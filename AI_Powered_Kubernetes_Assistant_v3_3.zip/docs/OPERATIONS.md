# Operations guide (v3.0)

## 1. Single sign-on (OIDC)
The service verifies JWTs itself; it never trusts identity headers. Flow for browsers:
`user → ingress → oauth2-proxy (IdP login) → assistant` with the user's token forwarded as
`Authorization: Bearer <jwt>` (or `X-Forwarded-Access-Token`). Scripts/CLIs send a token or an API key.

Required IdP settings: tokens signed with RS256/ES256, `aud` = `OIDC_AUDIENCE`, a **groups** claim
(name configurable via `OIDC_GROUPS_CLAIM`). Keycloak/Okta/Entra ID all support a groups claim; for Entra ID use
"groups" optional claim (or app roles) and keep group counts below the token overage limit.

Verified on every request: signature (JWKS, cached 1h), `iss`, `aud`, `exp`/`nbf` (30 s leeway), required claims.
`alg=none` and HMAC algorithms are rejected.

## 2. Authorization
Policy = rules mapping **groups / emails / subjects** → **role + clusters + namespaces** (globs allowed).
Roles: `viewer` (read) < `operator` (read + Claude Q&A/summary) < `admin`. No matching rule → **403**.
Namespace-scoped users never see nodes, other namespaces' pods/events/findings/history, and **Claude's digest is built
only from what that user may see**. Unknown and forbidden clusters both return 404 (no enumeration).

Service automation: `API_KEYS_FILE` holds SHA-256 digests only (`printf %s "$KEY" | sha256sum`); each key carries groups
that go through the same policy. The legacy single `API_KEY` still works as admin.

## 3. Multi-cluster
`CLUSTERS_CONFIG` lists clusters (in-cluster and/or kubeconfig). Every API takes `?cluster=<name>`; the default is the first.
For each **remote** cluster create a read-only identity there:

```bash
kubectl --context prod-us create namespace ka-reader
kubectl --context prod-us -n ka-reader create serviceaccount ka-reader
kubectl --context prod-us apply -f - <<'YAML'
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata: {name: ka-readonly}
rules:
  - {apiGroups: [""], resources: [pods, nodes, events], verbs: [get, list, watch]}
  - {apiGroups: [metrics.k8s.io], resources: [pods, nodes], verbs: [get, list]}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata: {name: ka-readonly}
roleRef: {apiGroup: rbac.authorization.k8s.io, kind: ClusterRole, name: ka-readonly}
subjects: [{kind: ServiceAccount, name: ka-reader, namespace: ka-reader}]
YAML
```
Build a kubeconfig for that ServiceAccount (token from `kubectl create token` for short-lived, or a
`kubernetes.io/service-account-token` Secret for long-lived; prefer an OIDC/exec plugin or workload identity where your platform supports it),
store it as a key in the Secret named by `remoteKubeconfigsSecret`, and reference it with `kubeconfigKey`.

## 4. Prometheus
* **Scrape**: `GET /metrics` (series prefixed `k8s_assistant_`). Auth: `METRICS_TOKEN` bearer if set, otherwise an admin identity.
  The chart's `ServiceMonitor` wires the token automatically.
* **Alerts**: `prometheus.rules.enabled=true` installs starter alerts (cluster unreachable, high-severity findings, memory growth,
  node saturation, auth-failure spike).
* **History**: with `prometheus.url`, `/api/history/*` reads cAdvisor/node-exporter series from Prometheus (survives restarts, identical
  across replicas). Requires `container_memory_working_set_bytes`, `container_cpu_usage_seconds_total`, `node_*` metrics, and a
  `cluster` label (configurable) when one Prometheus/Thanos/Mimir serves several clusters. If Prometheus is down the API falls back to in-process history.
  The leak/saturation **rules** still use the in-process sampler; they are evaluated per replica.

## 5. Day-2 checklist
* Terminate TLS at the ingress; keep `networkPolicy.enabled=true` and restrict egress to API servers, IdP JWKS, Prometheus, api.anthropic.com.
* Audit log (JSON lines on stdout) now includes `user` and `cluster`; ship it to your SIEM.
* Rate limiting is per user per replica. With N replicas the effective limit is up to N× the setting.
* Leave `ANTHROPIC_API_KEY` unset to keep every byte inside your network.
