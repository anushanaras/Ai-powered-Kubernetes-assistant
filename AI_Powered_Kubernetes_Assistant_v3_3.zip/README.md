# AI-Powered Kubernetes Assistant (v3.0)

Read-only, **multi-cluster** Kubernetes monitoring with **SSO (OIDC) + namespace-scoped RBAC**, a **Prometheus** `/metrics`
endpoint and history backend, a **Helm chart**, explainable rules and optional Claude-powered explanations. It never changes your cluster.

## What's new in 3.0
| Area | Change |
|---|---|
| Identity | OIDC JWT verification (JWKS, iss/aud/exp, RS256/ES256 only), hashed service API keys, legacy `API_KEY` still works as admin |
| Authorization | Roles `viewer`/`operator`/`admin` mapped from groups/emails; per-cluster and per-namespace scoping; default deny |
| Data isolation | Findings, pods, events, history **and the digest sent to Claude** are filtered to the caller's namespaces; nodes hidden from scoped users |
| Multi-cluster | `CLUSTERS_CONFIG`; every API takes `?cluster=`; per-cluster cache, history and sampler; forbidden = unknown (404) |
| Prometheus | `/metrics` (`k8s_assistant_*`), ServiceMonitor, starter alerts, optional Prometheus-backed history (`PROMETHEUS_URL`) |
| Deployment | Helm chart in `chart/kubernetes-assistant` (HA, PDB, NetworkPolicy, ingress, hardened pod); install guard refuses live mode without auth |
| Fail-closed | A configured-but-missing auth file never falls back to anonymous access |

See **docs/OPERATIONS.md** for SSO, RBAC policy, remote-cluster setup and Prometheus details.

## The app (desktop + mobile)
Open `https://<your-host>/app/` and install it: **Chrome/Edge** (Install icon in the address bar), **Android** (Add to Home screen),
**iOS Safari** (Share → Add to Home Screen). One installable PWA, no app-store build.
* **Operations**: cluster picker, KPIs, node CPU/memory bars with history sparklines, top pods, filterable findings.
* **Users**: *My access* (role, clusters, namespaces, what you may do) and recent activity; admins also see everyone's activity and who was active in the last hour.
* **Ask**: questions answered by Claude or the rules engine (operator/admin only).
* Sign-in: your SSO session (proxy-forwarded token) or an API key kept in session storage only. Strict CSP, no inline script, all text rendered via `textContent`.
* Works offline for the shell; data is never cached by the service worker.
Native desktop (Tauri) and mobile (Capacitor) project sources are in **`native/`**; see `native/README.md` for build steps and known limits.

## Streamlit interface (local, single user)
The same engine with a sidebar app: **Home · Cluster Monitoring · Logs Analysis · Event Analysis · AI Assistant · Dashboard · Settings**.
```bash
pip install -r requirements-streamlit.txt
streamlit run streamlit_app.py            # opens http://localhost:8501 (sample data by default)
DEMO_MODE=false streamlit run streamlit_app.py     # your cluster, using your kubeconfig (Windows: $env:DEMO_MODE="false")
```
* **Logs Analysis**: pick namespace and pod (or *All Pods*), *Fetch Logs*; level counts, error rate, detected issues (OOM, connection refused, DNS, timeouts,
  auth, disk, TLS, crashes...) with suggestions, level filter and search. Secrets are masked on screen by default.
* **AI Assistant**: describe a problem, *Get AI Recommendation* (Claude if `ANTHROPIC_API_KEY` is set, otherwise the built-in playbook). Only a redacted digest
  of findings and metrics is sent, plus, if you switch it on, pattern names and one short redacted example per pattern. Raw logs are never sent.
* **Dashboard**: CPU/memory gauges, pod-status donut, cluster metrics over time (auto-refresh configurable in Settings).
* Reading logs needs `get` on `pods/log` for your kubeconfig user. The interface has **no login** and binds to 127.0.0.1; for teams use the FastAPI server (SSO/RBAC).
* The file is `streamlit_app.py`, not `app.py`, because the project already has an `app/` package.

## Quick start with Helm
```bash
helm install ka chart/kubernetes-assistant -f chart/kubernetes-assistant/ci/values-production.example.yaml
# or evaluate with sample data (no cluster access, no auth): --set demoMode=true
```

## Authorization policy (excerpt)
```yaml
authz:
  rules:
    - {match: {groups: [platform-admins]}, role: admin,    clusters: ["*"],     namespaces: ["*"]}
    - {match: {groups: [team-payments]},   role: operator, clusters: [prod-eu], namespaces: [payments, "payments-*"]}
    - {match: {groups: [auditors]},        role: viewer,   clusters: ["*"],     namespaces: ["*"]}
```

## New endpoints
`GET /metrics` (Prometheus; `METRICS_TOKEN` or admin), `GET /api/clusters`, `GET /api/me`, `GET /api/audit` (own events; admins all), `GET /api/users/active` (admin); all `/api/*` accept `?cluster=`.

## Not (yet) included in 3.0
* Built-in browser login: use oauth2-proxy / ingress auth in front (the app verifies the forwarded token itself).
* Persistent audit store and per-user rate limits shared across replicas (audit goes to stdout JSON; limiter is per replica).
* Leak/saturation *rules* read the in-process sampler even when history API uses Prometheus.
* Log analysis and any write action (read-only by design).

---
## Original v2.0 documentation (single-cluster basics still apply)

Read-only Kubernetes monitoring with live metrics, metric history, explainable rules, and optional
Claude-powered explanations. It never changes your cluster.

## What it does
- **Live metrics** from Metrics Server: per-node and per-container CPU/memory, requests vs allocatable.
- **Rules engine** (always on, explainable): OOMKilled, CrashLoopBackOff, image-pull/config errors, unschedulable
  and long-Pending pods, containers near CPU/memory limits, missing requests/limits, right-sizing hints,
  node saturation and scheduling headroom, repeated Warning events.
- **History and trends** (in memory): memory-growth/leak detection with a time-to-limit projection, and sustained
  node saturation (not just spikes). Sparklines on the dashboard.
- **Claude integration (optional)**: natural-language Q&A and an executive summary, grounded in a compact,
  redacted digest of the findings. Falls back to the rules engine automatically if the API is unavailable.
- **Security**: API-key auth (Bearer / `X-API-Key` / browser Basic prompt), refuses to serve live data without a key,
  rate limiting, JSON audit log, security headers, non-root container with read-only filesystem.
- **Demo mode** with realistic sample data and two hours of synthetic history, so everything works without a cluster.

## Quick start (demo mode)
```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload                          # DEMO_MODE defaults to true
```
Open http://127.0.0.1:8000 (API docs at `/docs`).

## Live cluster
1. `kubectl get pods -A` and `kubectl top nodes` must work for the account running the service.
2. Set `DEMO_MODE=false` and **`API_KEY`** (startup fails without it unless `ALLOW_INSECURE=true`):
   ```bash
   export DEMO_MODE=false API_KEY="$(openssl rand -hex 32)"
   uvicorn app.main:app
   ```
   In a browser, the password prompt accepts the key as the password (any username). For scripts use
   `curl -H "X-API-Key: $API_KEY" http://127.0.0.1:8000/api/diagnostics`.
3. Optional Claude: `export ANTHROPIC_API_KEY=...` (model via `LLM_MODEL`, default `claude-sonnet-5-5`).

## Deploy to Kubernetes
```bash
kubectl create secret generic kubernetes-assistant \
  --from-literal=api-key="$(openssl rand -hex 32)" \
  --from-literal=anthropic-api-key="<optional>"
kubectl apply -f k8s/rbac.yaml            # re-apply on upgrade: now includes metrics.k8s.io
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/networkpolicy.yaml   # optional; needs a NetworkPolicy-enforcing CNI
kubectl port-forward service/kubernetes-assistant 8000:80
```
Build and push the image first (`docker build -t kubernetes-assistant:2.0 .`) and update the `image:` field.
Keep `replicas: 1`: history lives in the pod's memory. Do not expose it publicly without TLS (terminate at your ingress).

## API
| Endpoint | Description |
|---|---|
| `GET /health` | Liveness/readiness (no auth) |
| `GET /api/status` | Mode, auth/LLM enabled, history size |
| `GET /api/diagnostics?severity=&namespace=` | Findings with rule id, evidence, recommendation |
| `GET /api/metrics?top=5` | Node utilization and top CPU/memory pods |
| `GET /api/history/nodes` | Node CPU/memory % time series |
| `GET /api/history/pods/{ns}/{name}` | Pod series plus memory trend |
| `GET /api/pods/{ns}/{name}` | One pod and its findings |
| `POST /api/ask` | `{"question": "..."}` returns `answer`, `source` (`llm`/`rules`), `note` |
| `GET /api/summary` | Executive summary (Claude or rules) |
| `GET /api/cluster`, `GET /api/events` | Raw normalized snapshot / events |

## Configuration
| Variable | Default | Meaning |
|---|---|---|
| `DEMO_MODE` | `true` | Use built-in sample data |
| `API_KEY` | none | Required in live mode; enforced in any mode when set |
| `ALLOW_INSECURE` | `false` | Permit live mode without a key (isolated labs only) |
| `ANTHROPIC_API_KEY` / `LLM_MODEL` | none / `claude-sonnet-5-5` | Enable and choose the Claude model |
| `RATE_LIMIT_PER_MINUTE` | `20` | Per-client limit on `/api/ask` and `/api/summary` (0 disables) |
| `HISTORY_INTERVAL_SECONDS` / `HISTORY_MAX_POINTS` | `60` / `720` | Sampling interval and retained points (12 h by default) |
| `SNAPSHOT_TTL_SECONDS` | `10` | Live snapshot cache lifetime |
| `THRESHOLD_*` | see `Thresholds` in `app/analyzer.py` | `RESTARTS`, `PENDING_SECONDS`, `MEM_LIMIT_PCT`, `CPU_LIMIT_PCT`, `NODE_USAGE_PCT`, `NODE_REQUESTS_PCT`, `EVENT_COUNT`, `LEAK_GROWTH_PCT`, `LEAK_MIB_PER_HOUR` |

## Privacy and safety of the Claude integration
- Claude gets **no tools** and nothing it says is executed. Suggested commands are advice for a human.
- Only a compact digest leaves the process: findings, node utilization, top pods, problem-pod names/phases.
  No logs, environment variables, secrets, full pod specs, or kubeconfig. Strings are truncated and
  obvious `token=`/`password=`/Bearer values are redacted.
- Cluster text (event messages, names) is untrusted, so the prompt tells the model to treat it as data
  and ignore instructions inside it. This reduces, but cannot eliminate, prompt-injection risk. Review the
  digest in `app/llm.py::build_context` against your own data-sensitivity rules before enabling.
- Leave `ANTHROPIC_API_KEY` unset to keep all data inside your network.

## Audit log
One JSON object per line on stdout: `http_request` (method, path, status, ms, client), `ask`/`summary`
(question text clipped to 200 chars, source), `auth_failed`, `rate_limited`. Credentials are never logged.
`client` is the direct peer address; behind a proxy this will be the proxy's address.

## Tests
```bash
pip install -r requirements-dev.txt
pytest -q
```
Covers units, every rule, history/trend math, auth and rate limiting, the Claude client (with a mocked
transport), live-cluster normalization using fake Kubernetes objects, and HTTP endpoints via FastAPI's TestClient.
CI (`.github/workflows/ci.yml`) runs the tests on Python 3.10 and 3.12 and builds the image.

## Limitations
- History is in memory and resets on restart (no Prometheus/long-term storage yet).
- A single shared API key, not per-user identity or RBAC. Put an authenticating proxy (OIDC) in front for teams.
- No log analysis: the assistant reads pod/node/event state and metrics, not container logs.
- Rules are heuristics with tunable thresholds; treat findings as leads, not verdicts.
- Read-only by design: no scaling, restarting, or editing of resources.
