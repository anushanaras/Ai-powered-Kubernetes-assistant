# Native apps (desktop + mobile)

Thin native shells around the web app at `https://<your-server>/app/`. The UI, SSO and RBAC stay on the server,
so one backend release updates every client. Nothing is stored on the device except the server address.

```
native/
  launcher/   shared first-run screen: asks for the server address, validates it, then opens <server>/app/
  desktop/    Tauri v2 project  -> Windows (.msi/.exe), macOS (.dmg/.app), Linux (.deb/.AppImage/.rpm)
  mobile/     Capacitor 7 project -> Android (.apk/.aab), iOS (.ipa via Xcode)
```

## Desktop (Tauri)
Prerequisites: Node 20+, Rust stable, and your OS's Tauri prerequisites (https://v2.tauri.app/start/prerequisites/).
```bash
cd native/desktop
npm install
npm run dev        # run locally
npm run build      # installers in src-tauri/target/release/bundle/
```
Change `identifier` in `src-tauri/tauri.conf.json` (default `com.example.kubernetes-assistant`) to your own reverse-DNS id before shipping.

## Mobile (Capacitor)
Prerequisites: Node 20+; Android Studio (Android) and/or Xcode on macOS (iOS).
```bash
cd native/mobile
npm install
# Managed build (recommended): bake in your server so users never type it. List every host sign-in may visit.
export KA_SERVER_URL=https://k8s-assistant.example.com
export KA_ALLOWED_HOSTS=login.example.com
npx cap add android && npx cap add ios      # generates android/ and ios/ (not checked in)
npx cap sync
npx cap open android    # or: npx cap open ios   -> build/sign in the IDE
```
Without `KA_SERVER_URL` the app starts at the launcher and asks for the address (set `KA_ALLOWED_HOSTS` for production builds;
unset means "any host", which is for development only). Plain http is refused unless `KA_ALLOW_INSECURE_DEV=true`.
Change `appId` in `capacitor.config.ts` before publishing.

## Security model
* The launcher accepts only `https://` (plain http only for localhost/emulator), rejects embedded credentials and non-http schemes,
  keeps only the origin, and re-validates the stored value on every start.
* Desktop: navigation is limited to https (and localhost for testing); `file:`, `data:`, `javascript:` and other schemes are refused.
  No Tauri capability grants any native permission to the launcher or to remote pages, so your server and IdP pages cannot call native APIs.
* Mobile: `allowNavigation` restricts which hosts the webview may open; everything else is handed to the system browser.
* The web app itself keeps its strict CSP and never caches API data in the service worker.

## Known limits (read before rolling out)
* **Nothing here has been compiled or run on a device.** The source was written without Rust, Android or Xcode toolchains.
  The launcher logic, the Capacitor config and the JSON/assets are covered by automated tests; the Rust crate has unit tests that run with `cargo test`.
* **SSO in an embedded webview:** Okta, Entra ID, Keycloak and most enterprise IdPs work. Some IdPs (notably Google) refuse embedded
  webviews; use an API key, or a different IdP, for those. A system-browser (PKCE) sign-in flow would be the next step.
* **Switching server later:** use "Change server" on the launcher screen (shown briefly at start-up on generic builds). Managed mobile builds are fixed to their server.
* Code-signing and notarization (Apple, Microsoft, Play Store) are your organisation's accounts and are not configured here.
