use tauri::{Url, WebviewUrl, WebviewWindowBuilder};

/// Which URLs the window may navigate to.
///
/// The app is a shell around your Kubernetes Assistant server and your identity provider's sign-in pages,
/// so remote https pages are allowed. Everything else is refused: plain http (except localhost for testing),
/// file:, data:, javascript:, custom schemes. Remote pages get no access to Tauri's native APIs: no capability
/// in `capabilities/` grants permissions to remote origins.
fn allow_navigation(url: &Url) -> bool {
    match url.scheme() {
        "tauri" | "https" => true,
        "http" => matches!(
            url.host_str(),
            Some("localhost") | Some("127.0.0.1") | Some("[::1]") | Some("tauri.localhost")
        ),
        _ => false,
    }
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .setup(|app| {
            WebviewWindowBuilder::new(app, "main", WebviewUrl::App("index.html".into()))
                .title("Kubernetes Assistant")
                .inner_size(1280.0, 860.0)
                .min_inner_size(380.0, 600.0)
                .on_navigation(|url| allow_navigation(url))
                .build()?;
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running Kubernetes Assistant");
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ok(s: &str) -> bool {
        allow_navigation(&Url::parse(s).unwrap())
    }

    #[test]
    fn allows_https_and_internal_pages() {
        assert!(ok("https://k8s.example.com/app/"));
        assert!(ok("https://login.example.com/oauth2/authorize?x=1"));
        assert!(ok("tauri://localhost/index.html"));
        assert!(ok("http://tauri.localhost/index.html"));
        assert!(ok("http://localhost:8000/app/"));
    }

    #[test]
    fn refuses_everything_else() {
        assert!(!ok("http://k8s.example.com/app/"));
        assert!(!ok("file:///etc/passwd"));
        assert!(!ok("data:text/html,hi"));
        assert!(!ok("javascript:alert(1)"));
        assert!(!ok("ftp://example.com/"));
    }
}
