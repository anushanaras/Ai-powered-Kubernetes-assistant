/* Pure logic for the launcher (no DOM). Loaded as a classic script (window.KALauncher) and importable from Node. */
(function (root) {
  'use strict';
  const LOCAL = new Set(['localhost', '127.0.0.1', '[::1]', '10.0.2.2']);   // 10.0.2.2 = Android emulator -> host machine

  /* Turn what a person typed into a safe server origin, or return {error}. */
  function normalizeServerUrl(input, opts) {
    const allowInsecureLocal = !opts || opts.allowInsecureLocal !== false;
    let raw = String(input == null ? '' : input).trim();
    if (!raw) return { error: 'Enter your server address, e.g. k8s-assistant.example.com' };
    if (/^[a-z][a-z0-9+.-]*:/i.test(raw) && !/^https?:\/\//i.test(raw) && !/^[^/]+:\d+(\/|$)/.test(raw)) {
      return { error: 'Only https:// addresses are supported.' };       // javascript:, data:, file:, ftp: ...
    }
    if (!/^https?:\/\//i.test(raw)) raw = 'https://' + raw;
    let u;
    try { u = new URL(raw); } catch (e) { return { error: 'That does not look like a valid address.' }; }
    if (u.username || u.password) return { error: 'Do not put credentials in the address.' };
    if (!u.hostname) return { error: 'That does not look like a valid address.' };
    if (u.protocol === 'http:' && !(allowInsecureLocal && LOCAL.has(u.hostname))) {
      return { error: 'Use https:// (plain http is only allowed for local testing).' };
    }
    return { origin: u.origin, appUrl: u.origin + '/app/', host: u.host };
  }

  const KA = { normalizeServerUrl };
  if (typeof module !== 'undefined' && module.exports) module.exports = KA; else root.KALauncher = KA;
})(typeof window !== 'undefined' ? window : globalThis);
