(function () {
  'use strict';
  const STORE = 'ka_server_origin', $ = id => document.getElementById(id), L = window.KALauncher;
  let timer = null;

  function go(origin) { location.replace(origin + '/app/'); }
  function setStatus(msg, bad) { const s = $('status'); s.textContent = msg; s.className = bad ? 'bad' : 'muted'; }

  async function reachable(origin) {
    // The server sends no CORS headers, so use no-cors: we can only learn "reachable or not", which is all we need.
    const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 8000);
    try { await fetch(origin + '/health', { mode: 'no-cors', cache: 'no-store', signal: ctl.signal }); return true; }
    catch (e) { return false; } finally { clearTimeout(t); }
  }

  function showForm(prefill) {
    clearTimeout(timer);
    $('connecting').hidden = true; $('form').hidden = false;
    if (prefill) $('server').value = prefill;
    $('server').focus();
  }

  async function connect(e) {
    e.preventDefault();
    const r = L.normalizeServerUrl($('server').value);
    if (r.error) return setStatus(r.error, true);
    setStatus('Checking ' + r.host + '…');
    if (!(await reachable(r.origin))) return setStatus('Could not reach ' + r.host + '. Check the address and your network/VPN.', true);
    localStorage.setItem(STORE, r.origin);
    go(r.origin);
  }

  function init() {
    $('form').addEventListener('submit', connect);
    $('change').addEventListener('click', () => showForm(localStorage.getItem(STORE) || ''));
    const saved = localStorage.getItem(STORE), forceForm = new URLSearchParams(location.search).has('change');
    const r = saved ? L.normalizeServerUrl(saved) : null;          // re-validate: never trust stored data blindly
    if (!r || r.error || forceForm) { if (saved && (!r || r.error)) localStorage.removeItem(STORE); return showForm(r && !r.error ? saved : ''); }
    $('form').hidden = true; $('connecting').hidden = false; $('host').textContent = r.host;
    timer = setTimeout(() => go(r.origin), 1500);                   // short pause so "Change server" stays reachable
  }
  init();
})();
