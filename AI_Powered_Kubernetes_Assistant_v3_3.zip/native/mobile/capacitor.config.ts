import type { CapacitorConfig } from '@capacitor/cli';

/**
 * Two ways to build:
 *
 *  1. Enterprise / managed build (recommended): bake in your server so users never type an address.
 *       KA_SERVER_URL=https://k8s-assistant.example.com \
 *       KA_ALLOWED_HOSTS=k8s-assistant.example.com,login.example.com \
 *       npx cap sync
 *     KA_ALLOWED_HOSTS lists every host the app may navigate to: your server plus your identity provider's
 *     sign-in hosts. Wildcards such as *.okta.com are supported by Capacitor.
 *
 *  2. Generic build: leave KA_SERVER_URL unset. The app opens the bundled launcher, which asks for the server address.
 *     Set KA_ALLOWED_HOSTS here too for production; with it unset the generic build allows any host (development only).
 *
 * Plain http is refused unless KA_ALLOW_INSECURE_DEV=true (for an emulator talking to a dev server).
 */
type Env = Record<string, string | undefined>;

export function buildConfig(env: Env): CapacitorConfig {
  const serverUrl = (env.KA_SERVER_URL ?? '').trim().replace(/\/+$/, '');
  const hosts = (env.KA_ALLOWED_HOSTS ?? '').split(',').map((h) => h.trim()).filter(Boolean);
  const insecureDev = env.KA_ALLOW_INSECURE_DEV === 'true';

  let allowNavigation = hosts;
  let server: CapacitorConfig['server'];

  if (serverUrl) {
    const u = new URL(serverUrl); // throws on garbage, failing the build early
    if (u.protocol !== 'https:' && !(insecureDev && u.protocol === 'http:')) {
      throw new Error('KA_SERVER_URL must be https:// (set KA_ALLOW_INSECURE_DEV=true only for local testing).');
    }
    if (u.username || u.password) throw new Error('KA_SERVER_URL must not contain credentials.');
    allowNavigation = Array.from(new Set([u.host, ...hosts]));
    server = { url: `${u.origin}/app/`, cleartext: insecureDev && u.protocol === 'http:', allowNavigation };
  } else {
    server = { androidScheme: 'https', cleartext: false, allowNavigation: hosts.length ? hosts : ['*'] };
  }

  return {
    appId: 'com.example.kubernetesassistant',
    appName: 'Kubernetes Assistant',
    webDir: '../launcher',
    server,
    android: { allowMixedContent: false },
    ios: { contentInset: 'always' },
  };
}

export default buildConfig(process.env);
