"""Data preparation and tiny SVG/HTML builders for the Streamlit dashboards (pure; every dynamic string is escaped)."""
from html import escape
from typing import Any, Dict, Iterable, List, Optional, Tuple
import math

PHASE_COLORS = {"Running": "#2fbf71", "Pending": "#f5a524", "Failed": "#ef5350", "Succeeded": "#4aa3e8", "Unknown": "#8b97a8"}
LEVEL_COLORS = {"ERROR": "#ff6b6b", "WARN": "#ffb347", "INFO": "#5bc0ff", "DEBUG": "#9aa7b8", "UNKNOWN": "#c3cdd9"}


# --------------------------------------------------------------------------- summaries
def cluster_health(findings: List[Dict[str, Any]], snapshot: Dict[str, Any]) -> str:
    if snapshot.get("mode") == "error":
        return "Unknown"
    sev = {f["severity"] for f in findings}
    return "Critical" if "high" in sev else "Degraded" if "medium" in sev else "Healthy"


def node_is_ready(node: Dict[str, Any]) -> bool:
    return bool((node.get("conditions") or {}).get("Ready"))


def home_summary(snapshot: Dict[str, Any], findings: List[Dict[str, Any]]) -> Dict[str, Any]:
    pods, nodes = snapshot.get("pods", []), snapshot.get("nodes", [])
    return {"health": cluster_health(findings, snapshot),
            "pods_total": len(pods), "pods_running": sum(p.get("phase") == "Running" for p in pods),
            "nodes_total": len(nodes), "nodes_ready": sum(node_is_ready(n) for n in nodes),
            "alerts_active": sum(f["severity"] in ("high", "medium") for f in findings)}


def pod_status_counts(pods: Iterable[Dict[str, Any]]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for p in pods:
        phase = p.get("phase") if p.get("phase") in PHASE_COLORS else "Unknown"
        counts[phase] = counts.get(phase, 0) + 1
    return counts


def aggregate_usage(usage: Dict[str, Any]) -> Dict[str, Optional[float]]:
    """Cluster-wide CPU/memory % = total used / total allocatable across nodes (None when metrics are unavailable)."""
    nodes = [n for n in usage.get("nodes", []) if n.get("cpu_pct") is not None]
    if not nodes:
        return {"cpu_pct": None, "mem_pct": None}
    cpu_alloc = sum(n.get("cpu_allocatable_m") or 0 for n in nodes)
    mem_alloc = sum(n.get("mem_allocatable") or 0 for n in nodes)
    cpu = 100.0 * sum(n.get("cpu_used_m") or 0 for n in nodes) / cpu_alloc if cpu_alloc else None
    mem = 100.0 * sum(n.get("mem_used") or 0 for n in nodes) / mem_alloc if mem_alloc else None
    return {"cpu_pct": None if cpu is None else round(cpu, 1), "mem_pct": None if mem is None else round(mem, 1)}


def cluster_timeseries(history: Any) -> List[Tuple[float, Optional[float], Optional[float]]]:
    """[(ts, avg_cpu_pct, avg_mem_pct)] across nodes, oldest first."""
    by_ts: Dict[float, List[Tuple[Optional[float], Optional[float]]]] = {}
    for name in history.node_names():
        for ts, cpu, mem in history.node_series(name):
            by_ts.setdefault(ts, []).append((cpu, mem))
    def avg(vals):
        v = [x for x in vals if x is not None]
        return round(sum(v) / len(v), 1) if v else None
    return [(ts, avg(c for c, _ in rows), avg(m for _, m in rows)) for ts, rows in sorted(by_ts.items())]


# --------------------------------------------------------------------------- HTML / SVG builders
def _clamp(v: Optional[float]) -> float:
    return 0.0 if v is None or not math.isfinite(v) else max(0.0, min(100.0, float(v)))


def kpi_tile_html(label: str, value: str, sub: str, color: str) -> str:
    return (f'<div class="kpi" style="background:{escape(color)}"><div class="kv">{escape(value)}</div>'
            f'<div class="kl">{escape(label)}</div><div class="ks">{escape(sub)}</div></div>')


def gauge_svg(pct: Optional[float], label: str, size: int = 150) -> str:
    """A ring gauge. The colour follows load: <70 blue, <85 amber, else red."""
    p = _clamp(pct)
    r, c = 52, 2 * math.pi * 52
    color = "#ef5350" if p >= 85 else "#f5a524" if p >= 70 else "#35a7ff"
    text = "n/a" if pct is None else f"{round(p)}%"
    return (f'<div class="gauge"><svg viewBox="0 0 140 140" width="{int(size)}" height="{int(size)}" role="img" aria-label="{escape(label)} {escape(text)}">'
            f'<circle cx="70" cy="70" r="{r}" fill="none" stroke="#243750" stroke-width="14"/>'
            f'<circle cx="70" cy="70" r="{r}" fill="none" stroke="{color}" stroke-width="14" stroke-linecap="round" '
            f'stroke-dasharray="{c * p / 100:.1f} {c:.1f}" transform="rotate(-90 70 70)"/>'
            f'<text x="70" y="78" text-anchor="middle" font-size="26" font-weight="700" fill="currentColor">{escape(text)}</text></svg>'
            f'<div class="gl">{escape(label)}</div></div>')


def status_donut_html(counts: Dict[str, int], size: int = 150) -> str:
    total = sum(counts.values())
    r, c = 52, 2 * math.pi * 52
    segs, offset = [], 0.0
    for phase in PHASE_COLORS:
        n = counts.get(phase, 0)
        if n and total:
            length = c * n / total
            segs.append(f'<circle cx="70" cy="70" r="{r}" fill="none" stroke="{PHASE_COLORS[phase]}" stroke-width="14" '
                        f'stroke-dasharray="{length:.1f} {c - length:.1f}" stroke-dashoffset="{-offset:.1f}" transform="rotate(-90 70 70)"/>')
            offset += length
    legend = "".join(f'<div class="lg"><span class="dot" style="background:{PHASE_COLORS[ph]}"></span>{escape(ph)} <b>{counts[ph]}</b></div>'
                     for ph in PHASE_COLORS if counts.get(ph))
    base = '<circle cx="70" cy="70" r="52" fill="none" stroke="#243750" stroke-width="14"/>'
    return (f'<div class="donut"><svg viewBox="0 0 140 140" width="{int(size)}" height="{int(size)}" role="img" aria-label="Pod status">'
            f'{base}{"".join(segs)}<text x="70" y="78" text-anchor="middle" font-size="26" font-weight="700" fill="currentColor">{total}</text></svg>'
            f'<div class="legend">{legend or "No pods"}</div></div>')


def log_html(lines: List[Dict[str, Any]], limit: int = 300) -> str:
    """Colour-coded log block. Messages come from workloads, so they are escaped; nothing else is interpolated."""
    rows = []
    for l in lines[-limit:]:
        color = LEVEL_COLORS.get(l["level"], LEVEL_COLORS["UNKNOWN"])
        rows.append(f'<div><span class="ts">{escape(l["ts"] or "")}</span> <b style="color:{color}">{escape(l["level"])}</b> '
                    f'{escape(l["message"])}</div>')
    return '<div class="logbox">' + ("".join(rows) or '<span class="ts">No log lines.</span>') + "</div>"


CSS = """
<style>
.kpi{border-radius:12px;padding:16px 14px;color:#fff;text-align:center;min-height:112px}
.kpi .kv{font-size:22px;font-weight:700}.kpi .kl{font-size:14px;opacity:.95}.kpi .ks{font-size:12px;opacity:.85}
.gauge,.donut{text-align:center}.gl{opacity:.8;font-size:13px}
.legend{font-size:13px;margin-top:6px}.lg{display:flex;align-items:center;gap:6px;justify-content:center}
.dot{width:9px;height:9px;border-radius:50%;display:inline-block}
.logbox{font:12.5px/1.55 ui-monospace,Menlo,Consolas,monospace;background:#0b1320;color:#dbe6f3;border:1px solid #243750;border-radius:10px;padding:12px;max-height:380px;overflow:auto;word-break:break-word}
.logbox .ts{color:#6f87a6}
</style>
"""
