"""Log fetching helpers and log analysis (pure logic, no web framework).

Logs are untrusted and may contain secrets. Everything that leaves this module toward a model goes through
`redact()` and `ai_signals()` (a handful of short, redacted error lines), never raw logs.
"""
from typing import Any, Dict, List, Optional
import json
import re

LEVELS = ("ERROR", "WARN", "INFO", "DEBUG")
_LEVEL_ALIASES = {"ERR": "ERROR", "ERROR": "ERROR", "FATAL": "ERROR", "CRITICAL": "ERROR", "CRIT": "ERROR", "PANIC": "ERROR",
                  "SEVERE": "ERROR", "WARN": "WARN", "WARNING": "WARN", "INFO": "INFO", "NOTICE": "INFO",
                  "DEBUG": "DEBUG", "TRACE": "DEBUG"}
_LEVEL_RE = re.compile(r"\b(ERROR|ERR|FATAL|CRITICAL|CRIT|PANIC|SEVERE|WARNING|WARN|INFO|NOTICE|DEBUG|TRACE)\b", re.I)
_TS_RE = re.compile(r"^\[?(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\]?\s*")
_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_LEAD_LEVEL_RE = re.compile(r"^\[?(ERROR|ERR|FATAL|CRITICAL|CRIT|PANIC|SEVERE|WARNING|WARN|INFO|NOTICE|DEBUG|TRACE)\]?\s*[:\-]?\s+", re.I)
_LOGFMT_MSG_RE = re.compile(r'\bmsg="([^"]*)"')

# --------------------------------------------------------------------------- redaction
_REDACTIONS = [
    (re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?(-----END [A-Z ]*PRIVATE KEY-----|$)", re.S), "[REDACTED PRIVATE KEY]"),
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/=-]{8,}"), "Bearer [REDACTED]"),
    (re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}"), "[REDACTED JWT]"),
    (re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b"), "[REDACTED AWS KEY]"),
    (re.compile(r"\bsk-[A-Za-z0-9_-]{16,}"), "[REDACTED API KEY]"),
    (re.compile(r"\b(gh[pousr]_[A-Za-z0-9]{20,})"), "[REDACTED TOKEN]"),
    (re.compile(r"(?i)(://[^/\s:@]+):[^@\s/]+@"), r"\1:[REDACTED]@"),
    (re.compile(r"(?i)\b(token|password|passwd|pwd|secret|api[_-]?key|access[_-]?key|authorization)\b(\"?\s*[=:]\s*\"?)[^\s\",;&]+"),
     r"\1\2[REDACTED]"),
]


def redact(text: str) -> str:
    for rx, repl in _REDACTIONS:
        text = rx.sub(repl, text)
    return text


# --------------------------------------------------------------------------- parsing
def _level_of(message: str, obj: Optional[dict]) -> str:
    if obj:
        for key in ("level", "lvl", "severity", "levelname"):
            v = obj.get(key)
            if isinstance(v, str) and v.upper() in _LEVEL_ALIASES:
                return _LEVEL_ALIASES[v.upper()]
    m = re.search(r"(?i)\blevel=(\w+)", message[:120]) or _LEVEL_RE.search(message[:60])
    if m:
        return _LEVEL_ALIASES.get(m.group(1).upper(), "INFO")
    return "UNKNOWN"


def parse_log(text: str, max_lines: int = 1000) -> List[Dict[str, Any]]:
    """Split raw log text into {ts, level, message}. Handles plain, key=value and JSON-lines formats; keeps the last max_lines."""
    out: List[Dict[str, Any]] = []
    for raw in _CONTROL_RE.sub(" ", text or "").splitlines()[-max_lines:]:
        line = raw.rstrip()
        if not line.strip():
            continue
        obj = None
        if line.lstrip().startswith("{"):
            try:
                parsed = json.loads(line)
                obj = parsed if isinstance(parsed, dict) else None
            except ValueError:
                obj = None
        ts = None
        if obj:
            ts = str(obj.get("time") or obj.get("ts") or obj.get("timestamp") or "") or None
            message = str(obj.get("msg") or obj.get("message") or line)
        else:
            m = _TS_RE.match(line)
            ts, message = (m.group(1), line[m.end():]) if m else (None, line)
        level = _level_of(message, obj)
        if not obj:
            m2 = _LOGFMT_MSG_RE.search(message) if re.search(r"(?i)\blevel=", message[:120]) else None
            message = m2.group(1) if m2 else _LEAD_LEVEL_RE.sub("", message, count=1)   # the level is shown separately
        out.append({"ts": ts, "level": level, "message": message.strip()})
    return out


def filter_lines(lines: List[Dict[str, Any]], levels: Optional[List[str]] = None, query: str = "") -> List[Dict[str, Any]]:
    q = (query or "").strip().lower()
    return [l for l in lines if (not levels or l["level"] in levels) and (not q or q in l["message"].lower())]


# --------------------------------------------------------------------------- pattern detection
PATTERNS = [
    ("oom", r"out ?of ?memory|OutOfMemoryError|OOMKilled|Cannot allocate memory|java\.lang\.OutOfMemory", "high",
     "The application ran out of memory.",
     "Compare memory usage with the container limit. Raise the limit only if usage is legitimately high; otherwise look for a leak or unbounded cache."),
    ("conn-refused", r"connection refused|ECONNREFUSED|failed to connect|connect: no route to host|dial tcp .*(refused|unreachable)", "high",
     "A dependency refused or could not accept connections.",
     "Check that the target Service has ready endpoints (kubectl get endpoints), the port is right, and no NetworkPolicy blocks the traffic."),
    ("dns", r"no such host|NXDOMAIN|temporary failure in name resolution|could not resolve host|lookup .* on .*:53", "high",
     "DNS lookups are failing.", "Check CoreDNS pods and logs in kube-system, the service name and namespace spelling, and the pod's dnsPolicy."),
    ("timeout", r"timed? ?out|deadline exceeded|context deadline|i/o timeout", "medium",
     "Operations are timing out.", "Check latency of the downstream service, resource saturation (CPU throttling), and whether timeouts are set too low."),
    ("auth", r"permission denied|forbidden|unauthori[sz]ed|\b40[13]\b.*(http|status|response)|access denied|invalid credentials", "medium",
     "Requests are being rejected for authorization or authentication reasons.",
     "Verify the credentials the workload uses (ServiceAccount, Secret) and the RBAC or IAM permissions granted to them."),
    ("disk", r"no space left on device|disk (is )?full|ENOSPC", "high",
     "The filesystem is full.", "Check volume usage and log or temp-file growth; expand the volume or add cleanup/rotation."),
    ("tls", r"x509|certificate (has expired|is not valid|verify failed)|tls: .*(handshake|bad certificate)", "medium",
     "TLS certificate problems.", "Check certificate expiry and trust chain, and that the hostname matches the certificate."),
    ("fd", r"too many open files|EMFILE", "medium",
     "The process hit its open-file limit.", "Look for leaked connections or file handles; raise the ulimit only after ruling out a leak."),
    ("db", r"deadlock|too many connections|connection pool (exhausted|timeout)|could not obtain connection", "medium",
     "Database connection or locking problems.", "Check pool sizes against the database's max connections and look for long-running transactions."),
    ("crash", r"panic:|Traceback \(most recent call last\)|Unhandled(Promise)?Rejection|NullPointerException|Segmentation fault|SIGSEGV|fatal error:", "high",
     "The application crashed with an unhandled error.", "Read the stack trace around the first occurrence; check the last deployment or config change."),
    ("retry", r"retrying in|retry (attempt|#)|back-?off", "low",
     "The application is repeatedly retrying an operation.", "Find the failure that triggers the retries; the first error in the logs is usually the cause."),
]
_COMPILED = [(pid, re.compile(rx, re.I), sev, issue, rec) for pid, rx, sev, issue, rec in PATTERNS]
_SEV_RANK = {"high": 0, "medium": 1, "low": 2}


def analyze_logs(lines: List[Dict[str, Any]]) -> Dict[str, Any]:
    counts = {lvl: 0 for lvl in LEVELS}
    counts["UNKNOWN"] = 0
    hits: Dict[str, Dict[str, Any]] = {}
    first_error = None
    for l in lines:
        counts[l["level"]] = counts.get(l["level"], 0) + 1
        if l["level"] == "ERROR" and first_error is None:
            first_error = l
        for pid, rx, sev, issue, rec in _COMPILED:
            if rx.search(l["message"]):
                h = hits.setdefault(pid, {"pattern": pid, "severity": sev, "issue": issue, "recommendation": rec,
                                          "count": 0, "example": l["message"][:240]})
                h["count"] += 1
    findings = sorted(hits.values(), key=lambda h: (_SEV_RANK[h["severity"]], -h["count"]))
    total = len(lines)
    return {"total": total, "counts": counts, "error_rate": round(100.0 * counts["ERROR"] / total, 1) if total else 0.0,
            "first_error": first_error, "findings": findings}


def ai_signals(analysis: Dict[str, Any], limit: int = 8) -> List[Dict[str, Any]]:
    """The only log-derived data that may be sent to a model: pattern ids, counts and one short redacted example each."""
    return [{"pattern": f["pattern"], "severity": f["severity"], "count": f["count"], "example": redact(f["example"])[:160]}
            for f in analysis.get("findings", [])[:limit]]


# --------------------------------------------------------------------------- demo data
_DEMO = {
    "api": ["2026-10-14 12:01:32 INFO Starting application...", "2026-10-14 12:01:34 INFO Connected to database",
            "2026-10-14 12:02:10 WARN High memory usage detected", "2026-10-14 12:03:15 INFO Processing request /api/data",
            "2026-10-14 12:03:40 WARN High memory usage detected (97% of limit)",
            "2026-10-14 12:04:22 ERROR java.lang.OutOfMemoryError: Java heap space",
            "2026-10-14 12:04:23 ERROR Failed to connect to service payments-db:5432: connection refused",
            "2026-10-14 12:04:24 INFO Retrying in 5 seconds...", "2026-10-14 12:05:03 INFO Starting application...",
            "2026-10-14 12:05:09 ERROR Failed to connect to service payments-db:5432: connection refused",
            "2026-10-14 12:05:10 INFO Retrying in 5 seconds...",
            "2026-10-14 12:05:12 WARN auth header Bearer abcdef1234567890abcdef rejected"],
    "report": ["2026-10-14 12:00:01 INFO Report job started", "2026-10-14 12:10:00 INFO Cache size 410MB",
               "2026-10-14 12:20:00 WARN Cache size 560MB, no eviction configured", "2026-10-14 12:30:00 WARN Cache size 700MB, no eviction configured",
               "2026-10-14 12:31:00 ERROR request timed out after 30s calling storage-svc"],
    "default": ["2026-10-14 12:01:32 INFO Starting application...", "2026-10-14 12:01:34 INFO Connected to database",
                "2026-10-14 12:03:15 INFO Processing request /api/data", "2026-10-14 12:04:22 INFO Healthy"],
}


def demo_logs(pod_name: str) -> str:
    key = "api" if pod_name.startswith("api-") else "report" if pod_name.startswith("report-gen") else "default"
    return "\n".join(_DEMO[key])
