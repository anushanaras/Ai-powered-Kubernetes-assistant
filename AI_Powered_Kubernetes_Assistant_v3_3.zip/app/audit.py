"""Structured (JSON-lines) audit logging to stdout. Never logs credentials."""
import json
import logging
import sys
import time
from typing import Any

_logger = logging.getLogger("k8s-assistant.audit")
if not _logger.handlers:
    _handler = logging.StreamHandler(sys.stdout)
    _handler.setFormatter(logging.Formatter("%(message)s"))
    _logger.addHandler(_handler)
    _logger.setLevel(logging.INFO)
    _logger.propagate = False

_CONTROL = {c: " " for c in range(32)}


def clip(text: str, limit: int = 200) -> str:
    return str(text).translate(_CONTROL)[:limit]



# --------------------------------------------------------------------------- in-memory activity (for the app's dashboards)
from collections import deque  # noqa: E402
from threading import Lock  # noqa: E402
from typing import Deque, Dict, List, Optional  # noqa: E402

_RECENT: Deque[Dict[str, Any]] = deque(maxlen=500)
_USERS: Dict[str, Dict[str, Any]] = {}
_LOCK = Lock()
_MAX_USERS = 2000
_NOISY = {"http_request"}          # recorded in stdout, but too chatty for the activity feed


def audit(event: str, **fields: Any) -> None:
    record = {"ts": round(time.time(), 3), "event": event}
    record.update({k: (clip(v) if isinstance(v, str) else v) for k, v in fields.items()})
    _logger.info(json.dumps(record, default=str))
    if event not in _NOISY:
        with _LOCK:
            _RECENT.append(record)


def touch_user(label: str, role: str, auth_method: str, client: str = "", ts: Optional[float] = None) -> None:
    """Remember who was recently active. Per-process only (each replica keeps its own view)."""
    now = time.time() if ts is None else ts
    with _LOCK:
        u = _USERS.get(label)
        if u is None:
            if len(_USERS) >= _MAX_USERS:
                oldest = min(_USERS, key=lambda k: _USERS[k]["last_seen"])
                del _USERS[oldest]
            u = _USERS[label] = {"user": clip(label), "first_seen": now, "requests": 0}
        u.update(role=role, auth_method=auth_method, client=clip(client, 64), last_seen=now)
        u["requests"] += 1


def recent_events(limit: int = 100, user: Optional[str] = None) -> List[Dict[str, Any]]:
    """Newest first. With `user`, only that user's events (non-admins never see others' activity)."""
    with _LOCK:
        items = list(_RECENT)
    if user is not None:
        items = [e for e in items if e.get("user") == user]
    return list(reversed(items))[:max(1, min(limit, 500))]


def active_users(within_seconds: float = 900, now: Optional[float] = None) -> List[Dict[str, Any]]:
    now = time.time() if now is None else now
    with _LOCK:
        rows = [dict(u) for u in _USERS.values() if now - u["last_seen"] <= within_seconds]
    return sorted(rows, key=lambda u: u["last_seen"], reverse=True)


def reset_activity() -> None:
    with _LOCK:
        _RECENT.clear()
        _USERS.clear()
