from contextlib import asynccontextmanager
from dataclasses import dataclass
from threading import Lock
from typing import Any, Dict, List, Optional, Tuple
import hmac
import os
import time

from fastapi import APIRouter, Depends, FastAPI, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from app import metrics as prom_metrics
from app.analyzer import analyze_cluster, answer_question, utilization_summary
from app.audit import active_users, audit, recent_events, touch_user
from app.authn import ApiKeyStore, AuthError, Authenticator, OidcValidator
from app.authz import (Policy, Principal, allowed_clusters, can_access_cluster, filter_findings,
                       filter_snapshot, has_permission, load_policy, namespace_allowed, sees_cluster_scope)
from app.clusters import ClusterConfig, ClusterRegistry, load_registry
from app.history import History, Sampler, mem_trend, seed_demo_history, sparkline_points
from app.kube import get_snapshot
from app.llm import LLMClient, LLMError, build_context
from app.prom import PromError, PrometheusClient
from app.security import RateLimiter, anonymous_allowed, demo_mode, validate_startup_security
from app.units import fmt_cpu, fmt_memory

VERSION = "3.3.0"
limiter = RateLimiter(int(os.getenv("RATE_LIMIT_PER_MINUTE", "20")))
metrics = prom_metrics.build_registry()


def get_llm() -> Optional[LLMClient]:
    """Re-read the environment each call so the key can be rotated and tests can override it."""
    return LLMClient.from_env()


# --------------------------------------------------------------------------- shared state
@dataclass
class State:
    registry: ClusterRegistry
    histories: Dict[str, History]
    samplers: Dict[str, Sampler]
    policy: Policy
    prom: Optional[PrometheusClient]


_state: Optional[State] = None
_state_lock = Lock()
_auth_cache: Tuple[Tuple[str, ...], Optional[Authenticator]] = ((), None)


def build_state() -> State:
    registry = load_registry()
    max_points = int(os.getenv("HISTORY_MAX_POINTS", "720"))
    interval = float(os.getenv("HISTORY_INTERVAL_SECONDS", "60"))
    histories = {name: History(max_points=max_points) for name in registry.names()}
    samplers = {name: Sampler(histories[name], (lambda c=registry.get(name): get_snapshot(c)), interval=interval)
                for name in registry.names()}
    return State(registry, histories, samplers, load_policy(), PrometheusClient.from_env())


def state() -> State:
    global _state
    with _state_lock:
        if _state is None:
            _state = build_state()
        return _state


def get_authenticator() -> Authenticator:
    """Cached per distinct auth configuration, so JWKS keys are reused but key rotation still works."""
    global _auth_cache
    sig = tuple(os.getenv(k, "") for k in ("API_KEY", "API_KEYS_FILE", "OIDC_ISSUER", "OIDC_AUDIENCE",
                                           "OIDC_JWKS_URI", "OIDC_GROUPS_CLAIM", "OIDC_ALGORITHMS", "ALLOW_INSECURE",
                                           "DEMO_MODE"))
    if _auth_cache[0] == sig and _auth_cache[1] is not None:
        return _auth_cache[1]
    keys, oidc = ApiKeyStore.from_env(), OidcValidator.from_env()
    auth = Authenticator(keys, oidc, anonymous_allowed=anonymous_allowed())
    _auth_cache = (sig, auth)
    return auth


@asynccontextmanager
async def lifespan(_: FastAPI):
    global _state
    validate_startup_security()          # refuses to serve live data without authentication
    with _state_lock:
        _state = build_state()
    st = _state
    metrics.set_gauge_family("k8s_assistant_build_info", [({"version": VERSION}, 1)])
    for name in st.registry.names():
        if demo_mode():
            seed_demo_history(st.histories[name], get_snapshot(st.registry.get(name)))
        else:
            st.samplers[name].start()
    yield
    for sampler in st.samplers.values():
        sampler.stop()


app = FastAPI(title="AI-Powered Kubernetes Assistant", version=VERSION, lifespan=lifespan,
              description="Read-only multi-cluster monitoring with SSO/RBAC, Prometheus metrics and Claude-assisted troubleshooting.")
templates = Jinja2Templates(directory="app/templates")
templates.env.filters["cpu"] = fmt_cpu
templates.env.filters["mem"] = fmt_memory


# --------------------------------------------------------------------------- cross-cutting
def _client(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def current_principal(request: Request) -> Principal:
    try:
        raw = get_authenticator().authenticate(request.headers)
    except AuthError as exc:
        audit("auth_failed", path=request.url.path, client=_client(request), reason=str(exc))
        metrics.inc("k8s_assistant_auth_failures_total")
        raise HTTPException(status_code=401, detail="Authentication required.",
                            headers={"WWW-Authenticate": 'Basic realm="k8s-assistant"'}) from None
    principal = state().policy.resolve(raw)
    if principal.role == "none":
        audit("authz_denied", path=request.url.path, user=raw.label(), client=_client(request), reason="no matching role")
        metrics.inc("k8s_assistant_authz_denied_total", reason="no_role")
        raise HTTPException(status_code=403, detail="You are not authorized to use this service.")
    request.state.principal = principal
    return principal


def require(permission: str):
    def dep(request: Request, principal: Principal = Depends(current_principal)) -> Principal:
        if not has_permission(principal, permission):
            audit("authz_denied", path=request.url.path, user=principal.label(), client=_client(request),
                  reason=f"missing {permission}")
            metrics.inc("k8s_assistant_authz_denied_total", reason=permission)
            raise HTTPException(status_code=403, detail="Your role does not permit this action.")
        return principal
    return dep


@dataclass
class Ctx:
    principal: Principal
    cluster: ClusterConfig
    snapshot: Dict[str, Any]         # already filtered to what the principal may see
    history: History


def resolve_cluster(request: Request, name: Optional[str], principal: Principal) -> ClusterConfig:
    st = state()
    try:
        cfg = st.registry.get(name)
    except KeyError:
        cfg = None
    # Unknown and forbidden clusters look identical, so cluster names can't be enumerated.
    if cfg is None or not can_access_cluster(principal, cfg.name):
        if cfg is not None:
            audit("authz_denied", path=request.url.path, user=principal.label(), cluster=cfg.name,
                  client=_client(request), reason="cluster")
            metrics.inc("k8s_assistant_authz_denied_total", reason="cluster")
        raise HTTPException(status_code=404, detail="Unknown cluster.")
    request.state.cluster = cfg.name
    return cfg


def make_ctx(permission: str):
    def dep(request: Request, cluster: Optional[str] = Query(None, max_length=63),
            principal: Principal = Depends(require(permission))) -> Ctx:
        cfg = resolve_cluster(request, cluster, principal)
        snap = get_snapshot(cfg)
        if snap.get("mode") == "error":
            metrics.inc("k8s_assistant_snapshot_errors_total", cluster=cfg.name)
        return Ctx(principal, cfg, filter_snapshot(snap, principal), state().histories[cfg.name])
    return dep


read_ctx, ask_ctx = make_ctx("read"), make_ctx("ask")


def rate_limit(request: Request, principal: Principal = Depends(current_principal)) -> None:
    key = _client(request) if principal.auth_method == "anonymous" else principal.subject
    if not limiter.allow(key):
        audit("rate_limited", path=request.url.path, user=principal.label(), client=_client(request))
        metrics.inc("k8s_assistant_rate_limited_total")
        raise HTTPException(status_code=429, detail="Too many requests; slow down.")


@app.middleware("http")
async def audit_and_harden(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    elapsed = time.perf_counter() - start
    route = request.scope.get("route")
    route_label = getattr(route, "path", "unmatched")      # route template, never the raw path (bounded cardinality)
    if request.url.path not in ("/health", "/metrics"):
        principal = getattr(request.state, "principal", None)
        audit("http_request", method=request.method, path=request.url.path, status=response.status_code,
              ms=round(elapsed * 1000, 1), client=_client(request),
              user=principal.label() if principal else None, cluster=getattr(request.state, "cluster", None))
        if principal is not None:
            touch_user(principal.label(), principal.role, principal.auth_method, _client(request))
    metrics.inc("k8s_assistant_http_requests_total", method=request.method, route=route_label,
                status=str(response.status_code))
    metrics.observe("k8s_assistant_http_request_duration_seconds", elapsed, route=route_label)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    if request.url.path == "/":
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; frame-ancestors 'none'")
    elif request.url.path.startswith("/app"):
        # The installable app: no inline script, no third-party origins.
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; "
            "connect-src 'self'; manifest-src 'self'; worker-src 'self'; frame-ancestors 'none'; base-uri 'none'")
    return response


class Question(BaseModel):
    question: str = Field(min_length=2, max_length=500)


def _findings(ctx: Ctx, severity: Optional[str] = None, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
    findings = filter_findings(analyze_cluster(ctx.snapshot, history=ctx.history), ctx.principal)
    if severity:
        findings = [f for f in findings if f["severity"] == severity]
    if namespace:
        findings = [f for f in findings if f.get("namespace") == namespace]
    return findings


def _rules_summary(findings) -> str:
    real = [f for f in findings if f["severity"] != "info"]
    if not real:
        return "No issues were detected by the current rule set."
    counts = {s: sum(f["severity"] == s for f in real) for s in ("high", "medium", "low")}
    top = "; ".join(f"{f['resource']}: {f['issue']}" for f in real[:3])
    return (f"{counts['high']} high, {counts['medium']} medium and {counts['low']} low severity finding(s). "
            f"Most urgent: {top}")


def _node_sparklines(history: History, principal: Principal) -> Dict[str, Dict[str, str]]:
    if not sees_cluster_scope(principal):
        return {}
    out = {}
    for name in history.node_names():
        series = history.node_series(name)
        out[name] = {"cpu": sparkline_points([p[1] for p in series], vmax=100),
                     "mem": sparkline_points([p[2] for p in series], vmax=100)}
    return out


def _llm_outcome(outcome: str, cluster: str) -> None:
    metrics.inc("k8s_assistant_llm_requests_total", outcome=outcome, cluster=cluster)


# --------------------------------------------------------------------------- unauthenticated
@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/metrics", response_class=PlainTextResponse)
def prometheus_metrics(request: Request):
    """Prometheus scrape endpoint. Auth: METRICS_TOKEN bearer if set, else an authenticated admin."""
    token = os.getenv("METRICS_TOKEN", "").strip()
    if token:
        auth = request.headers.get("authorization", "")
        scheme, _, value = auth.partition(" ")
        if scheme.lower() != "bearer" or not hmac.compare_digest(value.strip().encode(), token.encode()):
            raise HTTPException(status_code=401, detail="Metrics token required.",
                                headers={"WWW-Authenticate": "Bearer"})
    else:
        principal = current_principal(request)
        if not has_permission(principal, "admin"):
            raise HTTPException(status_code=403, detail="Admin role required.")
    _refresh_cluster_gauges()
    return PlainTextResponse(metrics.render(), media_type=prom_metrics.CONTENT_TYPE)


def _refresh_cluster_gauges() -> None:
    st = state()
    findings_g, up_g, cpu_g, mem_g, pods_g = [], [], [], [], []
    for name in st.registry.names():
        snap = get_snapshot(st.registry.get(name))
        ok = snap.get("mode") in ("live", "demo")
        up_g.append(({"cluster": name}, 1 if ok else 0))
        if not ok:
            metrics.inc("k8s_assistant_snapshot_errors_total", cluster=name)
            continue
        counts: Dict[Tuple[str, str], int] = {}
        for f in analyze_cluster(snap, history=st.histories[name]):
            counts[(f["severity"], f["rule"])] = counts.get((f["severity"], f["rule"]), 0) + 1
        findings_g += [({"cluster": name, "severity": sev, "rule": rule}, n) for (sev, rule), n in counts.items()]
        phases: Dict[str, int] = {}
        for p in snap.get("pods", []):
            phases[p.get("phase", "Unknown")] = phases.get(p.get("phase", "Unknown"), 0) + 1
        pods_g += [({"cluster": name, "phase": ph}, n) for ph, n in phases.items()]
        for n in utilization_summary(snap).get("nodes", []):
            if n.get("cpu_pct") is not None:
                cpu_g.append(({"cluster": name, "node": n["name"]}, n["cpu_pct"]))
            if n.get("mem_pct") is not None:
                mem_g.append(({"cluster": name, "node": n["name"]}, n["mem_pct"]))
    metrics.set_gauge_family("k8s_assistant_findings", findings_g)
    metrics.set_gauge_family("k8s_assistant_cluster_up", up_g)
    metrics.set_gauge_family("k8s_assistant_node_cpu_utilization_percent", cpu_g)
    metrics.set_gauge_family("k8s_assistant_node_memory_utilization_percent", mem_g)
    metrics.set_gauge_family("k8s_assistant_pods", pods_g)


# --------------------------------------------------------------------------- protected routes
protected = APIRouter()


@protected.get("/", response_class=HTMLResponse)
def dashboard(request: Request, ctx: Ctx = Depends(read_ctx)):
    llm = get_llm()
    allowed = allowed_clusters(ctx.principal, state().registry.names())
    return templates.TemplateResponse(request, "index.html", {
        "snapshot": ctx.snapshot,
        "findings": _findings(ctx),
        "usage": utilization_summary(ctx.snapshot),
        "spark": _node_sparklines(ctx.history, ctx.principal),
        "ai_label": f"Claude ({llm.model})" if llm and has_permission(ctx.principal, "ask") else "Rules engine",
        "cluster": ctx.cluster.name,
        "clusters": allowed,
        "user": ctx.principal.label(),
    })


@protected.get("/api/me")
def me(principal: Principal = Depends(current_principal)):
    return {"user": principal.label(), "role": principal.role, "auth_method": principal.auth_method,
            "clusters": allowed_clusters(principal, state().registry.names()),
            "namespaces": sorted(principal.namespaces)}


@protected.get("/api/audit")
def audit_feed(limit: int = Query(50, ge=1, le=200), principal: Principal = Depends(require("read"))):
    """Recent activity. Admins see everyone's; everyone else sees only their own."""
    user = None if has_permission(principal, "admin") else principal.label()
    return {"scope": "all" if user is None else "self", "events": recent_events(limit, user)}


@protected.get("/api/users/active")
def users_active(minutes: int = Query(15, ge=1, le=1440), principal: Principal = Depends(require("admin"))):
    return {"window_minutes": minutes, "users": active_users(minutes * 60)}


@protected.get("/api/clusters")
def clusters(principal: Principal = Depends(require("read"))):
    return {"clusters": allowed_clusters(principal, state().registry.names()), "default": state().registry.default}


@protected.get("/api/status")
def status(ctx: Ctx = Depends(read_ctx)):
    llm = get_llm()
    snap = ctx.snapshot
    return {"cluster": ctx.cluster.name, "version": VERSION, "mode": snap.get("mode"),
            "auth_method": ctx.principal.auth_method, "role": ctx.principal.role,
            "llm_enabled": bool(llm) and has_permission(ctx.principal, "ask"),
            "history_backend": "prometheus" if state().prom and not demo_mode() else "memory",
            "history_samples": ctx.history.sample_count(),
            "metrics_available": bool((snap.get("metrics") or {}).get("available"))}


@protected.get("/api/cluster")
def cluster_snapshot(ctx: Ctx = Depends(read_ctx)):
    return ctx.snapshot


@protected.get("/api/diagnostics")
def diagnostics(severity: Optional[str] = Query(None, pattern="^(high|medium|low|info)$"),
                namespace: Optional[str] = Query(None, max_length=253), ctx: Ctx = Depends(read_ctx)):
    return {"cluster": ctx.cluster.name, "mode": ctx.snapshot.get("mode", "unknown"),
            "findings": _findings(ctx, severity, namespace)}


@protected.get("/api/metrics")
def metrics_summary(top: int = Query(5, ge=1, le=50), ctx: Ctx = Depends(read_ctx)):
    return {"cluster": ctx.cluster.name, "mode": ctx.snapshot.get("mode", "unknown"),
            **utilization_summary(ctx.snapshot, top_n=top)}


def _merge_by_ts(a: List[Tuple[float, float]], b: List[Tuple[float, float]]) -> List[Tuple[float, Optional[float], Optional[float]]]:
    bm = dict(b)
    return [(t, v, bm.get(t)) for t, v in a]


@protected.get("/api/history/nodes")
def history_nodes(ctx: Ctx = Depends(read_ctx)):
    if not sees_cluster_scope(ctx.principal):
        return {}
    prom = state().prom
    if prom and not demo_mode():
        try:
            end = time.time()
            data = prom.node_utilization(ctx.cluster.name, end - 6 * 3600, end)
            return {node: [{"ts": t, "cpu_pct": c, "mem_pct": m}
                           for t, c, m in _merge_by_ts(s.get("cpu_pct", []), s.get("mem_pct", []))]
                    for node, s in data.items()}
        except PromError:
            pass                                   # fall back to the in-process history
    h = ctx.history
    return {name: [{"ts": ts, "cpu_pct": c, "mem_pct": m} for ts, c, m in h.node_series(name)]
            for name in h.node_names()}


@protected.get("/api/history/pods/{namespace}/{name}")
def history_pod(namespace: str, name: str, ctx: Ctx = Depends(read_ctx)):
    if not namespace_allowed(ctx.principal, namespace):
        raise HTTPException(status_code=404, detail="No history for that pod yet.")
    series: List[Tuple[float, float, float]] = []
    prom = state().prom
    if prom and not demo_mode():
        try:
            end = time.time()
            mem = prom.pod_memory(ctx.cluster.name, namespace, name, end - 6 * 3600, end)
            cpu = dict(prom.pod_cpu_millicores(ctx.cluster.name, namespace, name, end - 6 * 3600, end))
            series = [(t, cpu.get(t, 0.0), m) for t, m in mem]
        except PromError:
            series = []
    if not series:
        series = ctx.history.pod_series(namespace, name)
    if not series:
        raise HTTPException(status_code=404, detail="No history for that pod yet.")
    return {"points": [{"ts": t, "cpu_m": c, "mem_bytes": m} for t, c, m in series],
            "memory_trend": mem_trend([(t, m) for t, _, m in series])}


@protected.get("/api/pods/{namespace}/{name}")
def pod_detail(namespace: str, name: str, ctx: Ctx = Depends(read_ctx)):
    pod = next((p for p in ctx.snapshot.get("pods", [])
                if p.get("namespace") == namespace and p.get("name") == name), None)
    if pod is None:
        raise HTTPException(status_code=404, detail="Pod not found in the current snapshot.")
    resource = f"pod/{namespace}/{name}"
    return {"pod": pod, "findings": [f for f in _findings(ctx) if f["resource"] == resource]}


@protected.post("/api/ask", dependencies=[Depends(rate_limit)])
def ask(payload: Question, request: Request, ctx: Ctx = Depends(ask_ctx)):
    answer, source, note = None, "rules", None
    llm = get_llm()
    findings = _findings(ctx)
    if llm and ctx.snapshot.get("mode") in ("live", "demo"):
        try:
            # The digest is built from the principal's filtered view, so Claude never sees other teams' namespaces.
            answer = llm.ask(payload.question, build_context(ctx.snapshot, findings, utilization_summary(ctx.snapshot)))
            source = "llm"
            _llm_outcome("ok", ctx.cluster.name)
        except LLMError as exc:
            note = f"Claude unavailable ({exc}); showing the rules-based answer."
            _llm_outcome("error", ctx.cluster.name)
    if answer is None:
        answer = answer_question(payload.question, ctx.snapshot, ctx.history)
    audit("ask", question=payload.question, source=source, user=ctx.principal.label(),
          cluster=ctx.cluster.name, client=_client(request))
    return {"answer": answer, "cluster": ctx.cluster.name, "mode": ctx.snapshot.get("mode", "unknown"),
            "source": source, "note": note}


@protected.get("/api/summary", dependencies=[Depends(rate_limit)])
def summary(request: Request, ctx: Ctx = Depends(ask_ctx)):
    findings = _findings(ctx)
    text, source, note = None, "rules", None
    llm = get_llm()
    if llm and ctx.snapshot.get("mode") in ("live", "demo"):
        try:
            text = llm.summarize(build_context(ctx.snapshot, findings, utilization_summary(ctx.snapshot)))
            source = "llm"
            _llm_outcome("ok", ctx.cluster.name)
        except LLMError as exc:
            note = f"Claude unavailable ({exc}); showing the rules-based summary."
            _llm_outcome("error", ctx.cluster.name)
    if text is None:
        text = _rules_summary(findings)
    audit("summary", source=source, user=ctx.principal.label(), cluster=ctx.cluster.name, client=_client(request))
    return {"summary": text, "cluster": ctx.cluster.name, "mode": ctx.snapshot.get("mode", "unknown"),
            "source": source, "note": note}


@protected.get("/api/events")
def events(ctx: Ctx = Depends(read_ctx)):
    return {"events": ctx.snapshot.get("events", [])}


app.include_router(protected)

# The installable app (PWA) shell is static and contains no data; every data call goes through the authenticated API.
import pathlib  # noqa: E402
_STATIC = pathlib.Path(__file__).parent / "static"
if _STATIC.is_dir():
    app.mount("/app", StaticFiles(directory=str(_STATIC), html=True), name="app")
