"""Kubernetes data access: live cluster (with Metrics Server) or a safe demo fallback.

Everything here is read-only (list/get calls only). The snapshot schema is plain
dicts so the analyzer can be tested without a cluster.
"""
from datetime import datetime, timezone
from threading import Lock
from typing import Any, Dict, List, Optional, Tuple
import os
import time

from app.units import parse_cpu, parse_memory

MAX_EVENTS = 200
ACTIVE_PHASES = ("Running", "Pending")

_cache_lock = Lock()
_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}     # per-cluster snapshot cache


# --------------------------------------------------------------------------- helpers
def _g(obj: Any, *path: str, default: Any = None) -> Any:
    """Null-safe attribute walk: _g(pod, 'status', 'phase')."""
    for attr in path:
        if obj is None:
            return default
        obj = getattr(obj, attr, None)
    return default if obj is None else obj


def _ts(value: Any) -> Optional[float]:
    return value.timestamp() if isinstance(value, datetime) else None


def _container(spec_c: Any, status: Any, usage: Optional[Dict[str, float]]) -> Dict[str, Any]:
    requests = _g(spec_c, "resources", "requests", default={}) or {}
    limits = _g(spec_c, "resources", "limits", default={}) or {}
    state, state_reason = "unknown", None
    if _g(status, "state", "waiting") is not None:
        state, state_reason = "waiting", _g(status, "state", "waiting", "reason")
    elif _g(status, "state", "running") is not None:
        state = "running"
    elif _g(status, "state", "terminated") is not None:
        state, state_reason = "terminated", _g(status, "state", "terminated", "reason")
    return {
        "name": _g(spec_c, "name", default="container"),
        "ready": bool(_g(status, "ready", default=False)),
        "restarts": int(_g(status, "restart_count", default=0) or 0),
        "state": state,
        "state_reason": state_reason,
        "last_terminated_reason": _g(status, "last_state", "terminated", "reason"),
        "last_exit_code": _g(status, "last_state", "terminated", "exit_code"),
        "cpu_request_m": parse_cpu(requests.get("cpu")),
        "cpu_limit_m": parse_cpu(limits.get("cpu")),
        "mem_request": parse_memory(requests.get("memory")),
        "mem_limit": parse_memory(limits.get("memory")),
        "cpu_usage_m": usage["cpu_m"] if usage else None,
        "mem_usage": usage["mem"] if usage else None,
    }


def pod_to_dict(pod: Any, pod_usage: Optional[Dict[str, Dict[str, float]]] = None,
                now: Optional[float] = None) -> Dict[str, Any]:
    """Normalize a V1Pod (or any object with the same attributes) into a plain dict."""
    pod_usage = pod_usage or {}
    now = now if now is not None else time.time()
    statuses = {s.name: s for s in (_g(pod, "status", "container_statuses", default=[]) or [])}
    containers: List[Dict[str, Any]] = [
        _container(c, statuses.get(c.name), pod_usage.get(c.name))
        for c in (_g(pod, "spec", "containers", default=[]) or [])
    ]
    scheduling = None
    for cond in _g(pod, "status", "conditions", default=[]) or []:
        if cond.type == "PodScheduled" and cond.status == "False":
            scheduling = {"reason": cond.reason or "", "message": (cond.message or "")[:300]}
    created = _ts(_g(pod, "metadata", "creation_timestamp"))
    owners = _g(pod, "metadata", "owner_references", default=[]) or []
    return {
        "name": _g(pod, "metadata", "name", default="unknown-pod"),
        "namespace": _g(pod, "metadata", "namespace", default="default"),
        "phase": _g(pod, "status", "phase", default="Unknown"),
        "ready": bool(statuses) and all(s.ready for s in statuses.values()),
        "restarts": sum(c["restarts"] for c in containers),
        "node": _g(pod, "spec", "node_name"),
        "age_seconds": int(now - created) if created else None,
        "owner_kind": owners[0].kind if owners else None,
        "scheduling": scheduling,
        "containers": containers,
    }


def node_to_dict(node: Any, usage: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
    allocatable = _g(node, "status", "allocatable", default={}) or {}
    conditions = {c.type: (c.status == "True") for c in (_g(node, "status", "conditions", default=[]) or [])}
    return {
        "name": _g(node, "metadata", "name", default="unknown-node"),
        "conditions": conditions,
        "allocatable_cpu_m": parse_cpu(allocatable.get("cpu")),
        "allocatable_mem": parse_memory(allocatable.get("memory")),
        "usage_cpu_m": usage["cpu_m"] if usage else None,
        "usage_mem": usage["mem"] if usage else None,
        "requests_cpu_m": 0.0,
        "requests_mem": 0.0,
        "pod_count": 0,
    }


def event_to_dict(event: Any) -> Dict[str, Any]:
    last = _ts(_g(event, "last_timestamp")) or _ts(_g(event, "event_time")) or _ts(_g(event, "metadata", "creation_timestamp"))
    return {
        "namespace": _g(event, "metadata", "namespace", default=""),
        "name": _g(event, "metadata", "name", default=""),
        "reason": _g(event, "reason", default=""),
        "message": (_g(event, "message", default="") or "")[:500],
        "type": _g(event, "type", default=""),
        "count": int(_g(event, "count", default=1) or 1),
        "object_kind": _g(event, "involved_object", "kind", default=""),
        "object_name": _g(event, "involved_object", "name", default=""),
        "last_seen": last,
    }


def attach_node_requests(pods: List[Dict[str, Any]], nodes: List[Dict[str, Any]]) -> None:
    """Sum scheduled pods' resource requests per node (what the scheduler sees)."""
    by_name = {n["name"]: n for n in nodes}
    for pod in pods:
        node = by_name.get(pod.get("node") or "")
        if not node or pod.get("phase") not in ACTIVE_PHASES:
            continue
        node["pod_count"] += 1
        for c in pod["containers"]:
            node["requests_cpu_m"] += c["cpu_request_m"] or 0.0
            node["requests_mem"] += c["mem_request"] or 0.0


# --------------------------------------------------------------------------- metrics
def parse_pod_metrics(items: List[Dict[str, Any]]) -> Dict[Tuple[str, str], Dict[str, Dict[str, float]]]:
    out: Dict[Tuple[str, str], Dict[str, Dict[str, float]]] = {}
    for item in items:
        meta = item.get("metadata", {})
        per_container = {}
        for c in item.get("containers", []):
            usage = c.get("usage", {})
            per_container[c.get("name", "")] = {
                "cpu_m": parse_cpu(usage.get("cpu")) or 0.0,
                "mem": parse_memory(usage.get("memory")) or 0.0,
            }
        out[(meta.get("namespace", ""), meta.get("name", ""))] = per_container
    return out


def parse_node_metrics(items: List[Dict[str, Any]]) -> Dict[str, Dict[str, float]]:
    return {
        item.get("metadata", {}).get("name", ""): {
            "cpu_m": parse_cpu(item.get("usage", {}).get("cpu")) or 0.0,
            "mem": parse_memory(item.get("usage", {}).get("memory")) or 0.0,
        }
        for item in items
    }


def _fetch_metrics(custom_api: Any) -> Tuple[Dict, Dict, Dict[str, Any]]:
    """Query metrics.k8s.io. Never raises; reports availability instead."""
    try:
        pods = custom_api.list_cluster_custom_object("metrics.k8s.io", "v1beta1", "pods")
        nodes = custom_api.list_cluster_custom_object("metrics.k8s.io", "v1beta1", "nodes")
        return (parse_pod_metrics(pods.get("items", [])),
                parse_node_metrics(nodes.get("items", [])),
                {"available": True, "reason": ""})
    except Exception as exc:  # noqa: BLE001 - report, don't leak internals
        status = getattr(exc, "status", None)
        if status == 404:
            reason = "Metrics API not found. Is Metrics Server installed?"
        elif status == 403:
            reason = "Access to metrics.k8s.io was denied. Apply the updated k8s/rbac.yaml."
        elif status == 503:
            reason = "Metrics API is registered but not serving yet (Metrics Server not ready)."
        else:
            reason = f"Metrics API unavailable ({type(exc).__name__})."
        return {}, {}, {"available": False, "reason": reason}


# --------------------------------------------------------------------------- demo data
def _demo_container(name: str, **kw: Any) -> Dict[str, Any]:
    base = {"name": name, "ready": True, "restarts": 0, "state": "running", "state_reason": None,
            "last_terminated_reason": None, "last_exit_code": None,
            "cpu_request_m": None, "cpu_limit_m": None, "mem_request": None, "mem_limit": None,
            "cpu_usage_m": None, "mem_usage": None}
    base.update(kw)
    return base


def _demo_snapshot() -> Dict[str, Any]:
    mi = 1024 ** 2
    gi = 1024 ** 3
    pods = [
        {"name": "web-7b9d8c", "namespace": "default", "phase": "Running", "ready": True, "restarts": 0,
         "node": "demo-node-1", "age_seconds": 86400 * 3, "owner_kind": "ReplicaSet", "scheduling": None,
         "containers": [_demo_container("web", cpu_request_m=250, cpu_limit_m=500, mem_request=256 * mi,
                                        mem_limit=512 * mi, cpu_usage_m=120, mem_usage=210 * mi)]},
        {"name": "worker-6f77ab", "namespace": "default", "phase": "Pending", "ready": False, "restarts": 0,
         "node": None, "age_seconds": 1800, "owner_kind": "ReplicaSet",
         "scheduling": {"reason": "Unschedulable",
                        "message": "0/2 nodes are available: 2 Insufficient memory."},
         "containers": [_demo_container("worker", ready=False, state="waiting", state_reason=None,
                                        cpu_request_m=500, mem_request=6 * gi, mem_limit=6 * gi)]},
        {"name": "api-55cc9f", "namespace": "payments", "phase": "Running", "ready": False, "restarts": 6,
         "node": "demo-node-2", "age_seconds": 86400, "owner_kind": "ReplicaSet", "scheduling": None,
         "containers": [_demo_container("api", ready=False, restarts=6, state="waiting",
                                        state_reason="CrashLoopBackOff",
                                        last_terminated_reason="OOMKilled", last_exit_code=137,
                                        cpu_request_m=200, cpu_limit_m=1000, mem_request=256 * mi,
                                        mem_limit=512 * mi, cpu_usage_m=40, mem_usage=498 * mi)]},
        {"name": "cache-0", "namespace": "payments", "phase": "Running", "ready": True, "restarts": 0,
         "node": "demo-node-2", "age_seconds": 86400 * 10, "owner_kind": "StatefulSet", "scheduling": None,
         "containers": [_demo_container("redis", cpu_request_m=1000, cpu_limit_m=1000, mem_request=2 * gi,
                                        mem_limit=2 * gi, cpu_usage_m=35, mem_usage=180 * mi)]},
        {"name": "batch-job-x9k2", "namespace": "default", "phase": "Running", "ready": True, "restarts": 0,
         "node": "demo-node-1", "age_seconds": 7200, "owner_kind": "Job", "scheduling": None,
         "containers": [_demo_container("batch", cpu_usage_m=910, mem_usage=300 * mi)]},
        {"name": "report-gen-5d8f", "namespace": "default", "phase": "Running", "ready": True, "restarts": 0,
         "node": "demo-node-1", "age_seconds": 86400, "owner_kind": "ReplicaSet", "scheduling": None,
         "containers": [_demo_container("report", cpu_request_m=200, cpu_limit_m=1000, mem_request=512 * mi,
                                        mem_limit=1 * gi, cpu_usage_m=150, mem_usage=700 * mi)]},
    ]
    nodes = [
        {"name": "demo-node-1", "conditions": {"Ready": True, "MemoryPressure": False, "DiskPressure": False, "PIDPressure": False},
         "allocatable_cpu_m": 4000.0, "allocatable_mem": 8 * gi, "usage_cpu_m": 1450.0, "usage_mem": 3.1 * gi,
         "requests_cpu_m": 0.0, "requests_mem": 0.0, "pod_count": 0},
        {"name": "demo-node-2", "conditions": {"Ready": True, "MemoryPressure": True, "DiskPressure": False, "PIDPressure": False},
         "allocatable_cpu_m": 4000.0, "allocatable_mem": 8 * gi, "usage_cpu_m": 900.0, "usage_mem": 7.2 * gi,
         "requests_cpu_m": 0.0, "requests_mem": 0.0, "pod_count": 0},
    ]
    attach_node_requests(pods, nodes)
    now = time.time()
    events = [
        {"namespace": "default", "name": "worker-6f77ab.1", "reason": "FailedScheduling",
         "message": "0/2 nodes are available: 2 Insufficient memory.", "type": "Warning", "count": 12,
         "object_kind": "Pod", "object_name": "worker-6f77ab", "last_seen": now - 120},
        {"namespace": "payments", "name": "api-55cc9f.1", "reason": "BackOff",
         "message": "Back-off restarting failed container api", "type": "Warning", "count": 41,
         "object_kind": "Pod", "object_name": "api-55cc9f", "last_seen": now - 30},
    ]
    return {"mode": "demo", "metrics": {"available": True, "reason": ""},
            "pods": pods, "nodes": nodes, "events": events}


# --------------------------------------------------------------------------- live collection
def _api_client(cluster: Optional[Any]) -> Any:
    """Build a Kubernetes ApiClient for one cluster (never mutates global client config)."""
    from kubernetes import client, config
    if cluster is not None and not cluster.in_cluster:
        if not cluster.kubeconfig:
            raise RuntimeError("cluster has neither in_cluster nor kubeconfig set")
        return config.new_client_from_config(config_file=cluster.kubeconfig, context=cluster.context)
    try:
        config.load_incluster_config()
    except Exception:  # noqa: BLE001
        if cluster is not None:          # explicitly in-cluster: do not silently fall back
            raise
        config.load_kube_config()
    return client.ApiClient()


def _collect_live(cluster: Optional[Any] = None) -> Dict[str, Any]:
    from kubernetes import client
    api = _api_client(cluster)
    v1 = client.CoreV1Api(api)
    pod_metrics, node_metrics, metrics_status = _fetch_metrics(client.CustomObjectsApi(api))
    now = time.time()

    pods = [pod_to_dict(p, pod_metrics.get((p.metadata.namespace, p.metadata.name)), now)
            for p in v1.list_pod_for_all_namespaces().items]
    nodes = [node_to_dict(n, node_metrics.get(n.metadata.name)) for n in v1.list_node().items]
    attach_node_requests(pods, nodes)

    events = [event_to_dict(e) for e in v1.list_event_for_all_namespaces().items]
    events.sort(key=lambda e: e["last_seen"] or 0, reverse=True)
    return {"mode": "live", "metrics": metrics_status, "pods": pods, "nodes": nodes,
            "events": events[:MAX_EVENTS]}


def get_snapshot(cluster: Optional[Any] = None) -> Dict[str, Any]:
    """Return a normalized snapshot for `cluster` (a ClusterConfig, or None for the default).

    DEMO_MODE defaults to true for a safe first run. Live snapshots are cached briefly per cluster
    (SNAPSHOT_TTL_SECONDS, default 10) so refreshes and concurrent users don't hammer the API server.
    """
    if os.getenv("DEMO_MODE", "true").lower() in ("1", "true", "yes"):
        return _demo_snapshot()
    try:
        ttl = float(os.getenv("SNAPSHOT_TTL_SECONDS", "10"))
    except ValueError:
        ttl = 10.0
    key = cluster.name if cluster is not None else "local"
    with _cache_lock:
        stamp, cached = _cache.get(key, (0.0, None))
        if cached is not None and time.time() - stamp < ttl:
            return cached
        try:
            snapshot = _collect_live(cluster)
        except Exception as exc:  # noqa: BLE001
            # Avoid leaking environment variables, credentials, or full internal tracebacks.
            return {"mode": "error", "metrics": {"available": False, "reason": ""},
                    "pods": [], "nodes": [], "events": [],
                    "error": f"Kubernetes connection failed: {type(exc).__name__}. Check kubeconfig, network, and RBAC."}
        _cache[key] = (time.time(), snapshot)
        return snapshot


# --------------------------------------------------------------------------- pod logs (optional, needs pods/log RBAC)
class LogsError(Exception):
    """Safe-to-display failure while reading logs."""


_DNS_LABEL = __import__("re").compile(r"[a-z0-9]([-a-z0-9.]{0,251}[a-z0-9])?")


def fetch_pod_logs(cluster: Optional[Any], namespace: str, pod: str, tail: int = 200, previous: bool = False,
                   container: Optional[str] = None) -> str:
    """Return the last `tail` log lines of a pod. Demo mode returns sample logs. Read-only; needs `get` on pods/log."""
    if not (_DNS_LABEL.fullmatch(namespace or "") and _DNS_LABEL.fullmatch(pod or "")):
        raise LogsError("Invalid namespace or pod name.")
    if os.getenv("DEMO_MODE", "true").lower() in ("1", "true", "yes"):
        from app.logs import demo_logs
        return demo_logs(pod)
    tail = max(1, min(int(tail), 1000))
    try:
        from kubernetes import client
        from kubernetes.client.rest import ApiException
    except ImportError:
        raise LogsError("The 'kubernetes' package is not installed.") from None
    try:
        v1 = client.CoreV1Api(_api_client(cluster))
        kwargs = {"tail_lines": tail, "timestamps": True, "limit_bytes": 512_000, "_request_timeout": 15}
        if previous:
            kwargs["previous"] = True
        if container:
            kwargs["container"] = container
        return v1.read_namespaced_pod_log(pod, namespace, **kwargs) or ""
    except ApiException as exc:
        hint = {403: "RBAC does not allow reading logs (grant get on pods/log).", 404: "Pod or container not found.",
                400: "The container has no logs yet (or no previous instance)."}.get(exc.status, f"Kubernetes returned HTTP {exc.status}.")
        raise LogsError(hint) from None
    except Exception as exc:  # noqa: BLE001
        raise LogsError(f"Could not read logs ({type(exc).__name__}).") from None
