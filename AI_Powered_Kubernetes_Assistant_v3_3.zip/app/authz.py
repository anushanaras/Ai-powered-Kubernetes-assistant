"""Authorization: roles, namespace scoping and cluster scoping (pure logic, framework-free).

Policy file (AUTHZ_POLICY, YAML/JSON):

    default_role: none            # what authenticated users with no matching rule get
    rules:
      - match: {groups: [platform-admins]}
        role: admin               # all clusters, all namespaces, can ask Claude
        clusters: ["*"]
        namespaces: ["*"]
      - match: {groups: [team-payments]}
        role: operator            # can use /api/ask and /api/summary
        clusters: [prod-eu]
        namespaces: [payments, payments-*]
      - match: {emails: [auditor@example.com]}
        role: viewer              # read-only dashboards/findings, no LLM

Roles: viewer < operator < admin. Multiple matching rules are merged (highest role wins,
clusters/namespaces are unioned). Cluster-scoped data (nodes) is visible to a principal only
when they hold "*" namespaces on that cluster.
"""
from dataclasses import dataclass, field
from fnmatch import fnmatchcase
from typing import Any, Dict, Iterable, List, Optional, Set
import json

ROLE_ORDER = {"none": 0, "viewer": 1, "operator": 2, "admin": 3}
PERMISSIONS = {
    "read": "viewer",       # findings, pods, events, metrics, history
    "ask": "operator",      # /api/ask, /api/summary (sends a digest to the LLM)
    "admin": "admin",       # /api/status details, /api/clusters health, cross-cluster views
}


@dataclass(frozen=True)
class Principal:
    subject: str
    email: str = ""
    groups: frozenset = frozenset()
    auth_method: str = "none"          # oidc | api-key | anonymous
    # Filled in by Policy.resolve():
    role: str = "none"
    clusters: frozenset = frozenset()
    namespaces: frozenset = frozenset()

    def label(self) -> str:
        return self.email or self.subject


def _match(value: str, patterns: Iterable[str]) -> bool:
    return any(fnmatchcase(value, p) for p in patterns)


@dataclass
class Policy:
    rules: List[Dict[str, Any]] = field(default_factory=list)
    default_role: str = "none"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Policy":
        default = str(data.get("default_role", "none"))
        if default not in ROLE_ORDER:
            raise ValueError(f"Unknown default_role {default!r}")
        rules = []
        for i, rule in enumerate(data.get("rules", [])):
            role = rule.get("role")
            if role not in ROLE_ORDER or role == "none":
                raise ValueError(f"Rule {i}: invalid role {role!r}")
            rules.append({"match": rule.get("match") or {}, "role": role,
                          "clusters": list(rule.get("clusters", ["*"])),
                          "namespaces": list(rule.get("namespaces", ["*"]))})
        return cls(rules=rules, default_role=default)

    @classmethod
    def from_file(cls, path: str) -> "Policy":
        with open(path, "r", encoding="utf-8") as fh:
            text = fh.read()
        if path.endswith(".json"):
            return cls.from_dict(json.loads(text))
        import yaml
        return cls.from_dict(yaml.safe_load(text) or {})

    def _rule_matches(self, rule: Dict[str, Any], p: Principal) -> bool:
        m = rule["match"]
        if not m:
            return False        # an empty match never grants anything (fail closed)
        if "groups" in m and any(_match(g, m["groups"]) for g in p.groups):
            return True
        if "emails" in m and p.email and _match(p.email.lower(), [e.lower() for e in m["emails"]]):
            return True
        if "subjects" in m and _match(p.subject, m["subjects"]):
            return True
        return False

    def resolve(self, p: Principal) -> Principal:
        role, clusters, namespaces = self.default_role, set(), set()
        for rule in self.rules:
            if self._rule_matches(rule, p):
                if ROLE_ORDER[rule["role"]] > ROLE_ORDER[role]:
                    role = rule["role"]
                clusters.update(rule["clusters"])
                namespaces.update(rule["namespaces"])
        if role == "none":
            return Principal(p.subject, p.email, p.groups, p.auth_method, "none", frozenset(), frozenset())
        if self.default_role != "none" and not clusters:
            clusters, namespaces = {"*"}, {"*"}      # default_role applies everywhere unless rules narrow it
        return Principal(p.subject, p.email, p.groups, p.auth_method, role,
                         frozenset(clusters), frozenset(namespaces))


def has_permission(p: Principal, permission: str) -> bool:
    need = PERMISSIONS[permission]
    return ROLE_ORDER.get(p.role, 0) >= ROLE_ORDER[need]


def can_access_cluster(p: Principal, cluster: str) -> bool:
    return p.role != "none" and _match(cluster, p.clusters)


def allowed_clusters(p: Principal, all_clusters: Iterable[str]) -> List[str]:
    return [c for c in all_clusters if can_access_cluster(p, c)]


def namespace_allowed(p: Principal, namespace: str) -> bool:
    return p.role != "none" and _match(namespace or "", p.namespaces)


def sees_cluster_scope(p: Principal) -> bool:
    """Nodes and other cluster-scoped data need unrestricted namespace access."""
    return p.role != "none" and "*" in p.namespaces


def filter_snapshot(snapshot: Dict[str, Any], p: Principal) -> Dict[str, Any]:
    """Return a copy of the snapshot containing only what `p` may see."""
    if sees_cluster_scope(p):
        return snapshot
    out = dict(snapshot)
    out["pods"] = [x for x in snapshot.get("pods", []) if namespace_allowed(p, x.get("namespace", ""))]
    out["events"] = [e for e in snapshot.get("events", []) if namespace_allowed(p, e.get("namespace", ""))]
    out["nodes"] = []          # node data is cluster-scoped; hidden from namespace-scoped users
    return out


def filter_findings(findings: List[Dict[str, Any]], p: Principal) -> List[Dict[str, Any]]:
    if sees_cluster_scope(p):
        return findings
    # Findings with no namespace (node-level) are cluster-scoped.
    return [f for f in findings if f.get("namespace") and namespace_allowed(p, f["namespace"])]


# --------------------------------------------------------------------------- loading
BUILTIN_RULES = [
    # Legacy single API_KEY (v2.0) and demo-mode anonymous access keep working as admin.
    {"match": {"groups": ["__legacy_admin__", "__anonymous__"]}, "role": "admin",
     "clusters": ["*"], "namespaces": ["*"]},
]


def load_policy(path: str = "") -> Policy:
    """Built-in rules first, then the operator's policy file (if any)."""
    import os
    path = path or os.getenv("AUTHZ_POLICY", "").strip()
    policy = Policy.from_file(path) if path else Policy()
    policy.rules = Policy.from_dict({"rules": BUILTIN_RULES}).rules + policy.rules
    return policy
