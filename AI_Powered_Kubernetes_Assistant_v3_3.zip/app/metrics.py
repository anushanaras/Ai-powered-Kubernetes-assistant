"""Minimal Prometheus text exposition (v0.0.4) with no third-party dependency.

Thread-safe counters, gauges and histograms with labels. Gauges that describe cluster state are
rebuilt on each scrape via `set_gauge_family`, so series for resolved findings disappear instead
of going stale.
"""
from threading import Lock
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

LabelKey = Tuple[Tuple[str, str], ...]
DEFAULT_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0)


def _key(labels: Dict[str, str]) -> LabelKey:
    return tuple(sorted((k, str(v)) for k, v in labels.items()))


def _esc(value: str) -> str:
    return value.replace("\\", "\\\\").replace("\n", "\\n").replace('"', '\\"')


def _fmt_labels(key: LabelKey, extra: Sequence[Tuple[str, str]] = ()) -> str:
    items = list(key) + list(extra)
    if not items:
        return ""
    return "{" + ",".join(f'{k}="{_esc(v)}"' for k, v in items) + "}"


def _num(v: float) -> str:
    if v == float("inf"):
        return "+Inf"
    return repr(float(v)) if v != int(v) else str(int(v))


class Registry:
    def __init__(self) -> None:
        self._lock = Lock()
        self._help: Dict[str, Tuple[str, str]] = {}
        self._counters: Dict[str, Dict[LabelKey, float]] = {}
        self._gauges: Dict[str, Dict[LabelKey, float]] = {}
        self._hists: Dict[str, Tuple[Tuple[float, ...], Dict[LabelKey, Tuple[List[int], float, int]]]] = {}

    def counter(self, name: str, help_text: str) -> None:
        self._help[name] = (help_text, "counter")
        self._counters.setdefault(name, {})

    def gauge(self, name: str, help_text: str) -> None:
        self._help[name] = (help_text, "gauge")
        self._gauges.setdefault(name, {})

    def histogram(self, name: str, help_text: str, buckets: Sequence[float] = DEFAULT_BUCKETS) -> None:
        self._help[name] = (help_text, "histogram")
        self._hists.setdefault(name, (tuple(sorted(buckets)), {}))

    def inc(self, name: str, amount: float = 1.0, **labels: str) -> None:
        with self._lock:
            series = self._counters[name]
            k = _key(labels)
            series[k] = series.get(k, 0.0) + amount

    def set_gauge_family(self, name: str, samples: Iterable[Tuple[Dict[str, str], float]]) -> None:
        """Replace every series of a gauge (so vanished label sets are dropped)."""
        with self._lock:
            self._gauges[name] = {_key(lbl): float(v) for lbl, v in samples if v is not None}

    def observe(self, name: str, value: float, **labels: str) -> None:
        with self._lock:
            buckets, series = self._hists[name]
            k = _key(labels)
            counts, total, n = series.get(k, ([0] * len(buckets), 0.0, 0))
            counts = list(counts)
            for i, b in enumerate(buckets):
                if value <= b:
                    counts[i] += 1
            series[k] = (counts, total + value, n + 1)

    def render(self) -> str:
        lines: List[str] = []
        with self._lock:
            for name, (help_text, kind) in sorted(self._help.items()):
                lines.append(f"# HELP {name} {help_text}")
                lines.append(f"# TYPE {name} {kind}")
                if kind == "counter":
                    for k, v in sorted(self._counters.get(name, {}).items()):
                        lines.append(f"{name}{_fmt_labels(k)} {_num(v)}")
                elif kind == "gauge":
                    for k, v in sorted(self._gauges.get(name, {}).items()):
                        lines.append(f"{name}{_fmt_labels(k)} {_num(v)}")
                else:
                    buckets, series = self._hists[name]
                    for k, (counts, total, n) in sorted(series.items()):
                        for b, c in zip(buckets, counts):
                            lines.append(f"{name}_bucket{_fmt_labels(k, [('le', _num(b))])} {c}")
                        lines.append(f"{name}_bucket{_fmt_labels(k, [('le', '+Inf')])} {n}")
                        lines.append(f"{name}_sum{_fmt_labels(k)} {_num(total)}")
                        lines.append(f"{name}_count{_fmt_labels(k)} {n}")
        return "\n".join(lines) + "\n"


CONTENT_TYPE = "text/plain; version=0.0.4; charset=utf-8"


def build_registry() -> Registry:
    r = Registry()
    r.counter("k8s_assistant_http_requests_total", "HTTP requests by method, route template and status.")
    r.histogram("k8s_assistant_http_request_duration_seconds", "HTTP request latency in seconds.")
    r.counter("k8s_assistant_auth_failures_total", "Failed authentication attempts.")
    r.counter("k8s_assistant_authz_denied_total", "Requests denied by authorization policy.")
    r.counter("k8s_assistant_rate_limited_total", "Requests rejected by the rate limiter.")
    r.counter("k8s_assistant_llm_requests_total", "Claude requests by outcome (ok/error/fallback).")
    r.counter("k8s_assistant_snapshot_errors_total", "Failed cluster snapshot collections.")
    r.gauge("k8s_assistant_findings", "Current findings by cluster, severity and rule.")
    r.gauge("k8s_assistant_cluster_up", "1 if the last snapshot of the cluster succeeded.")
    r.gauge("k8s_assistant_node_cpu_utilization_percent", "Node CPU usage as % of allocatable.")
    r.gauge("k8s_assistant_node_memory_utilization_percent", "Node memory usage as % of allocatable.")
    r.gauge("k8s_assistant_pods", "Pods by cluster and phase.")
    r.gauge("k8s_assistant_build_info", "Build information (value is always 1).")
    return r
