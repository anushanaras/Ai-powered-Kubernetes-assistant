"""Authentication helpers and a small in-memory rate limiter (pure logic, framework-free)."""
from collections import deque
from threading import Lock
from typing import Deque, Dict, Mapping, Optional
import base64
import hmac
import os
import time


def configured_api_key() -> str:
    return os.getenv("API_KEY", "").strip()


def demo_mode() -> bool:
    return os.getenv("DEMO_MODE", "true").lower() in ("1", "true", "yes")


def auth_configured() -> bool:
    """True when any authentication mechanism is configured (API key, key file, or OIDC SSO)."""
    return bool(configured_api_key() or os.getenv("API_KEYS_FILE", "").strip()
                or os.getenv("OIDC_ISSUER", "").strip())


def insecure_allowed() -> bool:
    return os.getenv("ALLOW_INSECURE", "false").lower() in ("1", "true", "yes")


def anonymous_allowed() -> bool:
    """Anonymous (admin) access only in demo mode or explicit ALLOW_INSECURE, and only when NO auth is configured.

    Any configured auth variable disables anonymous access even if its backing file is missing or empty,
    so a misconfiguration fails closed (401/403) instead of open.
    """
    return (demo_mode() or insecure_allowed()) and not auth_configured()


def validate_startup_security() -> None:
    """Refuse to serve a live cluster's data without authentication, unless explicitly overridden."""
    if demo_mode() or auth_configured():
        return
    if os.getenv("ALLOW_INSECURE", "false").lower() in ("1", "true", "yes"):
        return
    raise RuntimeError(
        "Live mode requires authentication. Configure OIDC_ISSUER/OIDC_AUDIENCE (SSO), API_KEYS_FILE, "
        "or API_KEY (or ALLOW_INSECURE=true for an isolated lab).")


def extract_credential(headers: Mapping[str, str]) -> Optional[str]:
    """Accept `Authorization: Bearer <key>`, `X-API-Key: <key>`, or HTTP Basic (password = key)."""
    lower = {k.lower(): v for k, v in headers.items()}
    if lower.get("x-api-key"):
        return lower["x-api-key"].strip()
    auth = lower.get("authorization", "")
    scheme, _, value = auth.partition(" ")
    value = value.strip()
    if scheme.lower() == "bearer" and value:
        return value
    if scheme.lower() == "basic" and value:
        try:
            decoded = base64.b64decode(value, validate=True).decode("utf-8")
        except (ValueError, UnicodeDecodeError):
            return None
        return decoded.partition(":")[2] or None
    return None


def is_authorized(credential: Optional[str], expected: str) -> bool:
    """Constant-time comparison. With no key configured, auth is disabled (demo mode only)."""
    if not expected:
        return True
    if not credential:
        return False
    return hmac.compare_digest(credential.encode(), expected.encode())


class RateLimiter:
    """Sliding-window limiter: at most `limit` hits per `window` seconds per key."""

    def __init__(self, limit: int, window: float = 60.0):
        self.limit, self.window = limit, window
        self._hits: Dict[str, Deque[float]] = {}
        self._lock = Lock()

    def allow(self, key: str, now: Optional[float] = None) -> bool:
        if self.limit <= 0:
            return True
        now = time.monotonic() if now is None else now
        with self._lock:
            q = self._hits.setdefault(key, deque())
            while q and now - q[0] >= self.window:
                q.popleft()
            if len(q) >= self.limit:
                return False
            q.append(now)
            if len(self._hits) > 1000:  # drop idle keys
                for k in [k for k, v in self._hits.items() if not v or now - v[-1] >= self.window]:
                    self._hits.pop(k, None)
            return True
