"""Parsing/formatting helpers for Kubernetes resource quantities (no external deps)."""
from typing import Optional, Union

Number = Union[int, float]

_MEM_SUFFIXES = {
    "Ki": 1024, "Mi": 1024**2, "Gi": 1024**3, "Ti": 1024**4, "Pi": 1024**5, "Ei": 1024**6,
    "k": 1000, "K": 1000, "M": 1000**2, "G": 1000**3, "T": 1000**4, "P": 1000**5, "E": 1000**6,
    "m": 0.001,
}


def parse_cpu(value: Optional[str]) -> Optional[float]:
    """Convert a CPU quantity ('250m', '2', '1500000n') to millicores."""
    if value is None or value == "":
        return None
    s = str(value).strip()
    try:
        if s.endswith("n"):
            return float(s[:-1]) / 1_000_000
        if s.endswith("u"):
            return float(s[:-1]) / 1_000
        if s.endswith("m"):
            return float(s[:-1])
        return float(s) * 1000
    except ValueError:
        return None


def parse_memory(value: Optional[str]) -> Optional[float]:
    """Convert a memory quantity ('128Mi', '1G', '123456') to bytes."""
    if value is None or value == "":
        return None
    s = str(value).strip()
    try:
        for suffix in ("Ki", "Mi", "Gi", "Ti", "Pi", "Ei"):  # binary suffixes first
            if s.endswith(suffix):
                return float(s[:-2]) * _MEM_SUFFIXES[suffix]
        if s[-1] in _MEM_SUFFIXES:
            return float(s[:-1]) * _MEM_SUFFIXES[s[-1]]
        return float(s)
    except (ValueError, IndexError):
        return None


def fmt_cpu(millicores: Optional[Number]) -> str:
    if millicores is None:
        return "n/a"
    if millicores >= 1000:
        return f"{millicores / 1000:.2f} cores"
    return f"{millicores:.0f}m"


def fmt_memory(num_bytes: Optional[Number]) -> str:
    if num_bytes is None:
        return "n/a"
    if num_bytes >= 1024**3:
        return f"{num_bytes / 1024**3:.1f}Gi"
    return f"{num_bytes / 1024**2:.0f}Mi"


def pct(used: Optional[Number], total: Optional[Number]) -> Optional[float]:
    """Percentage of total, or None when it cannot be computed."""
    if used is None or not total:
        return None
    return round(used / total * 100, 1)
