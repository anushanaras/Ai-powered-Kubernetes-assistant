/* Kubernetes Assistant app. All dynamic text is set via textContent (markup strings are never assigned), so cluster-controlled
   strings such as pod names and event messages cannot inject markup. */
(function () {
  'use strict';
  const KA = window.KA, $ = id => document.getElementById(id), KEY = 'ka_api_key';
  const state = { me: null, clusters: [], cluster: null, view: 'ops', sevFilter: 'all', timer: null };

  /* ---- tiny DOM helper ---- */
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v; else if (k === 'style') el.style.cssText = v; /* CSSOM is allowed under CSP; setAttribute('style') is not */ else if (k.startsWith('on')) el.addEventListener(k.slice(2), v); else el.setAttribute(k, v === true ? '' : v);
    }
    kids.flat().forEach(c => { if (c != null && c !== false) el.append(c.nodeType ? c : document.createTextNode(String(c))); });
    return el;
  }
  const svgNS = 'http://www.w3.org/2000/svg';
  function spark(values, color) {
    const s = document.createElementNS(svgNS, 'svg'); s.setAttribute('class', 'spark'); s.setAttribute('viewBox', '0 0 120 28'); s.setAttribute('preserveAspectRatio', 'none');
    const pts = KA.sparkPoints(values, 120, 28, 100);
    if (pts) { const p = document.createElementNS(svgNS, 'polyline'); p.setAttribute('points', pts); p.setAttribute('stroke', color); s.append(p); }
    return s;
  }
  const replace = (el, ...kids) => { el.replaceChildren(...kids.flat().filter(Boolean)); };

  /* ---- API ---- */
  class HttpError extends Error { constructor(status, detail) { super(detail || ('HTTP ' + status)); this.status = status; } }
  async function api(path, opts) {
    const headers = Object.assign({}, (opts && opts.headers) || {});
    const key = sessionStorage.getItem(KEY); if (key) headers['X-API-Key'] = key;
    let res;
    try { res = await fetch(path, Object.assign({}, opts, { headers, credentials: 'same-origin', redirect: 'manual' })); }
    catch (e) { throw new HttpError(0, 'offline'); }
    if (res.type === 'opaqueredirect') throw new HttpError(401, 'Your session has expired.');   // an SSO proxy wants a fresh login
    let body = null; try { body = await res.json(); } catch (e) { /* non-JSON error body */ }
    if (!res.ok) throw new HttpError(res.status, body && typeof body.detail === 'string' ? body.detail : null);
    return body;
  }
  const withCluster = p => p + (p.includes('?') ? '&' : '?') + 'cluster=' + encodeURIComponent(state.cluster);

  function banner(msg) { const b = $('banner'); if (msg) { b.textContent = msg; b.hidden = false; } else b.hidden = true; }

  /* ---- views ---- */
  async function renderOps() {
    const root = $('view-ops');
    const [metrics, diag, snap, hist] = await Promise.all([
      api(withCluster('/api/metrics?top=5')), api(withCluster('/api/diagnostics')), api(withCluster('/api/cluster')),
      api(withCluster('/api/history/nodes')).catch(() => ({}))]);
    banner(!metrics.metrics_available && metrics.reason ? 'Live metrics unavailable: ' + metrics.reason : (snap.mode === 'error' ? snap.error : ''));
    const sev = KA.countBySeverity(diag.findings), phases = KA.countByPhase(snap.pods || []);
    const kpi = (n, l, cls) => h('div', { class: 'card kpi' }, h('div', { class: 'n ' + (cls || '') }, n), h('div', { class: 'l' }, l));
    const phaseText = Object.entries(phases).map(([k, v]) => v + ' ' + k).join(' · ');

    const nodes = metrics.nodes || [];
    const nodeCard = h('div', { class: 'card' }, h('h2', null, 'Nodes'),
      nodes.length ? nodes.map(n => h('div', { class: 'node' },
        h('div', { class: 'head' }, h('strong', null, n.name), h('span', { class: 'muted' }, n.pod_count + ' pods')),
        h('div', { class: 'muted small' }, 'CPU ' + KA.fmtPct(n.cpu_pct) + ' used · ' + KA.fmtPct(n.cpu_requests_pct) + ' requested'),
        h('div', { class: 'bar ' + KA.level(n.cpu_pct) }, h('span', { style: 'width:' + Math.min(n.cpu_pct || 0, 100) + '%' })),
        h('div', { class: 'muted small' }, 'Memory ' + KA.fmtPct(n.mem_pct) + ' used · ' + KA.fmtPct(n.mem_requests_pct) + ' requested'),
        h('div', { class: 'bar ' + KA.level(n.mem_pct) }, h('span', { style: 'width:' + Math.min(n.mem_pct || 0, 100) + '%' })),
        (hist[n.name] || []).length > 1 ? h('div', null, spark(hist[n.name].map(p => p.cpu_pct), 'var(--brand)'), spark(hist[n.name].map(p => p.mem_pct), 'var(--crit)')) : null))
        : h('p', { class: 'muted' }, 'No node data. Node metrics are hidden for namespace-scoped access, or Metrics Server is unavailable.'));

    const podTable = (title, rows, valFn) => h('div', { class: 'card' }, h('h2', null, title),
      rows && rows.length ? h('div', { class: 'table-wrap' }, h('table', null, rows.map(p => h('tr', null, h('td', null, p.namespace + '/' + p.name), h('td', null, valFn(p)))))) : h('p', { class: 'muted' }, 'No data.'));

    replace(root,
      h('div', { class: 'grid' }, kpi((snap.pods || []).length, 'Pods'), kpi(nodes.length || '—', 'Nodes'),
        kpi(sev.high, 'High', sev.high ? 'sev high' : ''), kpi(sev.medium, 'Medium'), kpi(sev.low, 'Low')),
      h('p', { class: 'muted small' }, phaseText || 'No pods visible.'),
      h('div', { class: 'grid wide' }, nodeCard,
        podTable('Top CPU pods', metrics.top_cpu_pods, p => KA.fmtCpu(p.cpu_m)),
        podTable('Top memory pods', metrics.top_memory_pods, p => KA.fmtMem(p.mem) + (p.mem_limit_pct ? ' (' + Math.round(p.mem_limit_pct) + '% of limit)' : ''))),
      findingsCard(diag.findings));
  }

  function findingsCard(findings) {
    const list = KA.sortFindings(findings).filter(f => state.sevFilter === 'all' || f.severity === state.sevFilter);
    const chips = ['all', 'high', 'medium', 'low', 'info'].map(s => h('button', { class: 'chip', 'aria-pressed': String(state.sevFilter === s),
      onclick: () => { state.sevFilter = s; load(); } }, s));
    return h('div', { class: 'card' }, h('h2', null, 'Findings (' + list.length + ')'), h('div', { class: 'chips' }, chips),
      list.length ? list.map(f => h('details', { class: 'finding' },
        h('summary', null, h('span', { class: 'sev ' + f.severity }, f.severity), ' ' + f.resource + ' — ' + f.issue),
        f.evidence ? h('p', { class: 'muted' }, 'Evidence: ' + f.evidence) : null,
        h('p', null, 'Recommendation: ' + f.recommendation))) : h('p', { class: 'muted' }, 'Nothing to show for this filter.'));
  }

  async function renderUsers() {
    const root = $('view-users'), me = state.me, role = me.role;
    const perm = (label, ok) => h('tr', null, h('td', null, label), h('td', null, h('span', { class: 'badge ' + (ok ? 'ok' : 'no') }, ok ? 'allowed' : 'not allowed')));
    const access = h('div', { class: 'card' }, h('h2', null, 'My access'),
      h('div', { class: 'table-wrap' }, h('table', null,
        h('tr', null, h('td', null, 'User'), h('td', null, me.user)),
        h('tr', null, h('td', null, 'Role'), h('td', null, h('span', { class: 'badge' }, me.role))),
        h('tr', null, h('td', null, 'Sign-in'), h('td', null, me.auth_method)),
        h('tr', null, h('td', null, 'Clusters'), h('td', null, me.clusters.join(', ') || '—')),
        h('tr', null, h('td', null, 'Namespaces'), h('td', null, me.namespaces.join(', ') || '—')),
        perm('View dashboards and findings', KA.can(role, 'read')), perm('Ask Claude / summaries', KA.can(role, 'ask')),
        perm('See all users and activity', KA.can(role, 'admin')))));
    const [audit, active] = await Promise.all([api('/api/audit?limit=50'),
      KA.can(role, 'admin') ? api('/api/users/active?minutes=60') : Promise.resolve(null)]);
    const detail = e => e.question || e.reason || e.path || '';
    const activity = h('div', { class: 'card' }, h('h2', null, audit.scope === 'all' ? 'Recent activity (all users)' : 'My recent activity'),
      audit.events.length ? h('div', { class: 'table-wrap' }, h('table', null,
        h('tr', null, h('th', null, 'When'), audit.scope === 'all' ? h('th', null, 'User') : null, h('th', null, 'Event'), h('th', null, 'Cluster'), h('th', null, 'Detail')),
        audit.events.map(e => h('tr', null, h('td', null, KA.ago(e.ts)), audit.scope === 'all' ? h('td', null, e.user || '—') : null,
          h('td', null, e.event), h('td', null, e.cluster || '—'), h('td', null, detail(e)))))) : h('p', { class: 'muted' }, 'No activity recorded yet.'),
      h('p', { class: 'muted small' }, 'Held in memory by this replica; the permanent record is the JSON audit log.'));
    const users = active ? h('div', { class: 'card' }, h('h2', null, 'Active in the last hour'),
      active.users.length ? h('div', { class: 'table-wrap' }, h('table', null,
        h('tr', null, h('th', null, 'User'), h('th', null, 'Role'), h('th', null, 'Sign-in'), h('th', null, 'Requests'), h('th', null, 'Last seen')),
        active.users.map(u => h('tr', null, h('td', null, u.user), h('td', null, u.role), h('td', null, u.auth_method), h('td', null, u.requests), h('td', null, KA.ago(u.last_seen)))))) : h('p', { class: 'muted' }, 'Nobody yet.')) : null;
    replace(root, h('div', { class: 'grid wide' }, access, users), activity);
  }

  function setupAsk() {
    $('ask-form').addEventListener('submit', async e => {
      e.preventDefault();
      const q = $('question').value.trim(); if (q.length < 2) return;
      $('answer').textContent = 'Thinking…'; $('ask-meta').textContent = '';
      try {
        const r = await api(withCluster('/api/ask'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: q }) });
        $('answer').textContent = r.answer || 'No answer returned.';
        $('ask-meta').textContent = (r.source === 'llm' ? 'Claude, from a redacted digest of what you can see. ' : 'Rules engine. ') + (r.note || '');
      } catch (err) {
        $('answer').textContent = err.status === 403 ? 'Your role does not allow asking questions (operator or admin required).'
          : err.status === 429 ? 'Too many requests. Please wait a minute.' : (err.status === 0 ? 'You appear to be offline.' : err.message);
      }
    });
  }

  /* ---- navigation / lifecycle ---- */
  const TITLES = { ops: 'Operations', users: 'Users', ask: 'Ask' };
  async function load() {
    clearTimeout(state.timer);
    try {
      if (state.view === 'ops') await renderOps(); else if (state.view === 'users') await renderUsers();
      if (state.view !== 'ops' && state.view !== 'users') banner('');
    } catch (err) { handleError(err); }
    if (state.view !== 'ask') state.timer = setTimeout(() => { if (!document.hidden) load(); else state.timer = setTimeout(load, 30000); }, 30000);
  }
  function handleError(err) {
    if (err.status === 401 || err.status === 403) return showLogin(err);
    banner(err.status === 0 ? 'You are offline. Showing the last loaded data; it will refresh when the connection returns.' : err.message);
  }
  function show(view) {
    state.view = view;
    ['ops', 'users', 'ask'].forEach(v => { $('view-' + v).hidden = v !== view; });
    document.querySelectorAll('#nav button[data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    $('title').textContent = TITLES[view];
    $('cluster').parentElement.hidden = false;
    history.replaceState(null, '', '?view=' + view); load();
  }
  function showLogin(err) {
    $('shell').hidden = true; $('login').hidden = false; clearTimeout(state.timer);
    $('login-msg').textContent = err && err.status === 403 ? 'You are signed in but have no access. Ask your platform team to add you to a group.' : (err && err.message !== 'HTTP 401' ? err.message : 'Sign in to continue.');
  }
  async function boot() {
    $('sso').addEventListener('click', () => location.reload());
    $('login-form').addEventListener('submit', e => { e.preventDefault(); const k = $('apikey').value.trim(); if (!k) return; sessionStorage.setItem(KEY, k); $('apikey').value = ''; boot(); });
    $('signout').addEventListener('click', () => { sessionStorage.removeItem(KEY); location.reload(); });
    document.querySelectorAll('#nav button[data-view]').forEach(b => b.addEventListener('click', () => show(b.dataset.view)));
    $('refresh').addEventListener('click', load);
    $('cluster').addEventListener('change', e => { state.cluster = e.target.value; load(); });
    setupAsk();
    window.addEventListener('online', load);
    document.addEventListener('visibilitychange', () => { if (!document.hidden && state.view !== 'ask') load(); });
    await start();
  }
  async function start() {
    try {
      state.me = await api('/api/me');
      const c = await api('/api/clusters'); state.clusters = c.clusters; state.cluster = state.cluster && c.clusters.includes(state.cluster) ? state.cluster : c.default;
      if (!state.clusters.includes(state.cluster)) state.cluster = state.clusters[0];
      replace($('cluster'), state.clusters.map(n => h('option', { value: n, selected: n === state.cluster }, n)));
      $('login').hidden = true; $('shell').hidden = false; $('signout').hidden = !sessionStorage.getItem(KEY);
      const v = new URLSearchParams(location.search).get('view'); show(TITLES[v] ? v : 'ops');
    } catch (err) { if (err.status === 0) { $('login').hidden = true; $('shell').hidden = false; banner('You are offline.'); } else showLogin(err); }
  }
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/app/sw.js', { scope: '/app/' }).catch(() => {});
  boot();
})();
