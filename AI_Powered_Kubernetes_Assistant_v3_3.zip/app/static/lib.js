/* Pure helpers (no DOM). Loaded as a classic script (window.KA) and importable from Node for tests. */
(function (root) {
  'use strict';
  const SEVERITY_ORDER = { high: 0, medium: 1, low: 2, info: 3 };

  function fmtMem(bytes) {
    if (bytes == null || isNaN(bytes)) return '—';
    const mi = bytes / 1048576;
    return mi >= 1024 ? (mi / 1024).toFixed(1) + ' Gi' : Math.round(mi) + ' Mi';
  }
  function fmtCpu(m) {
    if (m == null || isNaN(m)) return '—';
    return m >= 1000 ? (m / 1000).toFixed(2) + ' cores' : Math.round(m) + 'm';
  }
  function fmtPct(v) { return v == null || isNaN(v) ? '—' : Math.round(v) + '%'; }
  function level(pct) { return pct == null ? 'ok' : pct >= 95 ? 'crit' : pct >= 85 ? 'warn' : 'ok'; }
  function ago(ts, now) {
    const s = Math.max(0, Math.round((now == null ? Date.now() / 1000 : now) - ts));
    if (s < 60) return s + 's ago';
    if (s < 3600) return Math.floor(s / 60) + 'm ago';
    if (s < 86400) return Math.floor(s / 3600) + 'h ago';
    return Math.floor(s / 86400) + 'd ago';
  }
  /* SVG polyline points for values in [0, vmax]; nulls skipped; needs >= 2 points. */
  function sparkPoints(values, width, height, vmax) {
    const v = values.filter(x => x != null && !isNaN(x));
    if (v.length < 2) return '';
    const hi = vmax || Math.max.apply(null, v) || 1, step = width / (v.length - 1);
    return v.map((x, i) => (i * step).toFixed(1) + ',' + (height - Math.min(Math.max(x, 0), hi) / hi * height).toFixed(1)).join(' ');
  }
  function sortFindings(list) {
    return list.slice().sort((a, b) => (SEVERITY_ORDER[a.severity] ?? 9) - (SEVERITY_ORDER[b.severity] ?? 9));
  }
  function countBySeverity(list) {
    const c = { high: 0, medium: 0, low: 0, info: 0 };
    list.forEach(f => { if (f.severity in c) c[f.severity]++; });
    return c;
  }
  function countByPhase(pods) {
    const c = {};
    pods.forEach(p => { c[p.phase || 'Unknown'] = (c[p.phase || 'Unknown'] || 0) + 1; });
    return c;
  }
  /* What may this role do? Mirrors the server's permission table (the server is the authority). */
  const ROLE_RANK = { none: 0, viewer: 1, operator: 2, admin: 3 };
  function can(role, permission) {
    const need = { read: 'viewer', ask: 'operator', admin: 'admin' }[permission];
    return (ROLE_RANK[role] || 0) >= ROLE_RANK[need];
  }
  const KA = { fmtMem, fmtCpu, fmtPct, level, ago, sparkPoints, sortFindings, countBySeverity, countByPhase, can };
  if (typeof module !== 'undefined' && module.exports) module.exports = KA; else root.KA = KA;
})(typeof window !== 'undefined' ? window : globalThis);
