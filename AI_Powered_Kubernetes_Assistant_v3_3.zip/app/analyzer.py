"""Rule-based diagnostic engine for Kubernetes Assistant.

Explainable rules only: every finding says which rule fired, on what evidence,
and what to check next. Nothing here executes remediation.
"""
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import os
import re

from app.history import mem_trend
from app.units import fmt_cpu, fmt_memory, pct

SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2, "info": 3}
WAITING_IMAGE = ("ImagePullBackOff", "ErrImagePull", "InvalidImageName")
WAITING_CONFIG = ("CreateContainerConfigError", "CreateContainerError", "RunContainerError")
EVENT_HINTS = {
    "FailedScheduling": "Pods cannot be placed; compare pod requests with node allocatable and taints/affinity.",
    "BackOff": "Containers keep failing and restarting; read current and previous logs.",
    "Unhealthy": "Liveness/readiness probes are failing; verify probe path, port, and startup time.",
    "FailedMount": "A volume cannot be mounted; check PVC status, storage class, and secrets/configmaps.",
    "FailedAttachVolume": "A volume cannot be attached; check the storage backend and node zone.",
    "Evicted": "Pods were evicted under node pressure; check node memory/disk and pod requests.",
    "OOMKilling": "The kernel killed a process for exceeding memory; raise limits or fix a leak.",
    "NodeNotReady": "A node went NotReady; check kubelet and network on that node.",
    "FailedCreate": "A controller cannot create pods; check quotas, admission webhooks, and RBAC.",
}


def _env_num(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except ValueError:
        return default


@dataclass(frozen=True)
class Thresholds:
    restarts: int = 5
    pending_seconds: int = 300
    mem_limit_pct: float = 90.0
    cpu_limit_pct: float = 90.0
    node_usage_pct: float = 85.0
    node_requests_pct: float = 90.0
    event_count: int = 3
    rightsize_age_seconds: int = 3600
    leak_growth_pct: float = 25.0
    leak_min_mib_per_hour: float = 10.0
    leak_min_r2: float = 0.85
    sustained_fraction: float = 0.8
    sustained_min_samples: int = 10
    ignore_namespaces: tuple = ("kube-system", "kube-public", "kube-node-lease")

    @classmethod
    def from_env(cls) -> "Thresholds":
        """Override defaults with e.g. THRESHOLD_MEM_LIMIT_PCT=85."""
        d = cls()
        return cls(
            restarts=int(_env_num("THRESHOLD_RESTARTS", d.restarts)),
            pending_seconds=int(_env_num("THRESHOLD_PENDING_SECONDS", d.pending_seconds)),
            mem_limit_pct=_env_num("THRESHOLD_MEM_LIMIT_PCT", d.mem_limit_pct),
            cpu_limit_pct=_env_num("THRESHOLD_CPU_LIMIT_PCT", d.cpu_limit_pct),
            node_usage_pct=_env_num("THRESHOLD_NODE_USAGE_PCT", d.node_usage_pct),
            node_requests_pct=_env_num("THRESHOLD_NODE_REQUESTS_PCT", d.node_requests_pct),
            event_count=int(_env_num("THRESHOLD_EVENT_COUNT", d.event_count)),
            leak_growth_pct=_env_num("THRESHOLD_LEAK_GROWTH_PCT", d.leak_growth_pct),
            leak_min_mib_per_hour=_env_num("THRESHOLD_LEAK_MIB_PER_HOUR", d.leak_min_mib_per_hour),
        )


def _finding(rule: str, severity: str, resource: str, issue: str, recommendation: str,
             namespace: Optional[str] = None, evidence: Optional[str] = None) -> Dict[str, Any]:
    return {"rule": rule, "severity": severity, "resource": resource, "namespace": namespace,
            "issue": issue, "evidence": evidence, "recommendation": recommendation}


def _human_age(seconds: Optional[float]) -> str:
    if seconds is None:
        return "unknown time"
    seconds = int(seconds)
    if seconds < 120:
        return f"{seconds}s"
    if seconds < 7200:
        return f"{seconds // 60}m"
    if seconds < 172800:
        return f"{seconds // 3600}h"
    return f"{seconds // 86400}d"


# --------------------------------------------------------------------------- pod rules
def _analyze_pod(pod: Dict[str, Any], th: Thresholds) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    name = pod.get("name", "unknown-pod")
    ns = pod.get("namespace", "default")
    res = f"pod/{ns}/{name}"
    phase = str(pod.get("phase", "Unknown"))
    ready = bool(pod.get("ready", False))
    restarts = int(pod.get("restarts", 0) or 0)
    age = pod.get("age_seconds")
    containers = pod.get("containers") or []
    container_problem = False

    def add(rule, sev, issue, rec, evidence=None):
        out.append(_finding(rule, sev, res, issue, rec, ns, evidence))

    if phase in ("Failed", "Unknown"):
        add("pod-phase", "high", f"Pod phase is {phase}.",
            "Inspect pod events and logs; check image, command, secrets, volumes, and node health.")

    for c in containers:
        cname = c.get("name", "container")
        reason = c.get("state_reason")
        last = c.get("last_terminated_reason")
        exit_code = c.get("last_exit_code")
        oom = last == "OOMKilled" or reason == "OOMKilled"
        if oom:
            container_problem = True
            limit = c.get("mem_limit")
            add("container-oomkilled", "high", f"Container '{cname}' was OOMKilled.",
                "Compare the memory limit with real usage; raise the limit if the workload legitimately needs more, "
                "otherwise look for a memory leak or unbounded cache.",
                f"memory limit: {fmt_memory(limit) if limit else 'not set'}, exit code: {exit_code}")
        if reason == "CrashLoopBackOff":
            container_problem = True
            add("container-crashloop", "high", f"Container '{cname}' is in CrashLoopBackOff.",
                "Read previous logs (`kubectl logs --previous`), check the exit code, config/secrets, "
                "and dependency availability.",
                f"last termination: {last or 'unknown'}, exit code: {exit_code}, restarts: {c.get('restarts', 0)}")
        elif reason in WAITING_IMAGE:
            container_problem = True
            add("container-image-pull", "high", f"Container '{cname}' cannot pull its image ({reason}).",
                "Verify the image name/tag exists, registry reachability, and imagePullSecrets.")
        elif reason in WAITING_CONFIG:
            container_problem = True
            add("container-config-error", "high", f"Container '{cname}' failed to start ({reason}).",
                "Check referenced ConfigMaps/Secrets/keys, volume mounts, and the container command.")

    if phase == "Pending":
        sched = pod.get("scheduling") or {}
        long_pending = age is None or age >= th.pending_seconds
        evidence = sched.get("message") or None
        if sched.get("reason") == "Unschedulable":
            add("pod-unschedulable", "high" if long_pending else "medium",
                f"Pod cannot be scheduled and has been Pending for {_human_age(age)}.",
                "Compare the pod's resource requests with node allocatable; check taints, affinity, "
                "node selectors, and PVC binding. Add capacity or lower requests if appropriate.", evidence)
        elif long_pending:
            add("pod-pending", "medium", f"Pod has been Pending for {_human_age(age)}.",
                "Check events for image pulls, volume attachment, or init containers that are slow or stuck.")
        else:
            add("pod-pending", "low", f"Pod is Pending ({_human_age(age)}); usually normal during startup.",
                "Re-check shortly; investigate if it stays Pending.")
    elif phase == "Running" and not ready and not container_problem:
        add("pod-not-ready", "medium", "Pod is not Ready.",
            "Check readiness probe, container logs, dependencies, and recent events.")

    if restarts >= th.restarts and not container_problem:
        add("pod-restarts", "medium", f"Container restart count is {restarts}.",
            "Check previous container logs, OOMKilled status, probe failures, and application errors.")

    if phase == "Running" and containers and ns not in th.ignore_namespaces:
        no_limit = [c["name"] for c in containers if c.get("mem_limit") is None]
        no_req = [c["name"] for c in containers if c.get("cpu_request_m") is None and c.get("mem_request") is None]
        if no_limit or no_req:
            parts = []
            if no_req:
                parts.append(f"no requests: {', '.join(no_req)}")
            if no_limit:
                parts.append(f"no memory limit: {', '.join(no_limit)}")
            add("pod-resource-config", "low", "Containers are missing resource requests/limits.",
                "Set requests (for scheduling) and a memory limit (to contain leaks); unbounded pods "
                "get evicted first and can starve neighbours.", "; ".join(parts))

    for c in containers:
        cname = c.get("name", "container")
        mem_p = pct(c.get("mem_usage"), c.get("mem_limit"))
        cpu_p = pct(c.get("cpu_usage_m"), c.get("cpu_limit_m"))
        if mem_p is not None and mem_p >= th.mem_limit_pct:
            add("container-memory-near-limit", "high" if mem_p >= 95 else "medium",
                f"Container '{cname}' is using {mem_p:.0f}% of its memory limit.",
                "It is close to being OOMKilled. Raise the limit or reduce memory use before it restarts.",
                f"{fmt_memory(c['mem_usage'])} of {fmt_memory(c['mem_limit'])}")
        if cpu_p is not None and cpu_p >= th.cpu_limit_pct:
            add("container-cpu-near-limit", "medium",
                f"Container '{cname}' is using {cpu_p:.0f}% of its CPU limit.",
                "It is likely being CPU-throttled, which hurts latency. Raise the CPU limit or scale out.",
                f"{fmt_cpu(c['cpu_usage_m'])} of {fmt_cpu(c['cpu_limit_m'])}")
        mem_req, mem_use = c.get("mem_request"), c.get("mem_usage")
        if mem_req and mem_use and mem_use > mem_req * 1.5 and (mem_p is None or mem_p < th.mem_limit_pct):
            add("container-under-requested", "low",
                f"Container '{cname}' uses well above its memory request.",
                "Raise the request to match real usage so the scheduler does not overcommit the node.",
                f"{fmt_memory(mem_use)} used vs {fmt_memory(mem_req)} requested")
        cpu_req, cpu_use = c.get("cpu_request_m"), c.get("cpu_usage_m")
        long_lived = age is not None and age >= th.rightsize_age_seconds
        if phase == "Running" and long_lived and cpu_req and cpu_req >= 500 and cpu_use is not None and cpu_use < cpu_req * 0.1:
            add("container-over-requested", "low",
                f"Container '{cname}' uses under 10% of its CPU request.",
                "Consider lowering the request to free schedulable capacity (check peak usage over time first).",
                f"{fmt_cpu(cpu_use)} used vs {fmt_cpu(cpu_req)} requested")
    return out


# --------------------------------------------------------------------------- node rules
def _analyze_node(node: Dict[str, Any], th: Thresholds) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    name = node.get("name", "unknown-node")
    res = f"node/{name}"
    conditions = node.get("conditions", {})
    if conditions.get("Ready") is False:
        out.append(_finding("node-not-ready", "high", res, "Node is not Ready.",
                            "Check node status, kubelet, network connectivity, disk pressure, and recent node events."))
    if conditions.get("NetworkUnavailable") is True:
        out.append(_finding("node-network", "high", res, "Node network is unavailable.",
                            "Check the CNI plugin pods and node networking configuration."))
    for condition in ("MemoryPressure", "DiskPressure", "PIDPressure"):
        if conditions.get(condition) is True:
            out.append(_finding(
                "node-pressure", "medium", res, f"Node condition {condition} is active.",
                "Review resource consumption and capacity; safely free or add capacity following operational procedures."))

    checks = (
        ("cpu", "CPU", node.get("usage_cpu_m"), node.get("requests_cpu_m"), node.get("allocatable_cpu_m"), fmt_cpu),
        ("memory", "memory", node.get("usage_mem"), node.get("requests_mem"), node.get("allocatable_mem"), fmt_memory),
    )
    for key, label, usage, requests, allocatable, fmt in checks:
        use_p, req_p = pct(usage, allocatable), pct(requests, allocatable)
        if use_p is not None and use_p >= th.node_usage_pct:
            out.append(_finding(
                f"node-{key}-usage", "high" if use_p >= 95 else "medium", res,
                f"Node {label} usage is {use_p:.0f}% of allocatable.",
                "Find the top consumers on this node; rebalance, scale out, or add capacity.",
                evidence=f"{fmt(usage)} of {fmt(allocatable)}"))
        if req_p is not None and req_p >= th.node_requests_pct:
            out.append(_finding(
                f"node-{key}-requests", "medium", res,
                f"Pods have requested {req_p:.0f}% of this node's allocatable {label}.",
                "New pods will struggle to schedule here. Add nodes or right-size over-requested workloads.",
                evidence=f"{fmt(requests)} requested of {fmt(allocatable)}"))
    return out


# --------------------------------------------------------------------------- event rules
def _analyze_events(events: List[Dict[str, Any]], th: Thresholds) -> List[Dict[str, Any]]:
    grouped: Dict[tuple, Dict[str, Any]] = {}
    for e in events:
        if e.get("type") != "Warning":
            continue
        key = (e.get("namespace", ""), e.get("object_kind", ""), e.get("object_name", ""), e.get("reason", ""))
        g = grouped.setdefault(key, {"count": 0, "message": e.get("message", "")})
        g["count"] += int(e.get("count", 1) or 1)
    out = []
    for (ns, kind, obj, reason), g in grouped.items():
        if g["count"] < th.event_count:
            continue
        hint = EVENT_HINTS.get(reason)
        resource = f"{kind.lower()}/{ns}/{obj}" if kind and ns else f"{kind.lower()}/{obj}" if kind else "cluster"
        out.append(_finding(
            "event-warning-repeated", "medium" if hint else "low", resource,
            f"Warning event '{reason}' occurred {g['count']} times.",
            hint or "Read the event message and the object's recent history.",
            ns or None, g["message"][:300] or None))
    return out



# --------------------------------------------------------------------------- history rules
def _analyze_history(snapshot: Dict[str, Any], history: Any, th: Thresholds) -> List[Dict[str, Any]]:
    """Rules that need time series: memory-leak trend and sustained node saturation."""
    out: List[Dict[str, Any]] = []
    mi = 1024 ** 2
    for pod in snapshot.get("pods", []):
        if pod.get("phase") != "Running":
            continue
        ns, name = pod.get("namespace", "default"), pod.get("name", "unknown-pod")
        trend = mem_trend([(t, m) for t, _, m in history.pod_series(ns, name)])
        if not trend or trend["r2"] < th.leak_min_r2:
            continue
        slope_mi = trend["slope_per_hour"] / mi
        if slope_mi < th.leak_min_mib_per_hour or trend["growth_pct"] < th.leak_growth_pct:
            continue
        limits = [c.get("mem_limit") for c in pod.get("containers") or []]
        limit = sum(limits) if limits and all(limits) else None
        evidence = (f"+{slope_mi:.0f}Mi/hour over {_human_age(trend['span_seconds'])} "
                    f"(now {fmt_memory(trend['current'])}, fit r\u00b2={trend['r2']:.2f})")
        severity = "medium"
        if limit:
            hours_left = max(limit - trend["current"], 0) / trend["slope_per_hour"]
            evidence += f"; projected to reach its {fmt_memory(limit)} limit in ~{hours_left:.1f}h"
            if hours_left < 6:
                severity = "high"
        else:
            severity = "low"
        out.append(_finding(
            "pod-memory-growth", severity, f"pod/{ns}/{name}",
            "Memory usage is growing steadily, which is typical of a leak or unbounded cache.",
            "Check recent deploys, heap/cache settings, and open connections; restart only as a stopgap. "
            "Set a memory limit if none exists.", ns, evidence))
    for node in snapshot.get("nodes", []):
        series = history.node_series(node.get("name", ""))
        if len(series) < th.sustained_min_samples:
            continue
        for idx, label, key in ((1, "CPU", "cpu"), (2, "memory", "mem")):
            vals = [pt[idx] for pt in series if pt[idx] is not None]
            if len(vals) < th.sustained_min_samples:
                continue
            frac = sum(v >= th.node_usage_pct for v in vals) / len(vals)
            if frac >= th.sustained_fraction:
                out.append(_finding(
                    f"node-{key}-sustained", "medium", f"node/{node.get('name')}",
                    f"Node {label} has stayed above {th.node_usage_pct:.0f}% for {frac * 100:.0f}% of the last "
                    f"{_human_age(series[-1][0] - series[0][0])}.",
                    "This is sustained pressure, not a spike: add capacity or rebalance workloads.",
                    evidence=f"{len(vals)} samples"))
    return out

# --------------------------------------------------------------------------- public API
def analyze_cluster(snapshot: Dict[str, Any], thresholds: Optional[Thresholds] = None,
                    history: Any = None) -> List[Dict[str, Any]]:
    th = thresholds or Thresholds.from_env()
    findings: List[Dict[str, Any]] = []
    for pod in snapshot.get("pods", []):
        findings.extend(_analyze_pod(pod, th))
    for node in snapshot.get("nodes", []):
        findings.extend(_analyze_node(node, th))
    findings.extend(_analyze_events(snapshot.get("events", []), th))
    if history is not None:
        findings.extend(_analyze_history(snapshot, history, th))

    if not findings:
        findings.append(_finding(
            "all-clear", "info", "cluster", "No issues were detected by the current rule set.",
            "Continue monitoring; this does not guarantee that the cluster is completely healthy."))

    metrics = snapshot.get("metrics")
    if snapshot.get("mode") == "live" and metrics and not metrics.get("available"):
        findings.append(_finding(
            "metrics-unavailable", "info", "cluster",
            "Live CPU/memory metrics are unavailable, so utilization rules were skipped.",
            metrics.get("reason") or "Install Metrics Server and allow read access to metrics.k8s.io."))

    findings.sort(key=lambda f: SEVERITY_ORDER.get(f["severity"], 9))
    return findings


def utilization_summary(snapshot: Dict[str, Any], top_n: int = 5) -> Dict[str, Any]:
    """Node utilization and top pod consumers from the snapshot's metrics."""
    metrics = snapshot.get("metrics") or {"available": False, "reason": ""}
    nodes = []
    for n in snapshot.get("nodes", []):
        alloc_cpu, alloc_mem = n.get("allocatable_cpu_m"), n.get("allocatable_mem")
        nodes.append({
            "name": n.get("name"),
            "cpu_used_m": n.get("usage_cpu_m"), "cpu_allocatable_m": alloc_cpu,
            "cpu_pct": pct(n.get("usage_cpu_m"), alloc_cpu),
            "cpu_requests_pct": pct(n.get("requests_cpu_m"), alloc_cpu),
            "mem_used": n.get("usage_mem"), "mem_allocatable": alloc_mem,
            "mem_pct": pct(n.get("usage_mem"), alloc_mem),
            "mem_requests_pct": pct(n.get("requests_mem"), alloc_mem),
            "pod_count": n.get("pod_count", 0),
        })
    pods = []
    for p in snapshot.get("pods", []):
        cs = p.get("containers") or []
        cpu = [c["cpu_usage_m"] for c in cs if c.get("cpu_usage_m") is not None]
        mem = [c["mem_usage"] for c in cs if c.get("mem_usage") is not None]
        if not cpu and not mem:
            continue
        limits = [c.get("mem_limit") for c in cs]
        mem_total = sum(mem)
        pods.append({
            "namespace": p.get("namespace"), "name": p.get("name"),
            "cpu_m": sum(cpu), "mem": mem_total,
            "mem_limit_pct": pct(mem_total, sum(limits)) if limits and all(limits) else None,
        })
    return {
        "metrics_available": bool(metrics.get("available")),
        "reason": metrics.get("reason", ""),
        "nodes": nodes,
        "top_cpu_pods": sorted(pods, key=lambda x: x["cpu_m"], reverse=True)[:top_n],
        "top_memory_pods": sorted(pods, key=lambda x: x["mem"], reverse=True)[:top_n],
    }


def _is_problem_pod(p: Dict[str, Any], restarts_threshold: int = 5) -> bool:
    phase = p.get("phase")
    if phase == "Succeeded":
        return False
    return (phase != "Running" or not p.get("ready", False)
            or int(p.get("restarts", 0) or 0) >= restarts_threshold)


def _describe_pod_line(p: Dict[str, Any]) -> str:
    return (f"{p.get('namespace', 'default')}/{p.get('name', 'unknown')} "
            f"(phase={p.get('phase', 'Unknown')}, ready={p.get('ready', False)}, restarts={p.get('restarts', 0)})")


def _word(q: str, *words: str) -> bool:
    return any(re.search(rf"\b{w}", q) for w in words)


def answer_question(question: str, snapshot: Dict[str, Any], history: Any = None) -> str:
    q = question.lower()
    pods = snapshot.get("pods", [])
    nodes = snapshot.get("nodes", [])
    th = Thresholds.from_env()

    # 1. A specific pod was named: explain just that pod.
    for p in pods:
        pname = str(p.get("name", "")).lower()
        if pname and pname in q:
            res = f"pod/{p.get('namespace', 'default')}/{p.get('name')}"
            related = [f for f in analyze_cluster(snapshot, th, history) if f["resource"] == res]
            lines = [f"{_describe_pod_line(p)}, node={p.get('node') or 'unscheduled'}."]
            for c in p.get("containers") or []:
                if c.get("mem_usage") is not None:
                    lines.append(
                        f"Container '{c['name']}': CPU {fmt_cpu(c.get('cpu_usage_m'))} (limit {fmt_cpu(c.get('cpu_limit_m')) if c.get('cpu_limit_m') else 'none'}), "
                        f"memory {fmt_memory(c['mem_usage'])} (limit {fmt_memory(c['mem_limit']) if c.get('mem_limit') else 'none'}).")
            if related:
                lines.extend(f"[{f['severity'].upper()}] {f['issue']} {f['recommendation']}"
                             + (f" ({f['evidence']})" if f.get("evidence") else "") for f in related)
            else:
                lines.append("No rules fired for this pod.")
            return " ".join(lines)

    # 2. Specific intents.
    if _word(q, "leak", "trend", "growing", "growth"):
        hits = [f for f in analyze_cluster(snapshot, th, history) if f["rule"] in ("pod-memory-growth", "node-cpu-sustained", "node-memory-sustained")]
        if not hits:
            return "No steady memory growth or sustained node saturation was found in the collected history."
        return "Trends: " + "; ".join(f"{f['resource']}: {f['issue']} ({f['evidence']})" for f in hits[:10])
    if _word(q, "oom", "out of memory", "killed"):
        hits = [f for f in analyze_cluster(snapshot, th, history) if f["rule"] in ("container-oomkilled", "container-memory-near-limit")]
        if not hits:
            return "No OOMKilled containers or containers near their memory limit were found in this snapshot."
        return "Memory problems: " + "; ".join(f"{f['resource']}: {f['issue']} ({f['evidence']})" for f in hits[:10]) + \
            ". Next: compare limits with real usage before raising them."
    if _word(q, "pending", "schedul", "unschedulable"):
        hits = [f for f in analyze_cluster(snapshot, th, history) if f["rule"] in ("pod-unschedulable", "pod-pending")]
        if not hits:
            return "No Pending or unschedulable pods were found in this snapshot."
        return "Pending pods: " + "; ".join(
            f"{f['resource']}: {f['issue']}" + (f" ({f['evidence']})" if f.get("evidence") else "") for f in hits[:10])
    if _word(q, "event", "warning"):
        hits = [f for f in analyze_cluster(snapshot, th, history) if f["rule"] == "event-warning-repeated"]
        if not hits:
            return "No repeated Warning events were found in the recent event window."
        return "Repeated warnings: " + "; ".join(f"{f['resource']}: {f['issue']}" for f in hits[:10])
    if _word(q, "headroom", "capacity", "request", "allocat"):
        s = utilization_summary(snapshot)
        if not s["nodes"]:
            return "No node data is available."
        return "Scheduling headroom (requested vs allocatable): " + "; ".join(
            f"{n['name']}: CPU {n['cpu_requests_pct']}%, memory {n['mem_requests_pct']}%" for n in s["nodes"])
    if _word(q, "cpu", "memory", "ram", "usage", "utili", "resource", "consum", "hungry", r"top\b", "busiest"):
        s = utilization_summary(snapshot)
        if not s["metrics_available"]:
            return ("Live utilization is unavailable. " + (s["reason"] or "Metrics Server is not reachable.")
                    + " Install Metrics Server and verify `kubectl top nodes` works.")
        node_txt = "; ".join(
            f"{n['name']}: CPU {n['cpu_pct']}%, memory {n['mem_pct']}%" for n in s["nodes"]) or "no node metrics"
        cpu_txt = ", ".join(f"{p['namespace']}/{p['name']} ({fmt_cpu(p['cpu_m'])})" for p in s["top_cpu_pods"]) or "none"
        mem_txt = ", ".join(f"{p['namespace']}/{p['name']} ({fmt_memory(p['mem'])})" for p in s["top_memory_pods"]) or "none"
        return f"Node utilization: {node_txt}. Top CPU pods: {cpu_txt}. Top memory pods: {mem_txt}."

    # 3. Original broad intents.
    if _word(q, "pod", "restart", "crash", "unhealthy"):
        if not pods:
            return "No pod data is available. Check Kubernetes connectivity and RBAC permissions."
        problem_pods = [p for p in pods if _is_problem_pod(p, th.restarts)]
        if not problem_pods:
            return f"{len(pods)} pods were returned; none matched the assistant's basic pod-warning rules."
        return "Pods to inspect: " + "; ".join(_describe_pod_line(p) for p in problem_pods[:10]) + \
            ". Next: inspect events and logs before changing workloads."
    if _word(q, "node", "worker"):
        not_ready = [n.get("name", "unknown") for n in nodes if n.get("conditions", {}).get("Ready") is False]
        return (f"Nodes reported: {len(nodes)}. Not-Ready nodes: "
                f"{', '.join(not_ready) if not_ready else 'none detected by this snapshot'}.")
    findings = analyze_cluster(snapshot, th, history)
    return (f"I reviewed the available cluster snapshot and found {len(findings)} diagnostic item(s). "
            "Ask about pods, nodes, CPU/memory usage, OOM kills, pending pods, events, or name a specific pod.")
