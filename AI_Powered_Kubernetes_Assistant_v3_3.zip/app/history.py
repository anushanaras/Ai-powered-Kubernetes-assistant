"""In-memory metric history, trend math, and sparklines (no external dependencies)."""
from collections import deque
from threading import RLock
from typing import Any, Deque, Dict, List, Optional, Tuple
import math
import threading
import time

from app.units import pct

MI = 1024 ** 2
NodePoint = Tuple[float, Optional[float], Optional[float]]   # ts, cpu%, mem%
PodPoint = Tuple[float, float, float]                        # ts, cpu millicores, memory bytes


class History:
    def __init__(self, max_points: int = 720):
        self.max_points = max_points
        self._lock = RLock()
        self._nodes: Dict[str, Deque[NodePoint]] = {}
        self._pods: Dict[Tuple[str, str], Deque[PodPoint]] = {}

    def record(self, snapshot: Dict[str, Any], ts: Optional[float] = None) -> bool:
        """Append one sample. Returns False when the snapshot has no usable metrics."""
        if snapshot.get("mode") not in ("live", "demo") or not (snapshot.get("metrics") or {}).get("available"):
            return False
        ts = time.time() if ts is None else ts
        with self._lock:
            seen_nodes, seen_pods = set(), set()
            for n in snapshot.get("nodes", []):
                if n.get("usage_cpu_m") is None:
                    continue
                name = n["name"]
                seen_nodes.add(name)
                self._nodes.setdefault(name, deque(maxlen=self.max_points)).append(
                    (ts, pct(n["usage_cpu_m"], n.get("allocatable_cpu_m")),
                     pct(n.get("usage_mem"), n.get("allocatable_mem"))))
            for p in snapshot.get("pods", []):
                cs = [c for c in (p.get("containers") or []) if c.get("mem_usage") is not None]
                if not cs:
                    continue
                key = (p.get("namespace", ""), p.get("name", ""))
                seen_pods.add(key)
                self._pods.setdefault(key, deque(maxlen=self.max_points)).append(
                    (ts, sum(c.get("cpu_usage_m") or 0.0 for c in cs), sum(c["mem_usage"] for c in cs)))
            for k in [k for k in self._nodes if k not in seen_nodes]:
                del self._nodes[k]
            for k in [k for k in self._pods if k not in seen_pods]:
                del self._pods[k]
        return True

    def node_series(self, name: str) -> List[NodePoint]:
        with self._lock:
            return list(self._nodes.get(name, ()))

    def pod_series(self, namespace: str, name: str) -> List[PodPoint]:
        with self._lock:
            return list(self._pods.get((namespace, name), ()))

    def node_names(self) -> List[str]:
        with self._lock:
            return sorted(self._nodes)

    def sample_count(self) -> int:
        with self._lock:
            return max((len(v) for v in self._nodes.values()), default=0)


def mem_trend(points: List[Tuple[float, float]], min_points: int = 10,
              min_span_seconds: float = 600) -> Optional[Dict[str, float]]:
    """Least-squares trend of (timestamp, bytes). Ignores data before the last restart-style drop."""
    start = 0
    for i in range(1, len(points)):
        if points[i][1] < points[i - 1][1] * 0.7:
            start = i
    pts = points[start:]
    if len(pts) < min_points or pts[-1][0] - pts[0][0] < min_span_seconds:
        return None
    t0 = pts[0][0]
    xs = [(t - t0) / 3600.0 for t, _ in pts]
    ys = [v for _, v in pts]
    n = len(pts)
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    if sxx == 0:
        return None
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx
    intercept = my - slope * mx
    ss_tot = sum((y - my) ** 2 for y in ys)
    ss_res = sum((y - (intercept + slope * x)) ** 2 for x, y in zip(xs, ys))
    r2 = 1.0 - ss_res / ss_tot if ss_tot else 0.0
    first_fit = intercept
    growth_pct = (slope * xs[-1]) / max(first_fit, 1.0) * 100
    return {"slope_per_hour": slope, "r2": r2, "growth_pct": growth_pct,
            "span_seconds": pts[-1][0] - pts[0][0], "current": ys[-1]}


def sparkline_points(values: List[Optional[float]], width: int = 120, height: int = 28,
                     vmin: float = 0.0, vmax: Optional[float] = None) -> str:
    """SVG polyline points for a series; None values are skipped."""
    vals = [v for v in values if v is not None]
    if len(vals) < 2:
        return ""
    hi = vmax if vmax is not None else max(vals)
    hi = hi if hi > vmin else vmin + 1
    step = width / (len(vals) - 1)
    pts = []
    for i, v in enumerate(vals):
        y = height - (min(max(v, vmin), hi) - vmin) / (hi - vmin) * height
        pts.append(f"{i * step:.1f},{y:.1f}")
    return " ".join(pts)


class Sampler:
    """Background thread that records a snapshot every `interval` seconds."""

    def __init__(self, history: History, get_snapshot, interval: float = 60.0):
        self.history, self.get_snapshot, self.interval = history, get_snapshot, interval
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="history-sampler", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self.history.record(self.get_snapshot())
            except Exception:  # noqa: BLE001 - sampling must never crash the app
                pass
            self._stop.wait(self.interval)


def seed_demo_history(history: History, snapshot: Dict[str, Any], now: Optional[float] = None,
                      points: int = 120, step: float = 60.0) -> None:
    """Give demo mode two hours of plausible history so charts and trend rules have something to show."""
    now = time.time() if now is None else now
    for i in range(points):
        frac = i / (points - 1)
        ts = now - (points - 1 - i) * step
        snap = {"mode": "demo", "metrics": {"available": True}, "nodes": [], "pods": []}
        for n in snapshot.get("nodes", []):
            wobble = math.sin(i / 7.0 + len(n["name"]))
            cpu = n["usage_cpu_m"] * (1 + 0.12 * wobble)
            mem = n["usage_mem"] * (1 + 0.015 * wobble)
            snap["nodes"].append({**n, "usage_cpu_m": cpu, "usage_mem": mem})
        for p in snapshot.get("pods", []):
            cs = []
            for c in p.get("containers", []):
                if c.get("mem_usage") is None:
                    continue
                mem = c["mem_usage"]
                if p["name"].startswith("report-gen"):   # a slow leak: 300Mi -> current over 2h
                    mem = 300 * MI + (c["mem_usage"] - 300 * MI) * frac + 2 * MI * math.sin(i)
                cs.append({**c, "mem_usage": mem})
            if cs:
                snap["pods"].append({**p, "containers": cs})
        history.record(snap, ts)
