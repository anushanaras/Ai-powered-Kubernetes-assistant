"""Prometheus as a long-term history backend (optional).

With PROMETHEUS_URL set, /api/history/* is answered from Prometheus (container_* from cAdvisor,
node via node-exporter or kube-state/cAdvisor) instead of the in-process ring buffer, so history
survives restarts and is the same on every replica. The HTTP transport is injectable for tests.

Env: PROMETHEUS_URL, PROMETHEUS_TOKEN (bearer, optional), PROMETHEUS_CLUSTER_LABEL (default "cluster",
used to select one cluster's series in a multi-cluster Prometheus such as Thanos/Mimir),
PROMETHEUS_TIMEOUT (seconds, default 10).
"""
from typing import Any, Callable, Dict, List, Optional, Tuple
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request

_LABEL_VALUE_RE = re.compile(r'[A-Za-z0-9._:/-]{1,253}')


class PromError(Exception):
    pass


def _lv(value: str) -> str:
    """Validate a value before interpolating it into PromQL (prevents query injection)."""
    if not _LABEL_VALUE_RE.fullmatch(value):   # fullmatch: `$` would accept a trailing newline
        raise PromError("invalid label value")
    return value


def _default_get(url: str, headers: Dict[str, str], timeout: float) -> Dict[str, Any]:
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 - operator-configured URL
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        raise PromError(f"Prometheus returned HTTP {exc.code}") from None
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
        raise PromError(f"Prometheus request failed ({type(exc).__name__})") from None


class PrometheusClient:
    def __init__(self, base_url: str, token: str = "", cluster_label: str = "cluster",
                 timeout: float = 10.0, get: Optional[Callable[..., Dict[str, Any]]] = None):
        self.base_url = base_url.rstrip("/")
        self.token, self.cluster_label, self.timeout = token, cluster_label, timeout
        self._get = get or _default_get

    @classmethod
    def from_env(cls) -> Optional["PrometheusClient"]:
        url = os.getenv("PROMETHEUS_URL", "").strip()
        if not url:
            return None
        return cls(url, os.getenv("PROMETHEUS_TOKEN", "").strip(),
                   os.getenv("PROMETHEUS_CLUSTER_LABEL", "cluster").strip() or "cluster",
                   float(os.getenv("PROMETHEUS_TIMEOUT", "10")))

    def query_range(self, promql: str, start: float, end: float, step: int) -> List[Dict[str, Any]]:
        params = urllib.parse.urlencode({"query": promql, "start": f"{start:.3f}", "end": f"{end:.3f}", "step": step})
        headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
        data = self._get(f"{self.base_url}/api/v1/query_range?{params}", headers, self.timeout)
        if data.get("status") != "success":
            raise PromError("Prometheus query failed")
        return data.get("data", {}).get("result", [])

    def _sel(self, cluster: Optional[str], extra: str = "") -> str:
        parts = [extra] if extra else []
        if cluster:
            parts.append(f'{self.cluster_label}="{_lv(cluster)}"')
        return "{" + ",".join(parts) + "}"

    # ---- queries ---------------------------------------------------------------------------
    def pod_memory(self, cluster: Optional[str], namespace: str, pod: str, start: float, end: float,
                   step: int = 60) -> List[Tuple[float, float]]:
        sel = self._sel(cluster, f'namespace="{_lv(namespace)}",pod="{_lv(pod)}",container!="",container!="POD"')
        result = self.query_range(f"sum(container_memory_working_set_bytes{sel})", start, end, step)
        return _points(result)

    def pod_cpu_millicores(self, cluster: Optional[str], namespace: str, pod: str, start: float, end: float,
                           step: int = 60) -> List[Tuple[float, float]]:
        sel = self._sel(cluster, f'namespace="{_lv(namespace)}",pod="{_lv(pod)}",container!="",container!="POD"')
        result = self.query_range(f"sum(rate(container_cpu_usage_seconds_total{sel}[5m])) * 1000", start, end, step)
        return _points(result)

    def node_utilization(self, cluster: Optional[str], start: float, end: float,
                         step: int = 60) -> Dict[str, Dict[str, List[Tuple[float, float]]]]:
        """Per-node CPU% and memory% from node-exporter metrics."""
        sel = self._sel(cluster)
        cpu_sel = self._sel(cluster, 'mode="idle"')
        cpu = self.query_range(f"100 - 100 * avg by (instance) (rate(node_cpu_seconds_total{cpu_sel}[5m]))", start, end, step)
        mem = self.query_range(
            f"100 * (1 - node_memory_MemAvailable_bytes{sel} / node_memory_MemTotal_bytes{sel})", start, end, step)
        out: Dict[str, Dict[str, List[Tuple[float, float]]]] = {}
        for kind, result in (("cpu_pct", cpu), ("mem_pct", mem)):
            for series in result:
                node = series.get("metric", {}).get("instance", "unknown").split(":")[0]
                out.setdefault(node, {})[kind] = _points([series])
        return out


def _points(result: List[Dict[str, Any]]) -> List[Tuple[float, float]]:
    pts: List[Tuple[float, float]] = []
    for series in result[:1]:
        for ts, val in series.get("values", []):
            try:
                f = float(val)
            except (TypeError, ValueError):
                continue
            if f == f and f not in (float("inf"), float("-inf")):   # drop NaN/Inf
                pts.append((float(ts), f))
    return pts
