"""Authentication: OIDC JWT bearer tokens (SSO) and static API keys for automation.

SSO model: users sign in through your identity provider (Okta, Entra ID, Keycloak, Google, ...),
typically via an authenticating proxy such as oauth2-proxy or your ingress, which forwards the
user's ID/access token as `Authorization: Bearer <jwt>` (or `X-Forwarded-Access-Token`).
This service independently VERIFIES that token (signature via the IdP's JWKS, issuer, audience,
expiry) and never trusts bare identity headers.

Env:
  OIDC_ISSUER        e.g. https://login.example.com/realms/corp   (enables SSO)
  OIDC_AUDIENCE      expected `aud` (your client id)
  OIDC_JWKS_URI      optional; defaults to <issuer>/.well-known/jwks.json
  OIDC_GROUPS_CLAIM  default "groups"
  OIDC_ALGORITHMS    default "RS256,ES256"
  API_KEYS_FILE      optional JSON/YAML: {"keys": [{"name": "ci", "sha256": "<hex>", "groups": ["platform-admins"]}]}
  API_KEY            legacy single key; treated as an admin principal (v2.0 compatibility)
"""
from typing import Any, Callable, Dict, List, Mapping, Optional
import hashlib
import hmac
import json
import os

from app.authz import Principal
from app.security import extract_credential


class AuthError(Exception):
    """Raised for any failed authentication; message is safe to log, never to return verbatim."""


def sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


class ApiKeyStore:
    """Static API keys stored only as SHA-256 digests (generate with: printf %s "$KEY" | sha256sum)."""

    def __init__(self, entries: List[Dict[str, Any]], legacy_key: str = ""):
        self._entries = [{"name": str(e["name"]), "sha256": str(e["sha256"]).lower(),
                          "groups": frozenset(e.get("groups", []))} for e in entries]
        self._legacy = legacy_key

    @classmethod
    def from_env(cls) -> "ApiKeyStore":
        entries: List[Dict[str, Any]] = []
        path = os.getenv("API_KEYS_FILE", "").strip()
        if path:
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    text = fh.read()
            except FileNotFoundError:
                text = ""          # e.g. an optional Secret key that was not provisioned: no keys, and still no anonymous access
            if text.strip():
                if path.endswith(".json"):
                    data = json.loads(text)
                else:
                    import yaml
                    data = yaml.safe_load(text) or {}
                entries = data.get("keys", [])
        return cls(entries, os.getenv("API_KEY", "").strip())

    @property
    def enabled(self) -> bool:
        return bool(self._entries or self._legacy)

    def authenticate(self, credential: str) -> Optional[Principal]:
        digest = sha256_hex(credential)
        for e in self._entries:                       # compare every entry: no early-exit timing signal
            if hmac.compare_digest(digest, e["sha256"]):
                return Principal(subject=f"apikey:{e['name']}", groups=e["groups"], auth_method="api-key")
        if self._legacy and hmac.compare_digest(credential.encode(), self._legacy.encode()):
            return Principal(subject="apikey:legacy", groups=frozenset({"__legacy_admin__"}), auth_method="api-key")
        return None


class OidcValidator:
    """Verifies JWTs. `key_resolver(token) -> key` is injectable so tests need no network."""

    def __init__(self, issuer: str, audience: str, groups_claim: str = "groups",
                 algorithms: Optional[List[str]] = None, jwks_uri: str = "",
                 key_resolver: Optional[Callable[[str], Any]] = None, leeway: int = 30):
        if not issuer or not audience:
            raise ValueError("OIDC requires both an issuer and an audience.")
        self.issuer, self.audience, self.groups_claim = issuer.rstrip("/"), audience, groups_claim
        self.algorithms = algorithms or ["RS256", "ES256"]
        if any(a.lower().startswith("hs") or a.lower() == "none" for a in self.algorithms):
            raise ValueError("Symmetric/none algorithms are not allowed for OIDC validation.")
        self.leeway = leeway
        if key_resolver is None:
            import jwt
            client = jwt.PyJWKClient(jwks_uri or f"{self.issuer}/.well-known/jwks.json", cache_keys=True, lifespan=3600)
            key_resolver = lambda token: client.get_signing_key_from_jwt(token).key  # noqa: E731
        self._resolve_key = key_resolver

    @classmethod
    def from_env(cls) -> Optional["OidcValidator"]:
        issuer = os.getenv("OIDC_ISSUER", "").strip()
        if not issuer:
            return None
        return cls(issuer, os.getenv("OIDC_AUDIENCE", "").strip(),
                   groups_claim=os.getenv("OIDC_GROUPS_CLAIM", "groups").strip() or "groups",
                   algorithms=[a.strip() for a in os.getenv("OIDC_ALGORITHMS", "RS256,ES256").split(",") if a.strip()],
                   jwks_uri=os.getenv("OIDC_JWKS_URI", "").strip())

    def validate(self, token: str) -> Principal:
        import jwt
        try:
            key = self._resolve_key(token)
            claims = jwt.decode(token, key=key, algorithms=self.algorithms, audience=self.audience,
                                issuer=self.issuer, leeway=self.leeway,
                                options={"require": ["exp", "iss", "aud", "sub"]})
        except Exception as exc:  # noqa: BLE001 - any failure is a failed login
            raise AuthError(f"token rejected: {type(exc).__name__}") from None
        raw_groups = claims.get(self.groups_claim, [])
        if isinstance(raw_groups, str):
            raw_groups = [raw_groups]
        groups = frozenset(str(g) for g in raw_groups) if isinstance(raw_groups, list) else frozenset()
        return Principal(subject=str(claims["sub"]), email=str(claims.get("email", "")),
                         groups=groups, auth_method="oidc")


def looks_like_jwt(value: str) -> bool:
    parts = value.split(".")
    return len(parts) == 3 and all(parts)


class Authenticator:
    def __init__(self, keys: ApiKeyStore, oidc: Optional[OidcValidator], anonymous_allowed: bool = False):
        self.keys, self.oidc, self.anonymous_allowed = keys, oidc, anonymous_allowed

    @property
    def enabled(self) -> bool:
        return bool(self.oidc or self.keys.enabled)

    def authenticate(self, headers: Mapping[str, str]) -> Principal:
        lower = {k.lower(): v for k, v in headers.items()}
        cred = extract_credential(headers) or lower.get("x-forwarded-access-token", "").strip() or None
        if cred is None:
            if self.anonymous_allowed:
                return Principal(subject="anonymous", groups=frozenset({"__anonymous__"}), auth_method="anonymous")
            raise AuthError("no credential")
        if self.oidc and looks_like_jwt(cred):
            return self.oidc.validate(cred)
        principal = self.keys.authenticate(cred)
        if principal is None:
            raise AuthError("unknown credential")
        return principal
