"""Multi-cluster registry.

Configured via CLUSTERS_CONFIG (path to a YAML/JSON file):

    clusters:
      - name: prod-eu
        kubeconfig: /etc/clusters/prod-eu.kubeconfig   # omit for in-cluster
        context: prod-eu                                # optional
      - name: local
        in_cluster: true

With no file configured there is exactly one cluster named "local" (in-cluster or default kubeconfig),
which keeps v2.0 single-cluster deployments working unchanged.
"""
from dataclasses import dataclass
from typing import Dict, List, Optional
import json
import os

DEFAULT_CLUSTER = "local"


@dataclass(frozen=True)
class ClusterConfig:
    name: str
    kubeconfig: Optional[str] = None
    context: Optional[str] = None
    in_cluster: bool = False


class ClusterRegistry:
    def __init__(self, clusters: List[ClusterConfig]):
        if not clusters:
            raise ValueError("At least one cluster must be configured.")
        names = [c.name for c in clusters]
        if len(set(names)) != len(names):
            raise ValueError("Cluster names must be unique.")
        self._clusters: Dict[str, ClusterConfig] = {c.name: c for c in clusters}
        self.default = clusters[0].name

    def names(self) -> List[str]:
        return list(self._clusters)

    def get(self, name: Optional[str]) -> ClusterConfig:
        key = name or self.default
        if key not in self._clusters:
            raise KeyError(key)
        return self._clusters[key]

    def __contains__(self, name: str) -> bool:
        return name in self._clusters


def _load_file(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        text = fh.read()
    if path.endswith(".json"):
        return json.loads(text)
    import yaml  # PyYAML; only needed for YAML files
    return yaml.safe_load(text) or {}


def parse_clusters(data: dict) -> List[ClusterConfig]:
    out = []
    for item in data.get("clusters", []):
        name = str(item.get("name", "")).strip()
        if not name or len(name) > 63 or not all(ch.isalnum() or ch in "-_." for ch in name):
            raise ValueError(f"Invalid cluster name: {name!r}")
        out.append(ClusterConfig(name=name, kubeconfig=item.get("kubeconfig"),
                                 context=item.get("context"), in_cluster=bool(item.get("in_cluster", False))))
    return out


def load_registry(path: Optional[str] = None) -> ClusterRegistry:
    path = path if path is not None else os.getenv("CLUSTERS_CONFIG", "").strip()
    if not path:
        return ClusterRegistry([ClusterConfig(DEFAULT_CLUSTER)])
    return ClusterRegistry(parse_clusters(_load_file(path)))
