"""Troubleshooting recommendations: a rules-based playbook, optionally upgraded by Claude (read-only advice only)."""
from typing import Any, Dict, List, Optional, Tuple

from app.llm import LLMClient, LLMError, build_context, sanitize
from app.logs import ai_signals

PLAYBOOK: List[Tuple[Tuple[str, ...], str, List[str]]] = [
    (("crashloopbackoff", "crash loop", "keeps restarting", "restarting"), "CrashLoopBackOff", [
        "Check the pod logs for the crash reason: kubectl logs <pod> --previous",
        "Look at the exit code and reason: kubectl describe pod <pod> (137 = killed/OOM, 1 = app error).",
        "Verify the image exists in the container registry and the tag is correct.",
        "Check for misconfigured environment variables, missing ConfigMaps or Secrets.",
        "Ensure the resource limits are sufficient and liveness probes are not too aggressive."]),
    (("imagepullbackoff", "errimagepull", "image pull", "pull image"), "ImagePullBackOff", [
        "Check the exact error: kubectl describe pod <pod> (see Events).",
        "Verify the image name and tag exist in the registry.",
        "If the registry is private, confirm imagePullSecrets is set and the secret is valid in this namespace.",
        "Check the node can reach the registry (network, proxy, rate limits)."]),
    (("oomkilled", "out of memory", "oom", "memory limit", "exit code 137"), "OOMKilled", [
        "Confirm: kubectl describe pod <pod> shows Last State Terminated, Reason OOMKilled.",
        "Compare actual usage (kubectl top pod) with the memory limit.",
        "If usage grows steadily over time it is a leak or unbounded cache; fix the application.",
        "If usage is legitimately high, raise the limit and request together, keeping node capacity in mind."]),
    (("pending", "unschedulable", "failedscheduling", "not scheduled", "insufficient"), "Pending / FailedScheduling", [
        "Read the scheduler message: kubectl describe pod <pod> (Events).",
        "Check requested CPU/memory against free node capacity: kubectl describe nodes.",
        "Check nodeSelector, affinity, taints/tolerations and PersistentVolumeClaims.",
        "Add capacity, lower the requests, or fix the scheduling constraints."]),
    (("evicted", "eviction", "diskpressure", "memorypressure", "node pressure"), "Eviction / node pressure", [
        "Find the node: kubectl get pod <pod> -o wide, then kubectl describe node <node>.",
        "Check MemoryPressure/DiskPressure conditions and what is consuming the resource.",
        "Set realistic requests/limits so the scheduler spreads load; clean up logs and images on the node."]),
    (("notready", "node not ready", "node down"), "Node NotReady", [
        "kubectl describe node <node> and read the Conditions and Events.",
        "Check kubelet status and logs on the node, plus disk, memory and network health.",
        "If the node is unrecoverable, cordon and drain it, then replace it."]),
    (("readiness", "liveness", "probe failed", "probe"), "Probe failures", [
        "kubectl describe pod <pod> shows which probe fails and the response.",
        "Make sure the probe path and port are correct and the app starts within initialDelaySeconds.",
        "Consider a startupProbe for slow starters and relax timeouts that are too strict."]),
    (("createcontainerconfigerror", "configmap", "secret not found", "env var"), "Configuration error", [
        "kubectl describe pod <pod> names the missing ConfigMap, Secret or key.",
        "Confirm the object exists in the same namespace and the key name matches exactly.",
        "Check recent changes to the Deployment manifest or Helm values."]),
    (("dns", "no such host", "name resolution", "nxdomain"), "DNS problems", [
        "Check CoreDNS pods and logs: kubectl -n kube-system get pods -l k8s-app=kube-dns.",
        "From a debug pod, test resolution of the service name; check namespace spelling.",
        "Check NetworkPolicies that may block UDP/TCP 53."]),
    (("timeout", "timed out", "slow", "latency", "connection refused", "unreachable", "502", "503", "504"), "Connectivity / latency", [
        "Check that the Service has ready endpoints: kubectl get endpoints <svc>.",
        "Verify ports and selectors match the pods; check NetworkPolicies and ingress rules.",
        "Look for CPU throttling or saturation on the callee; compare with recent deployments."]),
]
GENERIC = [
    "Check the pod logs for error details: kubectl logs <pod> (add --previous after a restart).",
    "Run kubectl describe pod <pod> and read the Events at the bottom.",
    "Verify the image exists in the container registry and can be pulled.",
    "Ensure the resource requests/limits are sufficient and the node has capacity.",
    "Check for misconfigured environment variables, ConfigMaps and Secrets.",
]


def rules_recommendation(issue: str) -> Dict[str, Any]:
    text = (issue or "").lower()
    matched, steps = [], []
    for keys, title, plan in PLAYBOOK:
        if any(k in text for k in keys):
            matched.append(title)
            steps += [s for s in plan if s not in steps]
    if not matched:
        steps = list(GENERIC)
    return {"matched": matched, "steps": steps[:8], "source": "rules"}


def related_findings(issue: str, findings: List[Dict[str, Any]], limit: int = 5) -> List[Dict[str, Any]]:
    """Live findings whose pod/node name is mentioned in the description (e.g. 'api-55cc9f is crashing')."""
    text = (issue or "").lower()
    hits = []
    for f in findings:
        name = f["resource"].split("/")[-1].lower()
        if len(name) >= 4 and name in text:
            hits.append(f)
    return hits[:limit]


def recommend(issue: str, snapshot: Dict[str, Any], findings: List[Dict[str, Any]], usage: Dict[str, Any],
              llm: Optional[LLMClient] = None, log_analysis: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Return {steps|text, matched, related, source, note}. Claude is used only if configured; any failure falls back to rules."""
    base = rules_recommendation(issue)
    base["related"] = related_findings(issue, findings)
    base["note"] = None
    if llm is None:
        return base
    ctx = build_context(snapshot, findings, usage)
    if log_analysis:
        ctx["log_signals"] = ai_signals(log_analysis)           # redacted, capped; never raw logs
    try:
        base["text"] = llm.ask("Troubleshooting request. Give a likely root cause, then numbered read-only diagnostic steps. "
                               "Problem as described by the operator: " + sanitize(issue, 500), ctx)
        base["source"] = "llm"
    except LLMError as exc:
        base["note"] = f"Claude unavailable ({exc}); showing the built-in playbook."
    return base
