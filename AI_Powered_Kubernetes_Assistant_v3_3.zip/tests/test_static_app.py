"""Guards for the installable app's static assets (no browser needed)."""
import json
import pathlib
import struct

STATIC = pathlib.Path(__file__).resolve().parents[1] / "app" / "static"


def png_size(path):
    data = path.read_bytes()
    assert data[:8] == b"\x89PNG\r\n\x1a\n"
    return struct.unpack(">II", data[16:24])


def test_manifest_is_installable():
    m = json.loads((STATIC / "manifest.webmanifest").read_text())
    assert m["display"] == "standalone" and m["start_url"].startswith(m["scope"])
    sizes = {i["sizes"] for i in m["icons"]}
    assert {"192x192", "512x512"} <= sizes and any(i.get("purpose") == "maskable" for i in m["icons"])
    for icon in m["icons"]:
        assert (STATIC / icon["src"].replace("/app/", "", 1)).is_file(), icon["src"]


def test_icons_have_declared_sizes():
    assert png_size(STATIC / "icons/icon-192.png") == (192, 192)
    assert png_size(STATIC / "icons/icon-512.png") == (512, 512)
    assert png_size(STATIC / "icons/icon-maskable-512.png") == (512, 512)
    assert png_size(STATIC / "icons/apple-touch-icon.png") == (180, 180)


def test_service_worker_never_caches_data():
    sw = (STATIC / "sw.js").read_text()
    assert "startsWith('/app/')" in sw and "'GET'" in sw          # only same-origin GETs under /app/
    assert "/api" not in sw.replace("/app/", "")                  # no API paths are ever cached


def test_ui_code_never_uses_dangerous_sinks():
    for name in ("app.js", "lib.js", "index.html"):
        text = (STATIC / name).read_text()
        for sink in ("innerHTML", "outerHTML", "insertAdjacentHTML", "document.write", "eval(", "new Function"):
            assert sink not in text, f"{name} uses {sink}"
    html = (STATIC / "index.html").read_text()
    assert "<script>" not in html and " style=" not in html and "onclick=" not in html   # compatible with the strict CSP


def test_shell_files_listed_in_service_worker_exist():
    import re
    sw = (STATIC / "sw.js").read_text()
    for path in re.findall(r"'(/app/[^']*)'", sw):
        rel = path.replace("/app/", "", 1) or "index.html"
        assert (STATIC / (rel or "index.html")).exists() or path == "/app/", path
