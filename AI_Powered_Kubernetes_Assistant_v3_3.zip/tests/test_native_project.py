"""Static guards for the native project sources (no Rust/Android/Xcode needed)."""
import json
import pathlib
import re

NATIVE = pathlib.Path(__file__).resolve().parents[1] / "native"
TAURI = NATIVE / "desktop" / "src-tauri"


def test_tauri_config_is_consistent_and_locked_down():
    conf = json.loads((TAURI / "tauri.conf.json").read_text())
    assert conf["app"]["windows"] == []                                  # window is created in Rust with the navigation guard
    for icon in conf["bundle"]["icon"]:
        assert (TAURI / icon).is_file(), icon
    assert (TAURI / conf["build"]["frontendDist"] / "index.html").resolve().is_file()
    csp = conf["app"]["security"]["csp"]
    assert "script-src 'self'" in csp and "unsafe-eval" not in csp and "unsafe-inline" not in csp.split("script-src")[1].split(";")[0]


def test_no_native_permissions_are_granted_to_any_page():
    cap = json.loads((TAURI / "capabilities" / "default.json").read_text())
    assert cap["permissions"] == [] and "remote" not in cap            # no IPC for remote origins, none for the launcher either


def test_rust_navigation_guard_present_and_tested():
    lib = (TAURI / "src" / "lib.rs").read_text()
    assert ".on_navigation(" in lib and "fn allow_navigation" in lib
    for scheme in ("file:///", "data:", "javascript:"):
        assert re.search(r"assert!\(!ok\(\"" + re.escape(scheme), lib), f"missing refusal test for {scheme}"
    assert "invoke_handler" not in lib                                  # no custom commands exposed to web content


def test_launcher_has_no_dangerous_sinks_and_is_csp_clean():
    for name in ("launcher.js", "launcher-lib.js", "index.html"):
        text = (NATIVE / "launcher" / name).read_text()
        for sink in ("innerHTML", "outerHTML", "document.write", "eval(", "new Function"):
            assert sink not in text, f"{name}: {sink}"
    html = (NATIVE / "launcher" / "index.html").read_text()
    assert "<script>" not in html and " style=" not in html and "onclick=" not in html


def test_mobile_package_and_versions_line_up():
    pkg = json.loads((NATIVE / "mobile" / "package.json").read_text())
    assert set(pkg["dependencies"]) == {"@capacitor/android", "@capacitor/core", "@capacitor/ios"}
    assert (NATIVE / "launcher" / "index.html").is_file()               # webDir target exists
    versions = {json.loads((NATIVE / d / "package.json").read_text())["version"] for d in ("desktop", "mobile")}
    assert len(versions) == 1
