from app import audit as a


def setup_function():
    a.reset_activity()


def test_feed_excludes_noise_and_scopes_by_user():
    a.reset_activity()
    a.audit("http_request", user="alice", path="/x")
    a.audit("ask", user="alice", question="why?")
    a.audit("ask", user="bob", question="how?")
    assert [e["event"] for e in a.recent_events()] == ["ask", "ask"]
    assert [e["user"] for e in a.recent_events(user="alice")] == ["alice"]
    assert a.recent_events(user="mallory") == []


def test_feed_is_newest_first_and_bounded():
    a.reset_activity()
    for i in range(700):
        a.audit("ask", user="u", n=i)
    ev = a.recent_events(limit=10)
    assert [e["n"] for e in ev] == list(range(699, 689, -1))
    assert len(a.recent_events(limit=10_000)) == 500


def test_active_users_window_and_counts():
    a.reset_activity()
    a.touch_user("old@x.io", "viewer", "oidc", ts=1000)
    a.touch_user("new@x.io", "admin", "oidc", "10.0.0.1", ts=5000)
    a.touch_user("new@x.io", "admin", "oidc", "10.0.0.1", ts=5100)
    rows = a.active_users(within_seconds=600, now=5200)
    assert [r["user"] for r in rows] == ["new@x.io"] and rows[0]["requests"] == 2 and rows[0]["role"] == "admin"


def test_control_characters_are_stripped():
    a.reset_activity()
    a.audit("ask", user="evil\nuser", question="a\x00b")
    ev = a.recent_events()[0]
    assert "\n" not in ev["user"] and "\x00" not in ev["question"]
