from app.authz import (Policy, Principal, allowed_clusters, can_access_cluster, filter_findings,
                       filter_snapshot, has_permission, load_policy, namespace_allowed, sees_cluster_scope)

POLICY = Policy.from_dict({"rules": [
    {"match": {"groups": ["platform-admins"]}, "role": "admin", "clusters": ["*"], "namespaces": ["*"]},
    {"match": {"groups": ["team-payments"]}, "role": "operator", "clusters": ["prod-eu"], "namespaces": ["payments", "payments-*"]},
    {"match": {"emails": ["Auditor@Example.com"]}, "role": "viewer", "clusters": ["*"], "namespaces": ["*"]},
]})


def who(groups=(), email="", sub="u1"):
    return POLICY.resolve(Principal(sub, email, frozenset(groups), "oidc"))


def test_admin_has_everything():
    p = who(["platform-admins"])
    assert p.role == "admin" and has_permission(p, "ask") and has_permission(p, "admin")
    assert sees_cluster_scope(p) and can_access_cluster(p, "anything")


def test_team_is_scoped_to_cluster_and_namespaces():
    p = who(["team-payments"])
    assert p.role == "operator" and has_permission(p, "ask") and not has_permission(p, "admin")
    assert can_access_cluster(p, "prod-eu") and not can_access_cluster(p, "prod-us")
    assert namespace_allowed(p, "payments") and namespace_allowed(p, "payments-canary")
    assert not namespace_allowed(p, "kube-system") and not sees_cluster_scope(p)
    assert allowed_clusters(p, ["prod-eu", "prod-us"]) == ["prod-eu"]


def test_unmatched_user_is_denied_by_default():
    p = who(["random"])
    assert p.role == "none" and not has_permission(p, "read") and not can_access_cluster(p, "prod-eu")


def test_email_match_is_case_insensitive_and_viewer_cannot_ask():
    p = who(email="auditor@example.com")
    assert p.role == "viewer" and has_permission(p, "read") and not has_permission(p, "ask")


def test_multiple_rules_merge_to_highest_role_and_union_scope():
    pol = Policy.from_dict({"rules": [
        {"match": {"groups": ["a"]}, "role": "viewer", "clusters": ["c1"], "namespaces": ["x"]},
        {"match": {"groups": ["b"]}, "role": "operator", "clusters": ["c2"], "namespaces": ["y"]}]})
    p = pol.resolve(Principal("u", "", frozenset({"a", "b"}), "oidc"))
    assert p.role == "operator" and p.clusters == {"c1", "c2"} and p.namespaces == {"x", "y"}


def test_empty_match_never_grants():
    pol = Policy.from_dict({"rules": [{"match": {}, "role": "admin"}]})
    assert pol.resolve(Principal("u", "", frozenset({"x"}), "oidc")).role == "none"


def test_invalid_policy_rejected():
    for bad in ({"rules": [{"match": {"groups": ["a"]}, "role": "root"}]}, {"default_role": "superuser"}):
        try:
            Policy.from_dict(bad)
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_snapshot_and_findings_filtering():
    snap = {"mode": "live", "nodes": [{"name": "n1"}],
            "pods": [{"namespace": "payments", "name": "a"}, {"namespace": "hr", "name": "b"}],
            "events": [{"namespace": "payments"}, {"namespace": "hr"}]}
    team = who(["team-payments"])
    view = filter_snapshot(snap, team)
    assert [p["name"] for p in view["pods"]] == ["a"] and view["nodes"] == [] and len(view["events"]) == 1
    assert filter_snapshot(snap, who(["platform-admins"])) is snap
    findings = [{"namespace": "payments"}, {"namespace": "hr"}, {"resource": "node/n1"}]
    assert filter_findings(findings, team) == [{"namespace": "payments"}]
    assert len(filter_findings(findings, who(["platform-admins"]))) == 3


def test_builtin_rules_keep_legacy_key_and_demo_working():
    pol = load_policy()
    for group in ("__legacy_admin__", "__anonymous__"):
        assert pol.resolve(Principal("s", "", frozenset({group}), "api-key")).role == "admin"
