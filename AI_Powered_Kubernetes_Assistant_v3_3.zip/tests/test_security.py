import base64
import os

from app.security import RateLimiter, extract_credential, is_authorized, validate_startup_security


def basic(pw, user="x"):
    return "Basic " + base64.b64encode(f"{user}:{pw}".encode()).decode()


def test_extract_credential_variants():
    assert extract_credential({"X-API-Key": " k1 "}) == "k1"
    assert extract_credential({"Authorization": "Bearer k2"}) == "k2"
    assert extract_credential({"authorization": basic("k3")}) == "k3"
    assert extract_credential({"Authorization": "Basic !!notbase64"}) is None
    assert extract_credential({"Authorization": "Token abc"}) is None
    assert extract_credential({}) is None


def test_is_authorized():
    assert is_authorized(None, "")            # no key configured -> open (demo)
    assert is_authorized("secret", "secret")
    assert not is_authorized("secret2", "secret")
    assert not is_authorized(None, "secret")
    assert not is_authorized("", "secret")


def _with_env(env, fn):
    keys = ("DEMO_MODE", "API_KEY", "ALLOW_INSECURE")
    saved = {k: os.environ.get(k) for k in keys}
    try:
        for k in keys:
            os.environ.pop(k, None)
        os.environ.update(env)
        return fn()
    finally:
        for k, v in saved.items():
            os.environ.pop(k, None)
            if v is not None:
                os.environ[k] = v


def _raises(env):
    try:
        _with_env(env, validate_startup_security)
    except RuntimeError:
        return True
    return False


def test_live_mode_requires_api_key():
    assert _raises({"DEMO_MODE": "false"})
    assert not _raises({"DEMO_MODE": "false", "API_KEY": "abc"})
    assert not _raises({"DEMO_MODE": "false", "ALLOW_INSECURE": "true"})
    assert not _raises({"DEMO_MODE": "true"})


def test_rate_limiter_window():
    rl = RateLimiter(limit=2, window=60)
    assert rl.allow("a", now=0) and rl.allow("a", now=1)
    assert not rl.allow("a", now=2)
    assert rl.allow("b", now=2)               # separate key
    assert rl.allow("a", now=61)              # window slid
    assert RateLimiter(limit=0).allow("a")    # 0 disables limiting
