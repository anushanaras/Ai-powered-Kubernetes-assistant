"""Multi-user / multi-cluster HTTP tests (skipped when FastAPI/httpx are not installed)."""
import json
import time

import pytest

pytest.importorskip("fastapi")
pytest.importorskip("httpx")

from fastapi.testclient import TestClient  # noqa: E402

from app import main  # noqa: E402
from app.authn import sha256_hex  # noqa: E402

ENV_VARS = ("API_KEY", "ANTHROPIC_API_KEY", "API_KEYS_FILE", "OIDC_ISSUER", "OIDC_AUDIENCE", "CLUSTERS_CONFIG",
            "AUTHZ_POLICY", "PROMETHEUS_URL", "METRICS_TOKEN")


@pytest.fixture
def env(monkeypatch, tmp_path):
    for var in ENV_VARS:
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("DEMO_MODE", "true")
    keys = tmp_path / "keys.json"
    keys.write_text(json.dumps({"keys": [
        {"name": "root", "sha256": sha256_hex("root-key"), "groups": ["platform-admins"]},
        {"name": "pay", "sha256": sha256_hex("pay-key"), "groups": ["team-payments"]},
        {"name": "aud", "sha256": sha256_hex("aud-key"), "groups": ["auditors"]},
        {"name": "nobody", "sha256": sha256_hex("nobody-key"), "groups": ["strangers"]},
    ]}))
    policy = tmp_path / "policy.json"
    policy.write_text(json.dumps({"rules": [
        {"match": {"groups": ["platform-admins"]}, "role": "admin", "clusters": ["*"], "namespaces": ["*"]},
        {"match": {"groups": ["team-payments"]}, "role": "operator", "clusters": ["prod-eu"], "namespaces": ["payments"]},
        {"match": {"groups": ["auditors"]}, "role": "viewer", "clusters": ["*"], "namespaces": ["*"]},
    ]}))
    clusters = tmp_path / "clusters.json"
    clusters.write_text(json.dumps({"clusters": [{"name": "prod-eu", "in_cluster": True}, {"name": "prod-us", "in_cluster": True}]}))
    monkeypatch.setenv("API_KEYS_FILE", str(keys))
    monkeypatch.setenv("AUTHZ_POLICY", str(policy))
    monkeypatch.setenv("CLUSTERS_CONFIG", str(clusters))
    monkeypatch.setenv("METRICS_TOKEN", "scrape-me")
    main.limiter._hits.clear()
    with TestClient(main.app) as c:
        yield c


def h(key):
    return {"X-API-Key": key}


def test_unauthenticated_and_unknown_principals(env):
    assert env.get("/api/diagnostics").status_code == 401
    assert env.get("/api/diagnostics", headers=h("wrong")).status_code == 401
    assert env.get("/api/diagnostics", headers=h("nobody-key")).status_code == 403     # authenticated, no role
    assert env.get("/health").status_code == 200


def test_team_sees_only_its_namespace_and_no_nodes(env):
    r = env.get("/api/cluster", params={"cluster": "prod-eu"}, headers=h("pay-key")).json()
    assert {p["namespace"] for p in r["pods"]} == {"payments"} and r["nodes"] == []
    findings = env.get("/api/diagnostics", params={"cluster": "prod-eu"}, headers=h("pay-key")).json()["findings"]
    assert findings and {f["namespace"] for f in findings} == {"payments"}
    assert env.get("/api/pods/default/web-7b9d8c", params={"cluster": "prod-eu"}, headers=h("pay-key")).status_code == 404
    assert env.get("/api/history/pods/default/report-gen-5d8f", params={"cluster": "prod-eu"}, headers=h("pay-key")).status_code == 404
    assert env.get("/api/history/nodes", params={"cluster": "prod-eu"}, headers=h("pay-key")).json() == {}
    assert env.get("/api/metrics", params={"cluster": "prod-eu"}, headers=h("pay-key")).json()["nodes"] == []


def test_cluster_scoping_hides_existence(env):
    assert env.get("/api/cluster", params={"cluster": "prod-us"}, headers=h("pay-key")).status_code == 404
    assert env.get("/api/cluster", params={"cluster": "does-not-exist"}, headers=h("pay-key")).status_code == 404
    assert env.get("/api/clusters", headers=h("pay-key")).json()["clusters"] == ["prod-eu"]
    assert env.get("/api/clusters", headers=h("root-key")).json()["clusters"] == ["prod-eu", "prod-us"]


def test_viewer_can_read_but_not_ask(env):
    assert env.get("/api/diagnostics", headers=h("aud-key")).status_code == 200
    assert env.post("/api/ask", json={"question": "what is wrong?"}, headers=h("aud-key")).status_code == 403
    assert env.get("/api/summary", headers=h("aud-key")).status_code == 403
    assert env.post("/api/ask", json={"question": "what is wrong?"}, headers=h("pay-key"),
                    params={"cluster": "prod-eu"}).status_code == 200


def test_claude_digest_is_scoped_to_the_callers_namespaces(env, monkeypatch):
    seen = {}

    class Spy:
        model = "spy"

        def ask(self, question, context):
            seen["ctx"] = json.dumps(context)
            return "ok"

    monkeypatch.setattr(main, "get_llm", lambda: Spy())
    env.post("/api/ask", json={"question": "what is wrong?"}, headers=h("pay-key"), params={"cluster": "prod-eu"})
    assert "payments/" in seen["ctx"] and "default/" not in seen["ctx"] and "demo-node" not in seen["ctx"]


def test_metrics_endpoint_requires_token_and_exposes_series(env):
    assert env.get("/metrics").status_code == 401
    assert env.get("/metrics", headers={"Authorization": "Bearer nope"}).status_code == 401
    body = env.get("/metrics", headers={"Authorization": "Bearer scrape-me"})
    assert body.status_code == 200 and body.headers["content-type"].startswith("text/plain")
    assert 'k8s_assistant_cluster_up{cluster="prod-eu"} 1' in body.text
    assert "k8s_assistant_findings{" in body.text and "k8s_assistant_node_cpu_utilization_percent{" in body.text
    # route labels use templates, not raw paths (bounded cardinality)
    env.get("/api/pods/payments/api-55cc9f", params={"cluster": "prod-eu"}, headers=h("root-key"))
    text = env.get("/metrics", headers={"Authorization": "Bearer scrape-me"}).text
    assert 'route="/api/pods/{namespace}/{name}"' in text and "api-55cc9f\"" not in text


def test_me_endpoint(env):
    me = env.get("/api/me", headers=h("pay-key")).json()
    assert me["role"] == "operator" and me["clusters"] == ["prod-eu"] and me["namespaces"] == ["payments"]


def test_oidc_bearer_token_end_to_end(env, monkeypatch):
    jwt = pytest.importorskip("jwt")
    from cryptography.hazmat.primitives.asymmetric import rsa
    from app.authn import ApiKeyStore, Authenticator, OidcValidator
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    oidc = OidcValidator("https://idp.example.com", "k8s-assistant", key_resolver=lambda t: key.public_key())
    monkeypatch.setattr(main, "get_authenticator", lambda: Authenticator(ApiKeyStore([]), oidc))
    tok = jwt.encode({"iss": "https://idp.example.com", "aud": "k8s-assistant", "sub": "bob", "email": "bob@x.io",
                      "groups": ["team-payments"], "exp": int(time.time()) + 300}, key, algorithm="RS256")
    r = env.get("/api/me", headers={"Authorization": f"Bearer {tok}"})
    assert r.status_code == 200 and r.json()["user"] == "bob@x.io" and r.json()["role"] == "operator"
    assert env.get("/api/me", headers={"Authorization": "Bearer a.b.c"}).status_code == 401


def test_audit_feed_is_scoped_and_active_users_is_admin_only(env):
    env.post("/api/ask", json={"question": "dev question"}, headers=h("pay-key"), params={"cluster": "prod-eu"})
    mine = env.get("/api/audit", headers=h("pay-key")).json()
    assert mine["scope"] == "self" and all(e.get("user") == "pay" or "apikey:pay" in str(e.get("user")) for e in mine["events"])
    allv = env.get("/api/audit", headers=h("root-key")).json()
    assert allv["scope"] == "all" and any(e.get("event") == "ask" for e in allv["events"])
    assert env.get("/api/users/active", headers=h("pay-key")).status_code == 403
    assert env.get("/api/users/active", headers=h("root-key")).status_code == 200
    assert env.get("/api/audit").status_code == 401


def test_app_shell_is_public_but_sets_strict_csp(env):
    r = env.get("/app/")
    assert r.status_code == 200 and "script-src 'self'" in r.headers["content-security-policy"]
    assert "unsafe-inline" not in r.headers["content-security-policy"].split("script-src")[1].split(";")[0]
    assert env.get("/app/manifest.webmanifest").status_code == 200
