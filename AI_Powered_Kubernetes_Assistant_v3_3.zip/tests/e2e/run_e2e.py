from playwright.sync_api import sync_playwright
import pathlib
BASE = "http://127.0.0.1:8765/app/"
problems = []
import time
def until(page, expr, timeout=8.0):
    end = time.time() + timeout
    while time.time() < end:
        if page.evaluate("() => !!(" + expr + ")"): return
        time.sleep(0.1)
    raise AssertionError("timeout waiting for: " + expr)

def watch(page, tag):
    page.on("console", lambda m: problems.append(f"[{tag}] console.{m.type}: {m.text}") if m.type in ("error", "warning") else None)
    page.on("pageerror", lambda e: problems.append(f"[{tag}] pageerror: {e}"))
def login(page, key):
    page.goto(BASE); page.wait_for_selector("#login:not([hidden])")
    page.fill("#apikey", key); page.click("#login-form button[type=submit]")

with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={"width": 1280, "height": 900}); page = ctx.new_page(); page.set_default_timeout(8000); watch(page, "admin")
    login(page, "root"); page.wait_for_selector("#view-ops .kpi")
    until(page, "document.querySelectorAll('#view-ops .node').length >= 2")
    txt = page.inner_text("#view-ops")
    assert "demo-node-1" in txt and "report-gen-5d8f" in txt, txt[:300]
    assert page.locator("#view-ops details.finding").count() >= 3
    assert page.locator("#view-ops .node svg.spark polyline").count() >= 2, "sparklines missing"
    page.screenshot(path="shots/admin_ops.png", full_page=True)
    assert page.locator("#cluster option").all_inner_texts() == ["prod-eu", "prod-us"]
    page.click("#nav button[data-view=users]")
    until(page, "document.querySelector('#view-users').innerText.includes('Active in the last hour')")
    ut = page.inner_text("#view-users"); assert "root@corp.io" in ut and "all users" in ut.lower(), ut[:400]
    page.screenshot(path="shots/admin_users.png", full_page=True)
    page.click("#nav button[data-view=ask]"); page.fill("#question", "which pods use the most memory?"); page.click("#ask-form button.primary")
    until(page, "document.getElementById('answer').textContent.startsWith('Rules answer')")
    page.click("#nav button[data-view=users]"); until(page, "document.querySelector('#view-users').innerText.includes('which pods use')")
    page.click("#nav button[data-view=ops]"); page.wait_for_selector("#view-ops .chip")
    page.click("#view-ops .chip:has-text('high')"); until(page, "document.querySelector('#view-ops .chip[aria-pressed=true]').innerText==='high'")
    sevs = [x.lower() for x in page.locator("#view-ops details.finding .sev").all_inner_texts()]
    assert sevs and set(sevs) == {"high"}, sevs
    until(page, "navigator.serviceWorker.getRegistration().then(r=>!!r)")
    print("1 admin desktop ok")

    ctx2 = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
    m = ctx2.new_page(); m.set_default_timeout(8000); watch(m, "mobile-pay")
    login(m, "pay"); m.wait_for_selector("#view-ops .kpi"); m.wait_for_timeout(500)
    mt = m.inner_text("#view-ops")
    assert "payments/" in mt and "report-gen" not in mt and "web-7b9d8c" not in mt and "demo-node-1" not in mt, mt[:400]
    assert m.locator("#cluster option").all_inner_texts() == ["prod-eu"]
    assert m.is_visible("#nav") and not m.is_visible("#nav .brand")
    m.screenshot(path="shots/mobile_ops.png", full_page=True)
    m.click("#nav button[data-view=users]"); until(m, "document.querySelector('#view-users').innerText.includes('My recent activity')")
    ut = m.inner_text("#view-users"); assert "Active in the last hour" not in ut and "dev@corp.io" in ut
    m.screenshot(path="shots/mobile_users.png", full_page=True)
    print("2 mobile scoped ok")

    v = b.new_context().new_page(); v.set_default_timeout(8000); watch(v, "viewer")
    login(v, "aud"); v.wait_for_selector("#view-ops .kpi"); v.click("#nav button[data-view=ask]")
    v.fill("#question", "anything"); v.click("#ask-form button.primary")
    until(v, "document.getElementById('answer').textContent.includes('does not allow')")
    print("3 viewer cannot ask ok")

    n = b.new_context().new_page(); n.set_default_timeout(8000)
    login(n, "nobody"); until(n, "document.getElementById('login-msg').textContent.includes('no access')")
    w = b.new_context().new_page(); w.set_default_timeout(8000); login(w, "wrong"); until(w, "!document.getElementById('login').hidden")
    print("4 no-role / bad key ok")

    pathlib.Path("/tmp/xss").write_text("1")
    page.click("#refresh"); page.wait_for_timeout(1500)
    assert page.evaluate("window.__xss") is None, "XSS EXECUTED"
    pathlib.Path("/tmp/xss").unlink()
    print("5 hostile text rendered inert ok")

    ctx.set_offline(True); page.click("#refresh")
    until(page, "!document.getElementById('banner').hidden && document.getElementById('banner').textContent.includes('offline')")
    ctx.set_offline(False)
    print("6 offline banner ok")
    b.close()
print("E2E PASSED"); print("console problems:", problems or "none")
