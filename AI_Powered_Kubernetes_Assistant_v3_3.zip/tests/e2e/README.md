Browser end-to-end test for the installable app (needs `pip install playwright && playwright install chromium`).

    python tests/e2e/stub_server.py &      # real analyzer/authz/audit code, FastAPI replaced by a stdlib server, same CSP
    mkdir -p shots && python tests/e2e/run_e2e.py

Covers: admin desktop, namespace-scoped phone user, viewer (cannot ask), no-role and bad key, hostile pod text
rendered inert, offline banner. Screenshots land in ./shots.
