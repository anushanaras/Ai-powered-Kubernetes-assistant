"""Launcher flow in a real browser. Start `stub_server.py` first (port 8765); this serves the launcher on 8766."""
import functools, http.server, pathlib, threading, time
from playwright.sync_api import sync_playwright

LAUNCHER = pathlib.Path(__file__).resolve().parents[2] / "native" / "launcher"
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
handler = functools.partial(Quiet, directory=str(LAUNCHER))
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 8766), handler); threading.Thread(target=srv.serve_forever, daemon=True).start()
L = "http://127.0.0.1:8766/index.html"

def until(page, expr, timeout=8.0):
    end = time.time() + timeout
    while time.time() < end:
        if page.evaluate("() => !!(" + expr + ")"): return
        time.sleep(0.1)
    raise AssertionError("timeout: " + expr)

with sync_playwright() as p:
    b = p.chromium.launch(); page = b.new_context().new_page(); page.set_default_timeout(8000)
    page.goto(L); until(page, "!document.getElementById('form').hidden")                      # first run -> form
    for bad, msg in (("javascript:alert(1)", "https"), ("http://k8s.example.com", "https"), ("https://u:p@x.example.com", "credentials")):
        page.fill("#server", bad); page.click("button.primary"); until(page, f"document.getElementById('status').textContent.includes('{msg}')")
    page.fill("#server", "http://127.0.0.1:1"); page.click("button.primary")                    # nothing listens there
    until(page, "document.getElementById('status').textContent.includes('Could not reach')")
    page.fill("#server", "http://127.0.0.1:8765"); page.click("button.primary")                 # real stub server
    page.wait_for_url("http://127.0.0.1:8765/app/**"); until(page, "!document.getElementById('login').hidden")
    print("1 first-run connect -> app opened ok")

    page.goto(L); until(page, "!document.getElementById('connecting').hidden")                 # saved -> auto-connect screen
    assert page.inner_text("#host") == "127.0.0.1:8765"
    page.wait_for_url("http://127.0.0.1:8765/app/**")
    print("2 auto-reconnect ok")

    page.goto(L); until(page, "!document.getElementById('connecting').hidden"); page.click("#change")   # change server
    until(page, "!document.getElementById('form').hidden"); assert page.input_value("#server") == "http://127.0.0.1:8765"
    print("3 change server ok")

    page.evaluate("() => localStorage.setItem('ka_server_origin', 'javascript:alert(1)')")      # tampered storage
    page.goto(L); until(page, "!document.getElementById('form').hidden")
    assert page.evaluate("() => localStorage.getItem('ka_server_origin')") is None
    print("4 tampered stored value rejected and cleared ok")
    b.close()
srv.shutdown(); print("LAUNCHER E2E PASSED")
