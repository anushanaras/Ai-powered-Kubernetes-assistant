"""Test harness: serves app/static and implements the app's API with the project's REAL pure modules
(analyzer, demo data, authz, audit, history) and the same CSP. Only FastAPI itself is replaced."""
import json, sys, time, mimetypes, pathlib, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
ROOT = __import__("pathlib").Path(__file__).resolve().parents[2]; sys.path.insert(0, str(ROOT))
from app.analyzer import analyze_cluster, utilization_summary
from app.authz import Policy, Principal, filter_findings, filter_snapshot, has_permission, load_policy, allowed_clusters, sees_cluster_scope, namespace_allowed
from app.audit import audit, recent_events, active_users, touch_user
from app.history import History, seed_demo_history
from app.kube import _demo_snapshot

STATIC = ROOT / "app" / "static"
POLICY = load_policy(); POLICY.rules += Policy.from_dict({"rules": [
    {"match": {"groups": ["pay"]}, "role": "operator", "clusters": ["prod-eu"], "namespaces": ["payments"]},
    {"match": {"groups": ["aud"]}, "role": "viewer", "clusters": ["*"], "namespaces": ["*"]}]}).rules
KEYS = {"root": ("root@corp.io", {"__legacy_admin__"}), "pay": ("dev@corp.io", {"pay"}), "aud": ("auditor@corp.io", {"aud"}), "nobody": ("x@corp.io", {"zzz"})}
CLUSTERS = ["prod-eu", "prod-us"]
HIST = History(); seed_demo_history(HIST, _demo_snapshot())
CSP = ("default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; "
       "manifest-src 'self'; worker-src 'self'; frame-ancestors 'none'; base-uri 'none'")

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send(self, code, body, ctype="application/json", extra=None):
        b = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(b)))
        self.send_header("Content-Security-Policy", CSP); self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items(): self.send_header(k, v)
        self.end_headers(); self.wfile.write(b)
    def principal(self):
        key = self.headers.get("X-API-Key", "")
        if key not in KEYS: return None, 401
        label, groups = KEYS[key]
        p = POLICY.resolve(Principal("apikey:" + key, label, frozenset(groups), "api-key"))
        return (p, 200) if p.role != "none" else (None, 403)
    def do_GET(self): self.route("GET")
    def do_POST(self): self.route("POST")
    def route(self, method):
        u = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(u.query); path = u.path
        if path.startswith("/app"):
            rel = path[len("/app"):].lstrip("/") or "index.html"; f = (STATIC / rel).resolve()
            if STATIC in f.parents and f.is_file():
                ct = "application/manifest+json" if rel.endswith(".webmanifest") else (mimetypes.guess_type(rel)[0] or "application/octet-stream")
                return self.send(200, f.read_bytes(), ct)
            return self.send(404, {"detail": "nf"})
        p, code = self.principal()
        if p is None:
            if code == 403: audit("authz_denied", user="x@corp.io", reason="no matching role")
            return self.send(code, {"detail": "Authentication required." if code == 401 else "You are not authorized to use this service."})
        touch_user(p.label(), p.role, p.auth_method)
        def need(perm):
            if not has_permission(p, perm): self.send(403, {"detail": "Your role does not permit this action."}); return False
            return True
        cl = (q.get("cluster") or [CLUSTERS[0]])[0]
        def cluster_ok():
            if cl not in CLUSTERS or cl not in allowed_clusters(p, CLUSTERS): self.send(404, {"detail": "Unknown cluster."}); return False
            return True
        snap = None
        if path == "/api/me": return self.send(200, {"user": p.label(), "role": p.role, "auth_method": p.auth_method, "clusters": allowed_clusters(p, CLUSTERS), "namespaces": sorted(p.namespaces)})
        if path == "/api/clusters": return self.send(200, {"clusters": allowed_clusters(p, CLUSTERS), "default": CLUSTERS[0]})
        if path == "/api/audit":
            if not need("read"): return
            user = None if has_permission(p, "admin") else p.label()
            return self.send(200, {"scope": "all" if user is None else "self", "events": recent_events(50, user)})
        if path == "/api/users/active":
            if not need("admin"): return
            return self.send(200, {"window_minutes": 60, "users": active_users(3600)})
        if not need("read") or not cluster_ok(): return
        raw = _demo_snapshot()
        if pathlib.Path("/tmp/xss").exists():      # hostile pod/event text, to prove the UI renders it as text
            raw["pods"][0]["name"] = '<img src=x onerror="window.__xss=1">'
            raw["events"][0]["message"] = "<script>window.__xss=2</script>"
        view = filter_snapshot(raw, p)
        findings = lambda: filter_findings(analyze_cluster(view, history=HIST), p)
        if path == "/api/metrics": return self.send(200, {"cluster": cl, "mode": "demo", **utilization_summary(view, top_n=5)})
        if path == "/api/diagnostics": return self.send(200, {"cluster": cl, "mode": "demo", "findings": findings()})
        if path == "/api/cluster": return self.send(200, view)
        if path == "/api/history/nodes":
            if not sees_cluster_scope(p): return self.send(200, {})
            return self.send(200, {n: [{"ts": t, "cpu_pct": c, "mem_pct": m} for t, c, m in HIST.node_series(n)] for n in HIST.node_names()})
        if path == "/api/ask" and method == "POST":
            if not need("ask"): return
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
            audit("ask", question=body.get("question", ""), source="rules", user=p.label(), cluster=cl)
            return self.send(200, {"answer": "Rules answer for: " + body.get("question", ""), "source": "rules", "note": None})
        return self.send(404, {"detail": "nf"})

if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", 8765), H).serve_forever()
