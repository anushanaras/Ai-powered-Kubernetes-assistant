from app.units import fmt_memory, parse_cpu, parse_memory, pct


def test_parse_cpu():
    assert parse_cpu("250m") == 250
    assert parse_cpu("2") == 2000
    assert parse_cpu("1500000n") == 1.5
    assert parse_cpu(None) is None
    assert parse_cpu("junk") is None


def test_parse_memory():
    assert parse_memory("128Mi") == 128 * 1024**2
    assert parse_memory("1Gi") == 1024**3
    assert parse_memory("1G") == 1_000_000_000
    assert parse_memory("123456") == 123456
    assert parse_memory("") is None


def test_pct_and_format():
    assert pct(50, 200) == 25.0
    assert pct(None, 200) is None
    assert pct(5, 0) is None
    assert fmt_memory(512 * 1024**2) == "512Mi"
