from app.analyzer import analyze_cluster, utilization_summary
from app.dashboard_data import (aggregate_usage, cluster_health, cluster_timeseries, gauge_svg, home_summary, kpi_tile_html,
                                log_html, pod_status_counts, status_donut_html)
from app.history import History, seed_demo_history
from app.kube import _demo_snapshot


def test_home_summary_on_demo_data():
    s = _demo_snapshot(); f = analyze_cluster(s); h = home_summary(s, f)
    assert h["pods_total"] == 6 and h["pods_running"] == 5 and h["nodes_total"] == 2 and h["nodes_ready"] == 2
    assert h["health"] == "Critical" and h["alerts_active"] == sum(x["severity"] in ("high", "medium") for x in f)


def test_health_levels():
    ok = {"mode": "live"}
    assert cluster_health([], ok) == "Healthy" and cluster_health([{"severity": "low"}], ok) == "Healthy"
    assert cluster_health([{"severity": "medium"}], ok) == "Degraded" and cluster_health([{"severity": "high"}], ok) == "Critical"
    assert cluster_health([], {"mode": "error"}) == "Unknown"


def test_status_counts_and_unknown_phase():
    assert pod_status_counts([{"phase": "Running"}, {"phase": "Running"}, {"phase": "Weird"}, {}]) == {"Running": 2, "Unknown": 2}


def test_aggregate_usage_is_capacity_weighted():
    u = {"nodes": [{"cpu_pct": 10, "cpu_used_m": 1000, "cpu_allocatable_m": 4000, "mem_used": 2, "mem_allocatable": 8},
                   {"cpu_pct": 90, "cpu_used_m": 3000, "cpu_allocatable_m": 4000, "mem_used": 6, "mem_allocatable": 8}]}
    assert aggregate_usage(u) == {"cpu_pct": 50.0, "mem_pct": 50.0}
    assert aggregate_usage({"nodes": []}) == {"cpu_pct": None, "mem_pct": None}
    assert aggregate_usage({"nodes": [{"cpu_pct": None}]}) == {"cpu_pct": None, "mem_pct": None}


def test_timeseries_averages_nodes_per_timestamp():
    s = _demo_snapshot(); h = History(); seed_demo_history(h, s)
    ts = cluster_timeseries(h)
    assert len(ts) == h.sample_count() and ts == sorted(ts) and all(0 <= c <= 100 and 0 <= m <= 100 for _, c, m in ts)


def test_gauge_clamps_colours_and_escapes():
    assert 'stroke="#35a7ff"' in gauge_svg(32, "CPU Usage") and 'stroke="#f5a524"' in gauge_svg(75, "x") and 'stroke="#ef5350"' in gauge_svg(97, "x")
    assert ">100%<" in gauge_svg(250, "x") and ">0%<" in gauge_svg(-5, "x") and ">n/a<" in gauge_svg(None, "x") and ">0%<" in gauge_svg(float("nan"), "x")
    assert "<script>" not in gauge_svg(10, "<script>alert(1)</script>")


def test_donut_and_kpi_escape_and_totals():
    d = status_donut_html({"Running": 10, "Pending": 1, "Failed": 1})
    assert ">12<" in d and d.count("<circle") == 4 and "Running <b>10</b>" in d
    assert "No pods" in status_donut_html({})
    k = kpi_tile_html("<b>x</b>", "<img src=x onerror=1>", "<s>", "red;background:url(javascript:1)")
    assert "<img" not in k and "<b>x" not in k and "&lt;img" in k


def test_log_html_escapes_hostile_messages():
    html_out = log_html([{"ts": "t", "level": "ERROR", "message": "<script>alert(1)</script><img src=x onerror=1>"}])
    assert "<script>" not in html_out and "<img" not in html_out and "&lt;script&gt;" in html_out
