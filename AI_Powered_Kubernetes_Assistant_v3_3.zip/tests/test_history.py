from app.analyzer import Thresholds, analyze_cluster
from app.history import History, mem_trend, seed_demo_history, sparkline_points
from app.kube import _demo_snapshot

MI = 1024**2


def linear(n=30, step=60.0, start=100 * MI, per_hour=60 * MI, t0=0.0):
    return [(t0 + i * step, start + per_hour * (i * step / 3600)) for i in range(n)]


def test_trend_detects_growth():
    t = mem_trend(linear())
    assert abs(t["slope_per_hour"] - 60 * MI) < MI and t["r2"] > 0.99 and t["growth_pct"] > 25


def test_trend_flat_has_no_growth_and_short_series_ignored():
    flat = [(i * 60.0, 200 * MI) for i in range(30)]
    t = mem_trend(flat)
    assert abs(t["slope_per_hour"]) < 1 and t["growth_pct"] < 1
    assert mem_trend(linear(n=5)) is None


def test_trend_ignores_data_before_restart_drop():
    pts = linear(n=20, per_hour=0, start=900 * MI)
    after = [(20 * 60.0 + i * 60.0, 100 * MI + 5 * MI * i) for i in range(20)]
    t = mem_trend(pts + after)
    assert t["slope_per_hour"] > 0       # only the post-restart growth counts


def test_history_record_and_prune():
    h = History(max_points=5)
    snap = _demo_snapshot()
    for i in range(8):
        assert h.record(snap, ts=float(i))
    assert len(h.node_series("demo-node-2")) == 5                  # ring buffer
    assert len(h.pod_series("default", "web-7b9d8c")) == 5
    snap2 = {**snap, "pods": [p for p in snap["pods"] if p["name"] != "web-7b9d8c"]}
    h.record(snap2, ts=9.0)
    assert h.pod_series("default", "web-7b9d8c") == []             # pruned when pod disappears
    assert not h.record({"mode": "live", "metrics": {"available": False}, "pods": [], "nodes": []})
    assert not h.record({"mode": "error", "metrics": {"available": True}})


def test_seeded_demo_history_triggers_trend_rules():
    h = History()
    snap = _demo_snapshot()
    seed_demo_history(h, snap, now=10_000.0)
    findings = analyze_cluster(snap, Thresholds(), history=h)
    leak = [f for f in findings if f["rule"] == "pod-memory-growth"]
    assert len(leak) == 1 and leak[0]["resource"] == "pod/default/report-gen-5d8f" and leak[0]["severity"] == "high"
    assert "limit in" in leak[0]["evidence"]
    sustained = [f for f in findings if f["rule"] == "node-mem-sustained"]
    assert [f["resource"] for f in sustained] == ["node/demo-node-2"]
    # no history -> trend rules silent, instantaneous rules unaffected
    assert not any(f["rule"] in ("pod-memory-growth", "node-mem-sustained") for f in analyze_cluster(snap, Thresholds()))


def test_leak_without_limit_is_low_and_noise_is_ignored():
    h = History()
    snap = _demo_snapshot()
    seed_demo_history(h, snap, now=10_000.0)
    for p in snap["pods"]:
        if p["name"].startswith("report-gen"):
            for c in p["containers"]:
                c["mem_limit"] = None
    leak = [f for f in analyze_cluster(snap, Thresholds(), history=h) if f["rule"] == "pod-memory-growth"][0]
    assert leak["severity"] == "low"
    # stable pods in the demo never trip the leak rule
    assert all(f["resource"].endswith("report-gen-5d8f")
               for f in analyze_cluster(snap, Thresholds(), history=h) if f["rule"] == "pod-memory-growth")


def test_sparkline():
    pts = sparkline_points([0, 50, 100], width=100, height=10, vmax=100)
    assert pts == "0.0,10.0 50.0,5.0 100.0,0.0"
    assert sparkline_points([1]) == "" and sparkline_points([None, None]) == ""
