const test = require('node:test'), assert = require('node:assert');
const KA = require('../../app/static/lib.js');

test('formatters', () => {
  assert.equal(KA.fmtMem(210 * 1048576), '210 Mi'); assert.equal(KA.fmtMem(3 * 1073741824), '3.0 Gi'); assert.equal(KA.fmtMem(null), '—');
  assert.equal(KA.fmtCpu(120), '120m'); assert.equal(KA.fmtCpu(1500), '1.50 cores'); assert.equal(KA.fmtPct(87.6), '88%'); assert.equal(KA.fmtPct(undefined), '—');
});
test('level thresholds', () => { assert.equal(KA.level(50), 'ok'); assert.equal(KA.level(85), 'warn'); assert.equal(KA.level(95), 'crit'); assert.equal(KA.level(null), 'ok'); });
test('ago', () => { assert.equal(KA.ago(100, 130), '30s ago'); assert.equal(KA.ago(0, 7200), '2h ago'); assert.equal(KA.ago(200, 100), '0s ago'); });
test('sparkline', () => {
  assert.equal(KA.sparkPoints([1], 120, 28, 100), ''); assert.equal(KA.sparkPoints([null, 5], 120, 28, 100), '');
  assert.equal(KA.sparkPoints([0, 100], 120, 28, 100), '0.0,28.0 120.0,0.0');
  assert.equal(KA.sparkPoints([0, 500], 120, 28, 100), '0.0,28.0 120.0,0.0');       // clamped
});
test('findings helpers', () => {
  const f = [{ severity: 'low' }, { severity: 'high' }, { severity: 'info' }, { severity: 'medium' }, { severity: 'high' }];
  assert.deepEqual(KA.sortFindings(f).map(x => x.severity), ['high', 'high', 'medium', 'low', 'info']);
  assert.deepEqual(KA.countBySeverity(f), { high: 2, medium: 1, low: 1, info: 1 });
  assert.deepEqual(KA.countByPhase([{ phase: 'Running' }, { phase: 'Running' }, {}]), { Running: 2, Unknown: 1 });
});
test('role permissions mirror the server table', () => {
  assert.ok(KA.can('viewer', 'read')); assert.ok(!KA.can('viewer', 'ask')); assert.ok(KA.can('operator', 'ask'));
  assert.ok(!KA.can('operator', 'admin')); assert.ok(KA.can('admin', 'admin')); assert.ok(!KA.can('none', 'read'));
});
