from app.analyzer import Thresholds, analyze_cluster, answer_question, utilization_summary
from app.kube import _demo_snapshot

MI = 1024**2
TH = Thresholds()


def container(**kw):
    base = {"name": "app", "ready": True, "restarts": 0, "state": "running", "state_reason": None,
            "last_terminated_reason": None, "last_exit_code": None, "cpu_request_m": 100, "cpu_limit_m": 500,
            "mem_request": 128 * MI, "mem_limit": 256 * MI, "cpu_usage_m": None, "mem_usage": None}
    base.update(kw)
    return base


def pod(name="p", ns="default", phase="Running", ready=True, restarts=0, age=86400, containers=None, scheduling=None):
    return {"name": name, "namespace": ns, "phase": phase, "ready": ready, "restarts": restarts,
            "age_seconds": age, "scheduling": scheduling, "containers": containers if containers is not None else [container()]}


def snap(pods=(), nodes=(), events=(), mode="demo", metrics=None):
    return {"mode": mode, "pods": list(pods), "nodes": list(nodes), "events": list(events),
            "metrics": metrics or {"available": True, "reason": ""}}


def rules(snapshot):
    return {f["rule"] for f in analyze_cluster(snapshot, TH)}


def test_oomkilled_and_crashloop():
    c = container(ready=False, restarts=4, state="waiting", state_reason="CrashLoopBackOff",
                  last_terminated_reason="OOMKilled", last_exit_code=137)
    r = rules(snap([pod(ready=False, containers=[c])]))
    assert {"container-oomkilled", "container-crashloop"} <= r
    assert "pod-not-ready" not in r  # container-level cause already explains it


def test_image_pull_error():
    c = container(ready=False, state="waiting", state_reason="ImagePullBackOff")
    assert "container-image-pull" in rules(snap([pod(ready=False, containers=[c])]))


def test_unschedulable_pending_is_high_when_long():
    p = pod(phase="Pending", ready=False, age=1800,
            scheduling={"reason": "Unschedulable", "message": "0/2 nodes: Insufficient memory"})
    f = [x for x in analyze_cluster(snap([p]), TH) if x["rule"] == "pod-unschedulable"][0]
    assert f["severity"] == "high" and "Insufficient memory" in f["evidence"]


def test_fresh_pending_is_low():
    f = [x for x in analyze_cluster(snap([pod(phase="Pending", ready=False, age=20)]), TH) if x["rule"] == "pod-pending"][0]
    assert f["severity"] == "low"


def test_memory_near_limit_severity_levels():
    near = pod(containers=[container(mem_usage=235 * MI)])      # ~92% of 256Mi
    crit = pod(containers=[container(mem_usage=250 * MI)])      # ~98%
    ok = pod(containers=[container(mem_usage=100 * MI)])
    sev = lambda s: [f["severity"] for f in analyze_cluster(snap([s]), TH) if f["rule"] == "container-memory-near-limit"]
    assert sev(near) == ["medium"] and sev(crit) == ["high"] and sev(ok) == []


def test_cpu_throttling_and_missing_limits():
    assert "container-cpu-near-limit" in rules(snap([pod(containers=[container(cpu_usage_m=480)])]))
    bare = container(cpu_request_m=None, mem_request=None, mem_limit=None)
    assert "pod-resource-config" in rules(snap([pod(containers=[bare])]))
    assert "pod-resource-config" not in rules(snap([pod(ns="kube-system", containers=[bare])]))


def test_restart_rule_not_duplicated_with_crashloop():
    r = rules(snap([pod(restarts=9, containers=[container(restarts=9)])]))
    assert "pod-restarts" in r
    c = container(restarts=9, state="waiting", state_reason="CrashLoopBackOff")
    assert "pod-restarts" not in rules(snap([pod(restarts=9, ready=False, containers=[c])]))


def test_succeeded_job_not_flagged():
    findings = analyze_cluster(snap([pod(phase="Succeeded", ready=False)]), TH)
    assert findings[0]["rule"] == "all-clear"


def test_node_usage_and_requests():
    node = {"name": "n1", "conditions": {"Ready": True}, "allocatable_cpu_m": 4000, "allocatable_mem": 8 * 1024**3,
            "usage_cpu_m": 3900, "usage_mem": 1 * 1024**3, "requests_cpu_m": 3800, "requests_mem": 1 * 1024**3}
    r = rules(snap(nodes=[node]))
    assert {"node-cpu-usage", "node-cpu-requests"} <= r
    assert "node-memory-usage" not in r


def test_node_without_metrics_skips_usage_rules():
    node = {"name": "n1", "conditions": {"Ready": True}, "allocatable_cpu_m": 4000, "allocatable_mem": 1,
            "usage_cpu_m": None, "usage_mem": None, "requests_cpu_m": 0, "requests_mem": 0}
    assert rules(snap(nodes=[node])) == {"all-clear"}


def test_repeated_warning_events():
    e = {"namespace": "default", "reason": "FailedScheduling", "type": "Warning", "count": 5,
         "object_kind": "Pod", "object_name": "x", "message": "m"}
    f = [x for x in analyze_cluster(snap(events=[e]), TH) if x["rule"] == "event-warning-repeated"]
    assert f and f[0]["severity"] == "medium" and f[0]["resource"] == "pod/default/x"
    assert "event-warning-repeated" not in rules(snap(events=[{**e, "count": 1}]))
    assert "event-warning-repeated" not in rules(snap(events=[{**e, "type": "Normal"}]))


def test_metrics_unavailable_note_only_in_live_mode():
    unavailable = {"available": False, "reason": "Metrics API not found."}
    assert "metrics-unavailable" in rules(snap(mode="live", metrics=unavailable))
    assert "metrics-unavailable" not in rules(snap(mode="demo", metrics=unavailable))


def test_findings_sorted_by_severity():
    findings = analyze_cluster(_demo_snapshot(), TH)
    order = {"high": 0, "medium": 1, "low": 2, "info": 3}
    assert [order[f["severity"]] for f in findings] == sorted(order[f["severity"]] for f in findings)


def test_demo_snapshot_exercises_main_rules():
    r = rules(_demo_snapshot())
    assert {"container-oomkilled", "container-crashloop", "pod-unschedulable", "node-pressure",
            "node-memory-usage", "container-memory-near-limit", "event-warning-repeated"} <= r


def test_utilization_summary_ranks_pods():
    s = utilization_summary(_demo_snapshot(), top_n=2)
    assert s["metrics_available"] and len(s["top_cpu_pods"]) == 2
    assert s["top_cpu_pods"][0]["name"] == "batch-job-x9k2"
    assert s["top_memory_pods"][0]["name"] == "report-gen-5d8f"


def test_questions_use_metrics():
    s = _demo_snapshot()
    assert "batch-job-x9k2" in answer_question("which pods use the most cpu?", s)
    assert "OOMKilled" in answer_question("any OOM kills?", s)
    assert "Insufficient memory" in answer_question("why are pods pending?", s)
    assert "CrashLoopBackOff" in answer_question("what is wrong with api-55cc9f", s)
    assert "Metrics Server" in answer_question("cpu usage?", {**s, "metrics": {"available": False, "reason": ""}})
