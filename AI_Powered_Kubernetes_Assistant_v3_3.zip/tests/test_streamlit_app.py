"""Runs streamlit_app.py end to end against a fake `streamlit` (the real one is not needed for these checks)."""
import importlib
import json
import sys

import pytest

from tests.fake_streamlit import FakeStreamlit
from app.llm import LLMClient

HOME, MON, LOGS, EVENTS, AI, DASH, SET = "🏠 Home", "📊 Cluster Monitoring", "📜 Logs Analysis", "🔔 Event Analysis", "🤖 AI Assistant", "📈 Dashboard", "⚙️ Settings"


def run(page, inputs=None, pressed=(), env=None, patch=None, monkeypatch=None):
    for k, v in {"DEMO_MODE": "true", **(env or {})}.items():
        monkeypatch.setenv(k, v)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False) if "ANTHROPIC_API_KEY" not in (env or {}) else None
    fake = FakeStreamlit(page, inputs, pressed)
    monkeypatch.setitem(sys.modules, "streamlit", fake)
    sys.modules.pop("streamlit_app", None)
    mod = importlib.import_module("streamlit_app")
    if patch:
        patch(mod)
    mod.main()
    return fake


@pytest.mark.parametrize("page", [HOME, MON, LOGS, EVENTS, AI, DASH, SET])
def test_every_page_renders_in_demo_mode(page, monkeypatch):
    fake = run(page, monkeypatch=monkeypatch)
    assert fake.named("set_page_config") and fake.texts("title", "subheader")


def test_home_shows_the_four_tiles_with_real_numbers(monkeypatch):
    blob = " ".join(run(HOME, monkeypatch=monkeypatch).html_blocks())
    for expected in ("Cluster Health", "Critical", "5 Running", "2 Ready", "Alerts", "Active"):
        assert expected in blob, expected


def test_dashboard_has_gauges_donut_and_time_series(monkeypatch):
    fake = run(DASH, monkeypatch=monkeypatch)
    blob = " ".join(fake.html_blocks())
    assert "CPU Usage" in blob and "Memory Usage" in blob and 'aria-label="Pod status"' in blob
    chart = fake.named("line_chart")[0][1][0]
    assert list(chart.columns) == ["CPU", "Memory"] and len(chart) > 10 and chart.index.is_monotonic_increasing


def test_logs_page_fetch_analyze_and_mask(monkeypatch):
    inputs = {"Namespace": "payments", "Pod": "api-55cc9f"}
    fake = run(LOGS, inputs, pressed=["Fetch Logs"], monkeypatch=monkeypatch)
    blob = " ".join(fake.html_blocks())
    assert "OutOfMemoryError" in blob and "ERROR" in blob
    assert "abcdef1234567890abcdef" not in blob and "[REDACTED]" in blob          # bearer token masked by default
    assert any("ran out of memory" in e[1][0] for e in fake.named("expander"))
    shown = run(LOGS, {**inputs, "Mask secrets": False}, pressed=["Fetch Logs"], monkeypatch=monkeypatch)
    assert "abcdef1234567890abcdef" in " ".join(shown.html_blocks())              # unmasked only when the operator opts out


def test_logs_all_pods_fan_out_and_prefix(monkeypatch):
    fake = run(LOGS, {"Namespace": "payments", "Pod": "All Pods"}, pressed=["Fetch Logs"], monkeypatch=monkeypatch)
    blob = " ".join(fake.html_blocks())
    assert "[api-55cc9f]" in blob and "[cache-0]" in blob


def test_logs_page_before_fetch_asks_for_a_choice(monkeypatch):
    fake = run(LOGS, monkeypatch=monkeypatch)
    assert any("Fetch Logs" in t for t in fake.texts("caption")) and not fake.html_blocks()[1:]


def test_ai_playbook_recommendation_without_claude(monkeypatch):
    fake = run(AI, {"Issue Description": "Pod is not starting and showing CrashLoopBackOff"}, pressed=["Get AI Recommendation"],
               monkeypatch=monkeypatch)
    md = " ".join(fake.texts("markdown"))
    assert "1. Check the pod logs" in md and "2. " in md and "Matched: CrashLoopBackOff" in " ".join(fake.texts("caption"))


def test_ai_uses_claude_when_configured_and_falls_back_cleanly(monkeypatch):
    seen = {}

    def good(mod):
        mod.ai_client = lambda: LLMClient("k", post=lambda u, h, b, t: seen.update(body=b) or {"content": [{"type": "text", "text": "Root cause: X"}]})
    fake = run(AI, {"Issue Description": "api-55cc9f crashing"}, pressed=["Get AI Recommendation"], patch=good, monkeypatch=monkeypatch)
    assert "Root cause: X" in " ".join(fake.texts("markdown")) and "api-55cc9f" in json.dumps(seen["body"])
    from app.llm import LLMError

    def bad(mod):
        def boom(*a, **k): raise LLMError("down")
        mod.ai_client = lambda: LLMClient("k", post=boom)
    fake2 = run(AI, {"Issue Description": "pod CrashLoopBackOff"}, pressed=["Get AI Recommendation"], patch=bad, monkeypatch=monkeypatch)
    assert any("unavailable" in t for t in fake2.texts("warning")) and "1. " in " ".join(fake2.texts("markdown"))


def test_settings_refresh_choice_is_kept_under_a_plain_key(monkeypatch):
    fake = run(SET, {"Auto-refresh (seconds, 0 = off)": 60}, monkeypatch=monkeypatch)
    assert fake.session_state["refresh_seconds"] == 60
    fake2 = run(DASH, monkeypatch=monkeypatch)                     # default 30 s -> body is wrapped in a fragment
    assert fake2.named("fragment")[0][2]["run_every"] == 30


def test_hostile_cluster_text_never_reaches_html_blocks(monkeypatch):
    from app.kube import _demo_snapshot
    evil = "<img src=x onerror=alert(1)>"

    def patch(mod):
        def snap(cfg=None):
            s = _demo_snapshot()
            s["pods"][0]["name"] = evil
            s["events"][0]["message"] = evil
            s["events"][0]["object_name"] = evil
            return s
        mod.get_snapshot = snap
    for page, inputs, pressed in ((HOME, {}, ()), (MON, {}, ()), (EVENTS, {}, ()), (DASH, {}, ()),
                                  (LOGS, {"Namespace": "default", "Pod": "All Pods"}, ["Fetch Logs"])):
        fake = run(page, inputs, pressed, patch=patch, monkeypatch=monkeypatch)
        assert all("<img" not in b and "onerror" not in b for b in fake.html_blocks()), page


def test_multi_cluster_selector_and_error_state(monkeypatch, tmp_path):
    cfg = tmp_path / "c.json"
    cfg.write_text(json.dumps({"clusters": [{"name": "prod-eu", "in_cluster": True}, {"name": "prod-us", "in_cluster": True}]}))
    fake = run(HOME, {"Cluster": "prod-us"}, env={"CLUSTERS_CONFIG": str(cfg)}, monkeypatch=monkeypatch)
    assert any(c[1][1] == ["prod-eu", "prod-us"] for c in fake.named("selectbox") if c[1][0] == "Cluster")

    def err(mod):
        mod.get_snapshot = lambda cfg=None: {"mode": "error", "error": "Kubernetes connection failed: ApiException.", "pods": [], "nodes": [], "events": [],
                                             "metrics": {"available": False, "reason": ""}}
    fake2 = run(HOME, patch=err, monkeypatch=monkeypatch)
    assert fake2.texts("error") == ["Kubernetes connection failed: ApiException."] and "Unknown" in " ".join(fake2.html_blocks())


def test_hostile_log_lines_are_escaped_in_the_log_view(monkeypatch):
    evil = "ERROR <img src=x onerror=alert(1)> <script>steal()</script>"

    def patch(mod):
        mod.fetch_pod_logs = lambda cfg, ns, pod, tail=200, previous=False, container=None: evil
    fake = run(LOGS, {"Namespace": "payments", "Pod": "api-55cc9f"}, pressed=["Fetch Logs"], patch=patch, monkeypatch=monkeypatch)
    blob = " ".join(fake.html_blocks())
    assert "&lt;img" in blob and "<img" not in blob and "<script>steal" not in blob
