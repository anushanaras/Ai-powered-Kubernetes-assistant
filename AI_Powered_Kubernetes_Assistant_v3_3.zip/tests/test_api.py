"""HTTP-level tests. Skipped automatically when FastAPI/httpx are not installed (pip install -r requirements-dev.txt)."""
import pytest

pytest.importorskip("fastapi")
pytest.importorskip("httpx")

from fastapi.testclient import TestClient  # noqa: E402

from app import main  # noqa: E402
from app.llm import LLMClient, LLMError  # noqa: E402


@pytest.fixture
def client(monkeypatch):
    for var in ("API_KEY", "ANTHROPIC_API_KEY", "API_KEYS_FILE", "OIDC_ISSUER", "OIDC_AUDIENCE", "CLUSTERS_CONFIG",
                "AUTHZ_POLICY", "PROMETHEUS_URL", "METRICS_TOKEN"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("DEMO_MODE", "true")
    main.limiter._hits.clear()
    with TestClient(main.app) as c:      # `with` runs the lifespan (seeds demo history)
        yield c


def fake_llm(text=None, error=None):
    def post(url, headers, body, timeout):
        if error:
            raise error
        return {"content": [{"type": "text", "text": text}]}
    return lambda: LLMClient("k", "claude-test", post=post)


def test_health_and_dashboard(client):
    assert client.get("/health").json() == {"status": "ok"}
    page = client.get("/")
    assert page.status_code == 200 and "Resource utilization" in page.text
    assert page.headers["x-frame-options"] == "DENY" and "content-security-policy" in page.headers


def test_diagnostics_filters_and_ordering(client):
    all_f = client.get("/api/diagnostics").json()["findings"]
    assert all_f[0]["severity"] == "high" and any(f["rule"] == "pod-memory-growth" for f in all_f)
    high = client.get("/api/diagnostics", params={"severity": "high"}).json()["findings"]
    assert high and {f["severity"] for f in high} == {"high"}
    pay = client.get("/api/diagnostics", params={"namespace": "payments"}).json()["findings"]
    assert pay and {f["namespace"] for f in pay} == {"payments"}
    assert client.get("/api/diagnostics", params={"severity": "bogus"}).status_code == 422


def test_metrics_history_and_pod_endpoints(client):
    assert client.get("/api/metrics").json()["top_cpu_pods"]
    assert len(client.get("/api/history/nodes").json()["demo-node-2"]) > 50
    hist = client.get("/api/history/pods/default/report-gen-5d8f").json()
    assert hist["memory_trend"]["slope_per_hour"] > 0
    assert client.get("/api/history/pods/default/nope").status_code == 404
    assert client.get("/api/pods/payments/api-55cc9f").json()["findings"]
    assert client.get("/api/pods/payments/nope").status_code == 404


def test_auth_enforced_when_key_set(client, monkeypatch):
    monkeypatch.setenv("API_KEY", "s3cret")
    assert client.get("/api/cluster").status_code == 401
    assert client.get("/api/cluster", headers={"X-API-Key": "wrong"}).status_code == 401
    assert client.get("/api/cluster", headers={"X-API-Key": "s3cret"}).status_code == 200
    assert client.get("/api/cluster", headers={"Authorization": "Bearer s3cret"}).status_code == 200
    assert client.get("/health").status_code == 200           # probes stay open
    assert client.get("/").headers["www-authenticate"].startswith("Basic")


def test_ask_uses_rules_without_llm(client):
    r = client.post("/api/ask", json={"question": "which pods use the most memory?"}).json()
    assert r["source"] == "rules" and "report-gen-5d8f" in r["answer"]
    assert client.post("/api/ask", json={"question": "x"}).status_code == 422


def test_ask_uses_claude_when_configured_and_falls_back_on_error(client, monkeypatch):
    monkeypatch.setattr(main, "get_llm", fake_llm("Raise the memory limit on api."))
    r = client.post("/api/ask", json={"question": "why is api failing?"}).json()
    assert r["source"] == "llm" and r["answer"] == "Raise the memory limit on api."
    monkeypatch.setattr(main, "get_llm", fake_llm(error=LLMError("Claude API returned HTTP 529")))
    r = client.post("/api/ask", json={"question": "which pods are unhealthy?"}).json()
    assert r["source"] == "rules" and "Pods to inspect" in r["answer"] and "529" in r["note"]


def test_summary_and_rate_limit(client, monkeypatch):
    assert client.get("/api/summary").json()["source"] == "rules"
    monkeypatch.setattr(main.limiter, "limit", 2)
    main.limiter._hits.clear()
    codes = [client.post("/api/ask", json={"question": "pods?"}).status_code for _ in range(3)]
    assert codes == [200, 200, 429]
