"""Live-path normalization, tested with fake Kubernetes objects (no cluster needed)."""
from datetime import datetime, timezone
from types import SimpleNamespace as NS

from app.kube import (attach_node_requests, event_to_dict, node_to_dict, parse_node_metrics,
                      parse_pod_metrics, pod_to_dict, _fetch_metrics)

MI = 1024**2


def fake_pod():
    spec_c = NS(name="api", resources=NS(requests={"cpu": "200m", "memory": "256Mi"},
                                          limits={"cpu": "1", "memory": "512Mi"}))
    status = NS(name="api", ready=False, restart_count=6,
                state=NS(waiting=NS(reason="CrashLoopBackOff"), running=None, terminated=None),
                last_state=NS(terminated=NS(reason="OOMKilled", exit_code=137)))
    return NS(metadata=NS(name="api-1", namespace="payments", owner_references=[NS(kind="ReplicaSet")],
                          creation_timestamp=datetime.fromtimestamp(1000, tz=timezone.utc)),
              spec=NS(node_name="n1", containers=[spec_c]),
              status=NS(phase="Running", container_statuses=[status],
                        conditions=[NS(type="PodScheduled", status="True", reason=None, message=None)]))


def test_pod_to_dict_maps_state_limits_and_usage():
    usage = {"api": {"cpu_m": 40.0, "mem": 498 * MI}}
    d = pod_to_dict(fake_pod(), usage, now=1000 + 3600)
    c = d["containers"][0]
    assert d["namespace"] == "payments" and d["restarts"] == 6 and d["ready"] is False
    assert d["age_seconds"] == 3600 and d["owner_kind"] == "ReplicaSet" and d["scheduling"] is None
    assert c["state_reason"] == "CrashLoopBackOff" and c["last_terminated_reason"] == "OOMKilled"
    assert c["cpu_limit_m"] == 1000 and c["mem_limit"] == 512 * MI and c["mem_usage"] == 498 * MI


def test_pod_without_metrics_has_none_usage():
    assert pod_to_dict(fake_pod())["containers"][0]["mem_usage"] is None


def test_unschedulable_condition_captured():
    p = NS(metadata=NS(name="w", namespace="d", owner_references=None, creation_timestamp=None),
           spec=NS(node_name=None, containers=[]),
           status=NS(phase="Pending", container_statuses=None,
                     conditions=[NS(type="PodScheduled", status="False", reason="Unschedulable", message="no fit")]))
    d = pod_to_dict(p)
    assert d["scheduling"] == {"reason": "Unschedulable", "message": "no fit"} and d["ready"] is False


def test_metrics_parsing_and_node_requests():
    pm = parse_pod_metrics([{"metadata": {"name": "api-1", "namespace": "payments"},
                             "containers": [{"name": "api", "usage": {"cpu": "40m", "memory": "498Mi"}}]}])
    assert pm[("payments", "api-1")]["api"]["mem"] == 498 * MI
    nm = parse_node_metrics([{"metadata": {"name": "n1"}, "usage": {"cpu": "1500000000n", "memory": "2Gi"}}])
    assert nm["n1"]["cpu_m"] == 1500.0

    node = node_to_dict(NS(metadata=NS(name="n1"),
                           status=NS(allocatable={"cpu": "4", "memory": "8Gi"},
                                     conditions=[NS(type="Ready", status="True")])), nm["n1"])
    pod = pod_to_dict(fake_pod())
    attach_node_requests([pod], [node])
    assert node["allocatable_cpu_m"] == 4000 and node["requests_cpu_m"] == 200 and node["pod_count"] == 1
    assert node["conditions"] == {"Ready": True}


def test_event_to_dict():
    e = NS(metadata=NS(name="e", namespace="d", creation_timestamp=None), reason="BackOff", message="x" * 900,
           type="Warning", count=None, involved_object=NS(kind="Pod", name="p"),
           last_timestamp=datetime.fromtimestamp(5, tz=timezone.utc), event_time=None)
    d = event_to_dict(e)
    assert len(d["message"]) == 500 and d["count"] == 1 and d["last_seen"] == 5 and d["object_name"] == "p"


def test_fetch_metrics_reports_missing_metrics_server():
    class Err(Exception):
        status = 404

    class Api:
        def list_cluster_custom_object(self, *a):
            raise Err()

    pods, nodes, status = _fetch_metrics(Api())
    assert status["available"] is False and "Metrics Server" in status["reason"] and pods == {} and nodes == {}
