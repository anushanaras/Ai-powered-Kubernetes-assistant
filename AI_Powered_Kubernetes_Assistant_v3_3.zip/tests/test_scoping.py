"""Namespace scoping end to end through the analyzer and the Claude digest (no web framework needed)."""
import json

from app.analyzer import analyze_cluster, answer_question, utilization_summary
from app.authz import Policy, Principal, filter_findings, filter_snapshot
from app.history import History, seed_demo_history
from app.kube import _demo_snapshot
from app.llm import build_context

POLICY = Policy.from_dict({"rules": [
    {"match": {"groups": ["team-payments"]}, "role": "operator", "clusters": ["*"], "namespaces": ["payments"]},
    {"match": {"groups": ["admins"]}, "role": "admin", "clusters": ["*"], "namespaces": ["*"]}]})


def principal(group):
    return POLICY.resolve(Principal("u", "", frozenset({group}), "oidc"))


def setup():
    snap = _demo_snapshot()
    hist = History()
    seed_demo_history(hist, snap)
    return snap, hist


def test_scoped_user_digest_contains_no_foreign_data():
    snap, hist = setup()
    p = principal("team-payments")
    view = filter_snapshot(snap, p)
    findings = filter_findings(analyze_cluster(view, history=hist), p)
    ctx = build_context(view, findings, utilization_summary(view))
    digest = json.dumps(ctx)
    assert findings and "payments/" in digest
    for foreign in ("default/", "report-gen", "worker-6f77ab", "web-7b9d8c"):
        assert foreign not in digest, foreign
    # Node-level data (utilization, other tenants' load) is hidden; a pod's own nodeName is not secret to its owner.
    assert ctx["nodes"] == [] and ctx["totals"]["nodes"] == 0
    assert all(p["pod"].startswith("payments/") for p in ctx["problem_pods"] + ctx["top_memory_pods"] + ctx["top_cpu_pods"])


def test_scoped_findings_never_include_other_namespaces_or_nodes():
    snap, hist = setup()
    p = principal("team-payments")
    findings = filter_findings(analyze_cluster(filter_snapshot(snap, p), history=hist), p)
    assert {f["namespace"] for f in findings} == {"payments"}
    assert all(not f["resource"].startswith("node/") for f in findings)


def test_rules_answers_are_scoped_too():
    snap, hist = setup()
    p = principal("team-payments")
    text = answer_question("which pods use the most memory?", filter_snapshot(snap, p), hist)
    assert "report-gen" not in text and "web-7b9d8c" not in text


def test_admin_sees_everything():
    snap, hist = setup()
    p = principal("admins")
    view = filter_snapshot(snap, p)
    assert view is snap
    assert {f.get("namespace") for f in filter_findings(analyze_cluster(view, history=hist), p)} >= {"default", "payments"}
