import time

import pytest

jwt = pytest.importorskip("jwt")
pytest.importorskip("cryptography")
from cryptography.hazmat.primitives.asymmetric import rsa  # noqa: E402

from app.authn import ApiKeyStore, AuthError, Authenticator, OidcValidator, sha256_hex  # noqa: E402

ISS, AUD = "https://idp.example.com", "k8s-assistant"
KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)
OTHER = rsa.generate_private_key(public_exponent=65537, key_size=2048)


def token(key=KEY, **over):
    claims = {"iss": ISS, "aud": AUD, "sub": "alice", "email": "alice@example.com",
              "groups": ["team-payments"], "exp": int(time.time()) + 300}
    claims.update(over)
    return jwt.encode({k: v for k, v in claims.items() if v is not None}, key, algorithm="RS256")


def validator():
    return OidcValidator(ISS, AUD, key_resolver=lambda t: KEY.public_key())


def test_valid_token_yields_principal():
    p = validator().validate(token())
    assert p.subject == "alice" and p.email == "alice@example.com"
    assert p.groups == {"team-payments"} and p.auth_method == "oidc"


@pytest.mark.parametrize("over", [{"exp": int(time.time()) - 3600}, {"iss": "https://evil.example"},
                                   {"aud": "someone-else"}, {"sub": None}])
def test_bad_claims_rejected(over):
    with pytest.raises(AuthError):
        validator().validate(token(**over))


def test_wrong_signature_rejected():
    with pytest.raises(AuthError):
        validator().validate(token(key=OTHER))


def test_alg_none_and_hs256_confusion_rejected():
    unsigned = jwt.encode({"iss": ISS, "aud": AUD, "sub": "x", "exp": int(time.time()) + 60}, None, algorithm="none")
    with pytest.raises(AuthError):
        validator().validate(unsigned)
    with pytest.raises(ValueError):
        OidcValidator(ISS, AUD, algorithms=["HS256"], key_resolver=lambda t: "x")


def test_groups_claim_as_string_and_missing():
    v = validator()
    assert v.validate(token(groups="solo")).groups == {"solo"}
    assert v.validate(token(groups=None)).groups == frozenset()


def test_api_keys_hashed_and_legacy():
    store = ApiKeyStore([{"name": "ci", "sha256": sha256_hex("ci-secret"), "groups": ["platform-admins"]}], legacy_key="old")
    assert store.authenticate("ci-secret").subject == "apikey:ci"
    assert store.authenticate("ci-secret").groups == {"platform-admins"}
    assert store.authenticate("old").groups == {"__legacy_admin__"}
    assert store.authenticate("nope") is None


def test_authenticator_dispatch():
    keys = ApiKeyStore([{"name": "ci", "sha256": sha256_hex("k"), "groups": []}])
    auth = Authenticator(keys, validator())
    assert auth.authenticate({"Authorization": f"Bearer {token()}"}).auth_method == "oidc"
    assert auth.authenticate({"X-API-Key": "k"}).auth_method == "api-key"
    assert auth.authenticate({"X-Forwarded-Access-Token": token()}).subject == "alice"
    for headers in ({}, {"X-API-Key": "bad"}, {"Authorization": f"Bearer {token(key=OTHER)}"}):
        with pytest.raises(AuthError):
            auth.authenticate(headers)


def test_anonymous_only_when_nothing_configured():
    open_auth = Authenticator(ApiKeyStore([]), None, anonymous_allowed=True)
    assert open_auth.authenticate({}).auth_method == "anonymous"
    closed = Authenticator(ApiKeyStore([], "k"), None, anonymous_allowed=False)
    with pytest.raises(AuthError):
        closed.authenticate({})


def test_missing_key_file_fails_closed(monkeypatch, tmp_path):
    from app.security import anonymous_allowed
    monkeypatch.setenv("DEMO_MODE", "true")
    monkeypatch.delenv("API_KEY", raising=False)
    monkeypatch.delenv("OIDC_ISSUER", raising=False)
    monkeypatch.setenv("API_KEYS_FILE", str(tmp_path / "does-not-exist.json"))
    assert ApiKeyStore.from_env().enabled is False          # no keys loaded, no crash
    assert anonymous_allowed() is False                     # but anonymous access is NOT silently enabled
    monkeypatch.delenv("API_KEYS_FILE")
    assert anonymous_allowed() is True                      # demo mode with nothing configured stays open
    monkeypatch.setenv("DEMO_MODE", "false")
    assert anonymous_allowed() is False                     # live mode is never anonymous...
    monkeypatch.setenv("ALLOW_INSECURE", "true")
    assert anonymous_allowed() is True                      # ...unless explicitly overridden
    monkeypatch.setenv("OIDC_ISSUER", "https://idp")
    assert anonymous_allowed() is False                     # any configured auth wins over the override
