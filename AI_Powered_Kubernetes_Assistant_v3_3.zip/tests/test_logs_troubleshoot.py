import json

from app.logs import ai_signals, analyze_logs, demo_logs, filter_lines, parse_log, redact
from app.troubleshoot import recommend, related_findings, rules_recommendation
from app.llm import LLMClient


def test_parse_plain_kv_and_json_formats():
    text = "\n".join(["2026-10-14 12:01:32 INFO Starting", "2026-10-14T12:04:22Z ERROR boom", "[WARNING] disk at 91%",
                      'level=error msg="db down"', json.dumps({"level": "fatal", "msg": "panic", "time": "t1"}), "", "plain text"])
    lines = parse_log(text)
    assert [l["level"] for l in lines] == ["INFO", "ERROR", "WARN", "ERROR", "ERROR", "UNKNOWN"]
    assert lines[0]["ts"] == "2026-10-14 12:01:32" and lines[0]["message"] == "Starting" and lines[4]["message"] == "panic"


def test_parse_keeps_last_lines_and_strips_control_chars():
    lines = parse_log("\n".join(f"INFO line {i}" for i in range(50)), max_lines=10)
    assert len(lines) == 10 and lines[-1]["message"].endswith("line 49")
    assert "\x00" not in parse_log("INFO a\x00b")[0]["message"]


def test_redaction_covers_common_secrets():
    samples = {"Authorization: Bearer abcdef1234567890xyz": "abcdef1234567890", "password=hunter2hunter2": "hunter2",
               "AKIAABCDEFGHIJKLMNOP": "AKIAABCDEFGHIJKLMNOP", "postgres://app:s3cr3t@db:5432/x": "s3cr3t",
               "token: ghp_abcdefghijklmnopqrstuvwx": "ghp_abcdef", '{"api_key":"sk-live-123456"}': "sk-live-123456",
               "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abcdefghijkl": "eyJzdWIi"}
    for raw, secret in samples.items():
        assert secret not in redact(raw), raw
    assert "REDACTED" in redact("-----BEGIN RSA PRIVATE KEY-----\nMIIabc\n-----END RSA PRIVATE KEY-----")
    assert redact("INFO all good") == "INFO all good"


def test_pattern_detection_and_ranking():
    a = analyze_logs(parse_log(demo_logs("api-55cc9f")))
    ids = [f["pattern"] for f in a["findings"]]
    assert "oom" in ids and "conn-refused" in ids and "retry" in ids
    assert a["findings"][0]["severity"] == "high" and a["counts"]["ERROR"] == 3 and a["first_error"]["message"].startswith("java.lang")
    assert a["error_rate"] == round(100 * 3 / a["total"], 1)
    assert analyze_logs(parse_log(demo_logs("web-1")))["findings"] == []
    assert analyze_logs([])["error_rate"] == 0.0


def test_filter_lines():
    lines = parse_log(demo_logs("api-55cc9f"))
    assert {l["level"] for l in filter_lines(lines, ["ERROR"])} == {"ERROR"}
    assert all("memory" in l["message"].lower() for l in filter_lines(lines, query="MEMORY"))


def test_ai_signals_never_leak_secrets():
    sig = ai_signals(analyze_logs(parse_log("ERROR 401 unauthorized: Bearer abcdef1234567890abcdef\nERROR connection refused password=hunter2hunter2")))
    blob = json.dumps(sig)
    assert "abcdef1234567890" not in blob and "hunter2" not in blob and sig


def test_playbook_matching_and_fallback():
    r = rules_recommendation("Pod is not starting and showing CrashLoopBackOff")
    assert r["matched"] == ["CrashLoopBackOff"] and len(r["steps"]) >= 4 and "logs" in r["steps"][0].lower()
    assert {"OOMKilled", "Pending / FailedScheduling"} <= set(rules_recommendation("OOMKilled then Pending forever")["matched"])
    g = rules_recommendation("something odd happened")
    assert g["matched"] == [] and len(g["steps"]) == 5


def test_related_findings_by_pod_name():
    findings = [{"resource": "pod/payments/api-55cc9f"}, {"resource": "pod/default/web-7b9d8c"}]
    assert related_findings("api-55cc9f keeps crashing", findings) == [findings[0]]


def test_recommend_uses_claude_when_available_and_falls_back_on_error():
    from app.kube import _demo_snapshot
    from app.analyzer import analyze_cluster, utilization_summary
    snap = _demo_snapshot(); f = analyze_cluster(snap); u = utilization_summary(snap)
    seen = {}
    def ok_post(url, headers, body, timeout):
        seen["prompt"] = body["messages"][0]["content"]
        return {"content": [{"type": "text", "text": "1. Check logs"}]}
    r = recommend("api crashing", snap, f, u, LLMClient("k", post=ok_post),
                  log_analysis=analyze_logs(parse_log("ERROR boom password=hunter2hunter2")))
    assert r["source"] == "llm" and r["text"] == "1. Check logs" and "hunter2" not in seen["prompt"] and "log_signals" in seen["prompt"]
    from app.llm import LLMError
    def bad_post(*a, **k): raise LLMError("down")
    r2 = recommend("pod CrashLoopBackOff", snap, f, u, LLMClient("k", post=bad_post))
    assert r2["source"] == "rules" and "unavailable" in r2["note"] and r2["steps"]
    assert recommend("x", snap, f, u, None)["source"] == "rules"
