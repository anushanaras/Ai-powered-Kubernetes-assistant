import pytest

from app.metrics import build_registry
from app.prom import PrometheusClient, PromError, _lv


def test_exposition_format_and_label_escaping():
    r = build_registry()
    r.inc("k8s_assistant_http_requests_total", method="GET", route="/api/x", status="200")
    r.inc("k8s_assistant_http_requests_total", method="GET", route="/api/x", status="200")
    r.observe("k8s_assistant_http_request_duration_seconds", 0.03, route='/a"b')
    out = r.render()
    assert "# TYPE k8s_assistant_http_requests_total counter" in out
    assert 'k8s_assistant_http_requests_total{method="GET",route="/api/x",status="200"} 2' in out
    assert 'route="/a\\"b"' in out
    assert 'k8s_assistant_http_request_duration_seconds_bucket{route="/a\\"b",le="0.025"} 0' in out
    assert 'le="0.05"} 1' in out and 'le="+Inf"} 1' in out and "_count" in out


def test_gauge_family_replaces_stale_series():
    r = build_registry()
    r.set_gauge_family("k8s_assistant_findings", [({"cluster": "a", "severity": "high", "rule": "r1"}, 2)])
    assert 'rule="r1",severity="high"} 2' in r.render()
    r.set_gauge_family("k8s_assistant_findings", [({"cluster": "a", "severity": "low", "rule": "r2"}, 1)])
    out = r.render()
    assert 'rule="r1"' not in out and 'rule="r2",severity="low"} 1' in out


def test_promql_label_injection_blocked():
    assert _lv("payments") == "payments"
    for bad in ('x"} or vector(1) #', "a b", "", "ns\n"):
        with pytest.raises(PromError):
            _lv(bad)


def test_prometheus_client_builds_queries_and_parses():
    seen = {}

    def fake_get(url, headers, timeout):
        seen["url"], seen["headers"] = url, headers
        return {"status": "success", "data": {"result": [{"metric": {}, "values": [[1, "10"], [2, "NaN"], [3, "30"]]}]}}

    c = PrometheusClient("http://prom:9090/", token="t", cluster_label="cluster", get=fake_get)
    pts = c.pod_memory("prod-eu", "payments", "api-1", 0, 100)
    assert pts == [(1.0, 10.0), (3.0, 30.0)]            # NaN dropped
    assert seen["headers"] == {"Authorization": "Bearer t"} and seen["url"].startswith("http://prom:9090/api/v1/query_range?")
    assert "container_memory_working_set_bytes" in seen["url"] and "prod-eu" in seen["url"]
    with pytest.raises(PromError):
        c.pod_memory("prod-eu", 'x"}', "p", 0, 1)


def test_prometheus_error_status():
    c = PrometheusClient("http://p", get=lambda *a, **k: {"status": "error"})
    with pytest.raises(PromError):
        c.query_range("up", 0, 1, 15)
