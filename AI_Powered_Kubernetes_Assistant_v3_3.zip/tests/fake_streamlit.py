"""A small stand-in for the `streamlit` module: records what the app renders and feeds it scripted widget values."""
import functools


class SessionState(dict):
    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError:
            raise AttributeError(k)

    def __setattr__(self, k, v):
        self[k] = v


class _Ctx:
    """Context manager / column object: widget calls on it are routed to the same recorder."""
    def __init__(self, st):
        self._st = st

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __getattr__(self, name):
        return getattr(self._st, name)


class FakeStreamlit:
    def __init__(self, page=None, inputs=None, pressed=()):
        self.session_state = SessionState()
        self.page, self.inputs, self.pressed = page, dict(inputs or {}), set(pressed)
        self.calls = []                      # (name, args, kwargs)
        self.sidebar = _Ctx(self)
        self._memo = {}

    # ---- recording helpers
    def _rec(self, name, *a, **k):
        self.calls.append((name, a, k))

    def texts(self, *names):
        return [str(c[1][0]) for c in self.calls if c[0] in names and c[1]]

    def html_blocks(self):
        return [str(c[1][0]) for c in self.calls if c[0] == "markdown" and c[2].get("unsafe_allow_html")]

    def named(self, name):
        return [c for c in self.calls if c[0] == name]

    # ---- decorators
    def cache_resource(self, fn=None, **kw):
        def wrap(f):
            @functools.wraps(f)
            def inner(*a):
                key = (f.__name__, a)
                if key not in self._memo:
                    self._memo[key] = f(*a)
                return self._memo[key]
            return inner
        return wrap(fn) if callable(fn) else wrap

    def fragment(self, fn=None, run_every=None):
        self._rec("fragment", run_every=run_every)
        return (lambda f: f) if fn is None else fn

    # ---- layout
    def columns(self, spec, **kw):
        n = spec if isinstance(spec, int) else len(spec)
        return [_Ctx(self) for _ in range(n)]

    def tabs(self, labels):
        return [_Ctx(self) for _ in labels]

    def expander(self, label, **kw):
        self._rec("expander", label)
        return _Ctx(self)

    def spinner(self, text="", **kw):
        return _Ctx(self)

    # ---- inputs
    def radio(self, label, options, **kw):
        return self.page if self.page in options else options[0]

    def selectbox(self, label, options, index=0, **kw):
        options = list(options)
        v = self.inputs.get(label, options[index] if options else None)
        self._rec("selectbox", label, options)
        return v

    def multiselect(self, label, options=(), default=None, **kw):
        return self.inputs.get(label, list(default) if default else [])

    def text_area(self, label, **kw):
        return self.inputs.get(label, "")

    def text_input(self, label, **kw):
        return self.inputs.get(label, "")

    def slider(self, label, min_value=None, max_value=None, value=None, **kw):
        return self.inputs.get(label, value)

    def toggle(self, label, value=False, **kw):
        return self.inputs.get(label, value)

    checkbox = toggle

    def button(self, label, **kw):
        self._rec("button", label)
        return label in self.pressed

    def set_page_config(self, **kw):
        self._rec("set_page_config", **kw)

    def __getattr__(self, name):                       # title, caption, markdown, metric, dataframe, line_chart, ...
        if name.startswith("_"):
            raise AttributeError(name)
        return lambda *a, **k: self._rec(name, *a, **k)
