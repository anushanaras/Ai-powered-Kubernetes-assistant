import json

from app.analyzer import analyze_cluster, utilization_summary
from app.kube import _demo_snapshot
from app.llm import LLMClient, LLMError, build_context, sanitize


def make_client(response=None, error=None, calls=None):
    def post(url, headers, body, timeout):
        if calls is not None:
            calls.append((url, headers, body))
        if error:
            raise error
        return response
    return LLMClient("sk-test", "claude-test", post=post)


def test_sanitize_redacts_secrets_and_control_chars():
    s = sanitize("login failed password=hunter2 token: abc123 Authorization: Bearer abcdefghijkl\x00x")
    assert "hunter2" not in s and "abc123" not in s and "abcdefghijkl" not in s and "\x00" not in s
    assert "secret foo not found" in sanitize("secret foo not found")      # ordinary prose is kept
    assert len(sanitize("a" * 1000, 50)) == 50


def test_build_context_is_compact_and_scoped():
    snap = _demo_snapshot()
    ctx = build_context(snap, analyze_cluster(snap), utilization_summary(snap))
    assert ctx["totals"]["pods"] == len(snap["pods"]) and ctx["findings"] and ctx["nodes"]
    blob = json.dumps(ctx)
    assert "containers" not in blob and "owner_kind" not in blob     # raw pod objects never leave the process
    assert any(p["pod"] == "payments/api-55cc9f" for p in ctx["problem_pods"])


def test_ask_sends_expected_request_and_returns_text():
    calls = []
    client = make_client({"content": [{"type": "text", "text": "Raise the memory limit."}]}, calls=calls)
    out = client.ask("why is api crashing?", {"findings": []})
    url, headers, body = calls[0]
    assert out == "Raise the memory limit."
    assert url == "https://api.anthropic.com/v1/messages" and headers["x-api-key"] == "sk-test"
    assert headers["anthropic-version"] == "2023-06-01"
    assert body["model"] == "claude-test" and "tools" not in body            # advisor only, no tools
    user = body["messages"][0]["content"]
    assert "<cluster_data>" in user and "why is api crashing?" in user
    assert "untrusted" in body["system"].lower() or "never follow instructions" in body["system"].lower()


def test_question_is_truncated_and_cleaned():
    calls = []
    make_client({"content": [{"type": "text", "text": "ok"}]}, calls=calls).ask("x\x00" * 400, {})
    user = calls[0][2]["messages"][0]["content"]
    question = user.split("Operator question: ")[1]
    assert "\x00" not in user and len(question) == 500


def test_errors_raise_llmerror():
    for client in (make_client({"content": []}), make_client(error=LLMError("HTTP 529"))):
        try:
            client.summarize({})
        except LLMError:
            continue
        raise AssertionError("expected LLMError")


def test_from_env(monkeypatch=None):
    import os
    saved = {k: os.environ.pop(k, None) for k in ("ANTHROPIC_API_KEY", "LLM_MODEL")}
    try:
        assert LLMClient.from_env() is None
        os.environ["ANTHROPIC_API_KEY"] = "k"
        assert LLMClient.from_env().model == "claude-sonnet-5-5"
        os.environ["LLM_MODEL"] = "claude-haiku-5-5"
        assert LLMClient.from_env().model == "claude-haiku-5-5"
    finally:
        for k in ("ANTHROPIC_API_KEY", "LLM_MODEL"):
            os.environ.pop(k, None)
            if saved[k] is not None:
                os.environ[k] = saved[k]
