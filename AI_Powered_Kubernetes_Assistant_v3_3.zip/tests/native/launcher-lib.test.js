const test = require('node:test'), assert = require('node:assert');
const { normalizeServerUrl: n } = require('../../native/launcher/launcher-lib.js');

test('adds https and reduces to the origin', () => {
  assert.deepEqual(n('k8s.example.com'), { origin: 'https://k8s.example.com', appUrl: 'https://k8s.example.com/app/', host: 'k8s.example.com' });
  assert.equal(n('  https://k8s.example.com/some/path?x=1#y  ').origin, 'https://k8s.example.com');
  assert.equal(n('K8S.Example.COM:8443').origin, 'https://k8s.example.com:8443');
});
test('plain http only for local testing', () => {
  assert.ok(n('http://localhost:8000').origin); assert.ok(n('http://10.0.2.2:8000').origin); assert.ok(n('localhost:8000').origin);
  assert.match(n('http://k8s.example.com').error, /https/);
  assert.match(n('http://localhost:8000', { allowInsecureLocal: false }).error, /https/);
});
test('rejects dangerous or malformed input', () => {
  for (const bad of ['', '   ', 'javascript:alert(1)', 'data:text/html,hi', 'file:///etc/passwd', 'ftp://x.example.com',
                     'https://user:pw@k8s.example.com', 'https://', 'http://[bad']) {
    assert.ok(n(bad).error, 'should reject ' + JSON.stringify(bad));
  }
});
test('host:port without scheme is accepted, not mistaken for a scheme', () => {
  assert.equal(n('cluster.internal:8443').origin, 'https://cluster.internal:8443');
});
