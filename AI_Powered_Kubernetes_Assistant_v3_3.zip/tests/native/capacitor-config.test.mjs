import test from 'node:test';
import assert from 'node:assert';
import { buildConfig } from '../../native/mobile/capacitor.config.ts';

test('managed build bakes in the server and restricts navigation', () => {
  const c = buildConfig({ KA_SERVER_URL: 'https://k8s.example.com/', KA_ALLOWED_HOSTS: 'login.example.com, *.okta.com' });
  assert.equal(c.server.url, 'https://k8s.example.com/app/');
  assert.deepEqual(c.server.allowNavigation, ['k8s.example.com', 'login.example.com', '*.okta.com']);
  assert.equal(c.server.cleartext, false);
  assert.equal(c.webDir, '../launcher');
});

test('generic build uses the launcher; hosts default to wildcard only for development', () => {
  const dev = buildConfig({});
  assert.equal(dev.server.url, undefined);
  assert.deepEqual(dev.server.allowNavigation, ['*']);
  assert.deepEqual(buildConfig({ KA_ALLOWED_HOSTS: 'k8s.example.com' }).server.allowNavigation, ['k8s.example.com']);
});

test('plain http and credentials are refused for managed builds', () => {
  assert.throws(() => buildConfig({ KA_SERVER_URL: 'http://k8s.example.com' }), /https/);
  assert.throws(() => buildConfig({ KA_SERVER_URL: 'https://u:p@k8s.example.com' }), /credentials/);
  assert.throws(() => buildConfig({ KA_SERVER_URL: 'not a url' }));
  const emu = buildConfig({ KA_SERVER_URL: 'http://10.0.2.2:8000', KA_ALLOW_INSECURE_DEV: 'true' });
  assert.equal(emu.server.cleartext, true);
});
