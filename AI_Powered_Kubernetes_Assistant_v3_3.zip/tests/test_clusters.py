import pytest

from app.clusters import ClusterRegistry, load_registry, parse_clusters


def test_default_is_single_local_cluster(monkeypatch):
    monkeypatch.delenv("CLUSTERS_CONFIG", raising=False)
    reg = load_registry()
    assert reg.names() == ["local"] and reg.get(None).name == "local"


def test_parse_and_lookup(tmp_path):
    f = tmp_path / "c.json"
    f.write_text('{"clusters":[{"name":"prod-eu","kubeconfig":"/k/eu","context":"eu"},{"name":"prod-us","in_cluster":true}]}')
    reg = load_registry(str(f))
    assert reg.default == "prod-eu" and reg.get("prod-us").in_cluster and "prod-eu" in reg
    with pytest.raises(KeyError):
        reg.get("nope")


@pytest.mark.parametrize("bad", ["", "a b", "x" * 64, "../etc"])
def test_invalid_names_rejected(bad):
    with pytest.raises(ValueError):
        parse_clusters({"clusters": [{"name": bad}]})


def test_duplicates_and_empty_rejected():
    from app.clusters import ClusterConfig
    with pytest.raises(ValueError):
        ClusterRegistry([ClusterConfig("a"), ClusterConfig("a")])
    with pytest.raises(ValueError):
        ClusterRegistry([])
