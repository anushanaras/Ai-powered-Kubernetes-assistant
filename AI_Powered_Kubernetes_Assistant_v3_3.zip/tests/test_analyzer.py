from app.analyzer import analyze_cluster, answer_question


def test_failed_pod_detected():
    snapshot = {"pods": [{"name": "bad", "namespace": "default", "phase": "Failed", "ready": False, "restarts": 0}], "nodes": []}
    findings = analyze_cluster(snapshot)
    assert any("Pod phase is Failed" in f["issue"] for f in findings)


def test_healthy_snapshot_has_info():
    snapshot = {"pods": [{"name": "ok", "namespace": "default", "phase": "Running", "ready": True, "restarts": 0}],
                "nodes": [{"name": "n1", "conditions": {"Ready": True}}]}
    assert analyze_cluster(snapshot)[0]["severity"] == "info"


def test_question_about_pods():
    snapshot = {"pods": [{"name": "x", "namespace": "default", "phase": "Pending", "ready": False, "restarts": 0}], "nodes": []}
    assert "Pods to inspect" in answer_question("Which pods are unhealthy?", snapshot)
