These plain manifests are the v2.0 single-cluster install and are kept for reference.
For production use the Helm chart in `chart/kubernetes-assistant`.
