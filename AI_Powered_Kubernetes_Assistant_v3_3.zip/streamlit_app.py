"""Kubernetes AI Assistant: local Streamlit interface.   Run:  streamlit run streamlit_app.py

Single-user, read-only tool that uses your own kubeconfig (like kubectl). It has no login, so it binds to 127.0.0.1;
for teams use the FastAPI server (SSO + RBAC). Demo mode (default) needs no cluster:  DEMO_MODE=false to use a real one.
"""
from html import escape
import os
import time

import streamlit as st

from app.analyzer import analyze_cluster, answer_question, utilization_summary
from app.clusters import load_registry
from app.dashboard_data import (CSS, aggregate_usage, cluster_timeseries, gauge_svg, home_summary, kpi_tile_html, log_html,
                                pod_status_counts, status_donut_html)
from app.history import History, Sampler, seed_demo_history
from app.kube import LogsError, fetch_pod_logs, get_snapshot
from app.llm import LLMClient, LLMError, build_context
from app.logs import analyze_logs, filter_lines, parse_log, redact
from app.troubleshoot import recommend

VERSION = "3.3.0"
PAGES = ["🏠 Home", "📊 Cluster Monitoring", "📜 Logs Analysis", "🔔 Event Analysis", "🤖 AI Assistant", "📈 Dashboard", "⚙️ Settings"]
HEALTH_COLORS = {"Healthy": "#1f9d55", "Degraded": "#d98a00", "Critical": "#c0392b", "Unknown": "#6b7787"}
DEMO = os.getenv("DEMO_MODE", "true").lower() in ("1", "true", "yes")


# --------------------------------------------------------------------------- shared state
@st.cache_resource
def registry():
    return load_registry()


@st.cache_resource
def history_for(cluster_name: str):
    """One History per cluster, kept across reruns. Live mode samples in the background; demo mode is pre-seeded."""
    hist = History()
    cfg = registry().get(cluster_name)
    if DEMO:
        seed_demo_history(hist, get_snapshot(cfg))
    else:
        Sampler(hist, lambda: get_snapshot(cfg), interval=60.0).start()
    return hist


def ai_client():
    return LLMClient.from_env()


def load(cluster_name: str):
    cfg = registry().get(cluster_name)
    snapshot = get_snapshot(cfg)
    hist = history_for(cluster_name)
    findings = analyze_cluster(snapshot, history=hist)
    return snapshot, findings, utilization_summary(snapshot), hist


def auto_refresh(fn):
    """Run `fn`, re-running it on a timer when the user enabled auto-refresh (Streamlit fragments)."""
    seconds = int(st.session_state.get("refresh_seconds", 0) or 0)
    if seconds > 0 and hasattr(st, "fragment"):
        st.fragment(run_every=seconds)(fn)()
    else:
        fn()


def html(markup: str):
    st.markdown(markup, unsafe_allow_html=True)       # callers pass only strings built by dashboard_data (all escaped)


# --------------------------------------------------------------------------- pages
def page_home(cluster, data):
    def body():
        snapshot, findings, usage, _ = load(cluster)
        s = home_summary(snapshot, findings)
        st.title("Kubernetes AI Assistant")
        st.caption("Monitor  |  Analyze  |  Troubleshoot  |  Optimize")
        if snapshot.get("mode") == "error":
            st.error(snapshot.get("error", "Could not read the cluster."))
        st.info("Welcome to your Kubernetes Assistant. Get real-time cluster insights, analyze logs and events, "
                "find issues, and receive AI-powered troubleshooting recommendations.")
        c = st.columns(4)
        tiles = [("Cluster Health", s["health"], "", HEALTH_COLORS[s["health"]]),
                 ("Pods", f'{s["pods_running"]} Running', f'of {s["pods_total"]} total', "#1769aa"),
                 ("Nodes", f'{s["nodes_ready"]} Ready', f'of {s["nodes_total"]} total', "#6c4bb5"),
                 ("Alerts", f'{s["alerts_active"]} Active', "high + medium findings", "#e67e22")]
        for col, (label, value, sub, color) in zip(c, tiles):
            with col:
                html(kpi_tile_html(label, value, sub, color))
        st.subheader("Top findings")
        top = [f for f in findings if f["severity"] in ("high", "medium")][:5]
        if not top:
            st.success("No high or medium severity findings.")
        for f in top:
            with st.expander(f'{f["severity"].upper()} · {f["resource"]} · {f["issue"]}'):
                st.write(f["evidence"] or "")
                st.markdown("**Recommendation:** " + f["recommendation"])
    auto_refresh(body)


def page_monitoring(cluster, data):
    def body():
        snapshot, findings, usage, _ = load(cluster)
        st.title("Cluster Monitoring")
        st.subheader("Nodes")
        if not usage["nodes"]:
            st.info("No node metrics available (Metrics Server missing or not permitted).")
        for n in usage["nodes"]:
            st.markdown(f"**{n['name']}** · {n['pod_count']} pods")
            a, b = st.columns(2)
            a.progress(min(max((n["cpu_pct"] or 0) / 100, 0.0), 1.0), text=f"CPU {n['cpu_pct']}% (requested {n['cpu_requests_pct']}%)")
            b.progress(min(max((n["mem_pct"] or 0) / 100, 0.0), 1.0), text=f"Memory {n['mem_pct']}% (requested {n['mem_requests_pct']}%)")
        st.subheader("Pods")
        import pandas as pd
        rows = [{"namespace": p["namespace"], "pod": p["name"], "phase": p["phase"], "ready": p["ready"], "restarts": p["restarts"],
                 "node": p.get("node") or "", "owner": p.get("owner_kind") or ""} for p in snapshot.get("pods", [])]
        df = pd.DataFrame(rows, columns=["namespace", "pod", "phase", "ready", "restarts", "node", "owner"])
        left, right = st.columns(2)
        ns = left.multiselect("Namespace", sorted(df["namespace"].unique()) if len(df) else [])
        ph = right.multiselect("Phase", sorted(df["phase"].unique()) if len(df) else [])
        if ns:
            df = df[df["namespace"].isin(ns)]
        if ph:
            df = df[df["phase"].isin(ph)]
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.subheader("Top consumers")
        l2, r2 = st.columns(2)
        l2.markdown("**CPU (millicores)**")
        l2.dataframe(pd.DataFrame(usage["top_cpu_pods"]), use_container_width=True, hide_index=True)
        r2.markdown("**Memory (bytes)**")
        r2.dataframe(pd.DataFrame(usage["top_memory_pods"]), use_container_width=True, hide_index=True)
    auto_refresh(body)


def _fetch_for_ui(cluster, snapshot, namespace, pod, tail, previous):
    cfg = registry().get(cluster)
    targets = [p["name"] for p in snapshot.get("pods", []) if p["namespace"] == namespace] if pod == "All Pods" else [pod]
    all_lines, problems = [], []
    for name in targets[:8]:                      # cap fan-out so one click cannot hammer the API server
        try:
            raw = fetch_pod_logs(cfg, namespace, name, tail=tail if pod != "All Pods" else min(tail, 100), previous=previous)
        except LogsError as exc:
            problems.append(f"{name}: {exc}")
            continue
        for l in parse_log(raw):
            all_lines.append({**l, "message": (f"[{name}] " if pod == "All Pods" else "") + l["message"]})
    if len(targets) > 8:
        problems.append(f"Showing the first 8 of {len(targets)} pods.")
    return all_lines, problems


def page_logs(cluster, data):
    snapshot, findings, usage, _ = load(cluster)
    st.title("Logs Analysis")
    namespaces = sorted({p["namespace"] for p in snapshot.get("pods", [])})
    if not namespaces:
        st.info("No pods to read logs from.")
        return
    c1, c2, c3, c4 = st.columns([2, 3, 2, 2])
    ns = c1.selectbox("Namespace", namespaces)
    pods = ["All Pods"] + sorted(p["name"] for p in snapshot["pods"] if p["namespace"] == ns)
    pod = c2.selectbox("Pod", pods)
    tail = c3.slider("Lines", 50, 1000, 200, step=50)
    previous = c4.checkbox("Previous container", value=False)
    if st.button("Fetch Logs", type="primary"):
        with st.spinner("Reading logs…"):
            lines, problems = _fetch_for_ui(cluster, snapshot, ns, pod, tail, previous)
        st.session_state["logs"] = {"ns": ns, "pod": pod, "lines": lines, "problems": problems, "at": time.time()}
    got = st.session_state.get("logs")
    if not got:
        st.caption("Choose a namespace and pod, then press Fetch Logs.")
        return
    for msg in got["problems"]:
        st.warning(msg)
    lines = got["lines"]
    analysis = analyze_logs(lines)
    st.session_state["last_log_analysis"] = analysis
    m = st.columns(4)
    m[0].metric("Lines", analysis["total"])
    m[1].metric("Errors", analysis["counts"]["ERROR"])
    m[2].metric("Warnings", analysis["counts"]["WARN"])
    m[3].metric("Error rate", f'{analysis["error_rate"]}%')
    if analysis["findings"]:
        st.subheader("Detected issues")
        for f in analysis["findings"]:
            with st.expander(f'{f["severity"].upper()} · {f["issue"]} ({f["count"]}×)'):
                st.code(redact(f["example"]))
                st.markdown("**Suggestion:** " + f["recommendation"])
    a, b, c = st.columns([2, 3, 2])
    levels = a.multiselect("Levels", ["ERROR", "WARN", "INFO", "DEBUG", "UNKNOWN"], default=["ERROR", "WARN", "INFO", "DEBUG", "UNKNOWN"])
    query = b.text_input("Search")
    mask = c.toggle("Mask secrets", value=True)
    shown = filter_lines(lines, levels, query)
    if mask:
        shown = [{**l, "message": redact(l["message"])} for l in shown]
    st.subheader("Logs")
    html(log_html(shown))


def page_events(cluster, data):
    snapshot, findings, usage, _ = load(cluster)
    st.title("Event Analysis")
    import pandas as pd
    events = snapshot.get("events", [])
    df = pd.DataFrame([{"type": e["type"], "reason": e["reason"], "object": f'{e["object_kind"]}/{e["namespace"]}/{e["object_name"]}',
                        "count": e["count"], "message": e["message"], "last_seen": e["last_seen"]} for e in events],
                      columns=["type", "reason", "object", "count", "message", "last_seen"])
    only_warn = st.toggle("Warnings only", value=True)
    if only_warn and len(df):
        df = df[df["type"] == "Warning"]
    if len(df):
        st.subheader("Events by reason")
        st.bar_chart(df.groupby("reason")["count"].sum().sort_values(ascending=False).head(10))
        df = df.assign(last_seen=pd.to_datetime(df["last_seen"], unit="s", errors="coerce")).sort_values("last_seen", ascending=False)
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.success("No events to show.")
    ev_findings = [f for f in findings if f["rule"].startswith("event") or "event" in f["rule"]]
    if ev_findings:
        st.subheader("What the rules engine concluded")
        for f in ev_findings[:6]:
            st.markdown(f'- **{f["resource"]}**: {f["issue"]}  \n  _{f["recommendation"]}_')


def page_ai(cluster, data):
    snapshot, findings, usage, hist = load(cluster)
    st.title("AI Assistant")
    llm = ai_client()
    st.caption(f"Engine: Claude ({llm.model})" if llm else "Engine: built-in playbook (set ANTHROPIC_API_KEY to enable Claude)")
    t1, t2 = st.tabs(["Troubleshoot", "Ask a question"])
    with t1:
        issue = st.text_area("Issue Description", placeholder="Pod is not starting and showing CrashLoopBackOff", height=110, max_chars=500)
        use_logs = st.toggle("Include log signals from the last fetched logs", value=False,
                             help="Sends pattern names, counts and one short redacted example each. Never raw logs.")
        if st.button("Get AI Recommendation", type="primary") and issue.strip():
            analysis = st.session_state.get("last_log_analysis") if use_logs else None
            with st.spinner("Thinking…"):
                r = recommend(issue, snapshot, findings, usage, llm, analysis)
            st.subheader("AI Recommendation" if r["source"] == "llm" else "Recommendation (built-in playbook)")
            if r["note"]:
                st.warning(r["note"])
            if r["source"] == "llm":
                st.markdown(r["text"])
            else:
                if r["matched"]:
                    st.caption("Matched: " + ", ".join(r["matched"]))
                st.markdown("\n".join(f"{i}. {s}" for i, s in enumerate(r["steps"], 1)))
            if r["related"]:
                st.subheader("Related live findings")
                for f in r["related"]:
                    st.markdown(f'- **{f["resource"]}**: {f["issue"]}')
    with t2:
        q = st.text_input("Ask about this cluster", placeholder="Which pods use the most memory?", max_chars=500)
        if st.button("Ask") and q.strip():
            try:
                text = llm.ask(q, build_context(snapshot, findings, usage)) if llm else answer_question(q, snapshot, hist)
            except LLMError as exc:
                st.warning(f"Claude unavailable ({exc}); using the rules engine.")
                text = answer_question(q, snapshot, hist)
            st.markdown(text)


def page_dashboard(cluster, data):
    def body():
        snapshot, findings, usage, hist = load(cluster)
        st.title("Monitoring Dashboard")
        agg = aggregate_usage(usage)
        if not usage.get("metrics_available"):
            st.warning("Live CPU/memory metrics are unavailable" + (f": {usage['reason']}" if usage.get("reason") else "."))
        a, b, c = st.columns(3)
        with a:
            html(gauge_svg(agg["cpu_pct"], "CPU Usage"))
        with b:
            html(gauge_svg(agg["mem_pct"], "Memory Usage"))
        with c:
            html(status_donut_html(pod_status_counts(snapshot.get("pods", []))))
        st.subheader("Cluster Metrics")
        series = cluster_timeseries(hist)
        if len(series) >= 2:
            import pandas as pd
            df = pd.DataFrame({"CPU": [x[1] for x in series], "Memory": [x[2] for x in series]},
                              index=pd.to_datetime([x[0] for x in series], unit="s"))
            st.line_chart(df, height=280)
        else:
            st.info("History is still being collected. Come back in a few minutes.")
    auto_refresh(body)


def page_settings(cluster, data):
    st.title("Settings")
    st.markdown(f"**Version** {VERSION}  ·  **Mode** {'demo (sample data)' if DEMO else 'live cluster'}")
    st.markdown("**Clusters** " + ", ".join(registry().names()))
    llm = ai_client()
    st.markdown("**Claude** " + (f"enabled ({llm.model})" if llm else "off. Set `ANTHROPIC_API_KEY` to turn it on."))
    # Stored under a plain key: widget-bound keys are dropped by Streamlit whenever the widget is not rendered.
    st.session_state["refresh_seconds"] = st.slider("Auto-refresh (seconds, 0 = off)", 0, 300, int(st.session_state["refresh_seconds"]), step=10)
    st.info("Privacy: the model only ever receives a compact, redacted digest of findings and metrics. Raw logs are never sent.")
    st.caption("This interface has no login and binds to 127.0.0.1. For shared use deploy the FastAPI server with SSO/RBAC.")


ROUTES = {PAGES[0]: page_home, PAGES[1]: page_monitoring, PAGES[2]: page_logs, PAGES[3]: page_events,
          PAGES[4]: page_ai, PAGES[5]: page_dashboard, PAGES[6]: page_settings}


def main():
    st.set_page_config(page_title="Kubernetes AI Assistant", page_icon="☸️", layout="wide")
    html(CSS)
    st.session_state.setdefault("refresh_seconds", 30)
    with st.sidebar:
        st.markdown("### ☸️ K8s Assistant")
        page = st.radio("Navigation", PAGES, label_visibility="collapsed")
        names = registry().names()
        cluster = st.selectbox("Cluster", names) if len(names) > 1 else names[0]
        st.caption("Demo data" if DEMO else "Live cluster · read-only")
    try:
        ROUTES[page](cluster, None)
    except Exception as exc:  # noqa: BLE001 - never show a raw traceback with cluster details to the screen
        st.error(f"Something went wrong ({type(exc).__name__}). Check the terminal for details.")
        raise


if __name__ == "__main__":
    main()
